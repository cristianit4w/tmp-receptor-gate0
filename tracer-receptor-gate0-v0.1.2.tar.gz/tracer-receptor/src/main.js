import { startReceiver } from './server.js';
import { assertConformanceFixture } from './fixtureGate.js';

const asPositiveInt=(key,dflt,min=1,max=1_000_000)=> {
  const v=process.env[key]??String(dflt);const n=Number(v);
  if(!Number.isInteger(n)||n<min||n>max)throw Error(`${key} out of range`);return n;
};
if(process.env.DB_FORWARDER && process.env.DB_FORWARDER!=='false')throw Error('GATE0: DB_FORWARDER MUST be false');
if(process.env.DIAGNOSTIC_MODE!=='true')throw Error('GATE0: DIAGNOSTIC_MODE must be true');
if(process.env.RECEIVER_MODE!=='gate0')throw Error('GATE0: RECEIVER_MODE=gate0 required');
// No iniciar el TCP listener si no pasa la conformidad de 12 PC sanitizados.
assertConformanceFixture();
const receiver=startReceiver({
  host:process.env.TCP_HOST??'127.0.0.1',
  port:asPositiveInt('TCP_PORT',41873,1,65535),
  sqlitePath:process.env.SQLITE_PATH??'./data/spool.sqlite',
  healthPort:asPositiveInt('HEALTH_PORT',9090,1,65535),
  diagnostics:true,
  maxConnections:asPositiveInt('MAX_ACTIVE_CONNECTIONS',128,1,1000),
  maxConnectionsPerIP:asPositiveInt('MAX_CONNECTIONS_PER_IP',4,1,128),
  allowedSources:process.env.ALLOWED_SOURCES ?? '',
  maxErrorsRows:asPositiveInt('MAX_ERRORS_ROWS',1000,1,100000),
  maxSpoolBytes:asPositiveInt('MAX_SPOOL_BYTES',134217728,65536,10000000000),
  maxFrames:asPositiveInt('MAX_FRAMES_PER_CONNECTION',1000,1,100000),
  maxConnectionBytes:asPositiveInt('MAX_CONNECTION_BYTES',262144,59,10000000),
  idleTimeoutMs:asPositiveInt('SOCKET_IDLE_TIMEOUT_MS',8000,1000,300000),
  rawRetentionHours:asPositiveInt('RAW_RETENTION_HOURS',24,1,24),
});
let stopping=false;
async function stop(sig){if(stopping)return;stopping=true;console.log(JSON.stringify({event:'stop',signal:sig}));await receiver.close();process.exit(0);}
process.on('SIGTERM',()=>stop('SIGTERM'));
process.on('SIGINT',()=>stop('SIGINT'));
