import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export class Spool {
  constructor(filename, { diagnostics = false, rawRetentionHours = 24, maxErrorsRows = 1000, maxSpoolBytes = 134217728 } = {}) {
    if (!Number.isSafeInteger(maxErrorsRows) || maxErrorsRows < 1) throw Error('INVALID_MAX_ERRORS_ROWS');
    if (!Number.isSafeInteger(maxSpoolBytes) || maxSpoolBytes < 65536) throw Error('INVALID_MAX_SPOOL_BYTES');
    this.filename = filename;
    this.maxErrorsRows = maxErrorsRows;
    this.maxSpoolBytes = maxSpoolBytes;
    fs.mkdirSync(path.dirname(filename), { recursive: true, mode: 0o750 });
    this.db = new DatabaseSync(filename);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
      PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS spool (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        hash TEXT NOT NULL UNIQUE, received_at TEXT NOT NULL, reported_at TEXT NOT NULL,
        plate TEXT NOT NULL, gps_valid INTEGER NOT NULL, event_code TEXT NOT NULL,
        event_known INTEGER NOT NULL DEFAULT 1,
        payload_json TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','retry','sent')),
        retry_count INTEGER NOT NULL DEFAULT 0, next_retry_at TEXT
      );
      CREATE TABLE IF NOT EXISTS last_state (
        plate TEXT PRIMARY KEY, last_reported_at TEXT, last_received_at TEXT,
        last_valid_at TEXT, valid_lat REAL, valid_lon REAL,
        latest_gps_valid INTEGER, latest_event TEXT
      );
      CREATE TABLE IF NOT EXISTS counters (name TEXT PRIMARY KEY, n INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS raw_diagnostic (
        seq INTEGER PRIMARY KEY AUTOINCREMENT, received_at TEXT NOT NULL, raw_hex TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS errors (
        seq INTEGER PRIMARY KEY AUTOINCREMENT, observed_at TEXT NOT NULL,
        code TEXT NOT NULL, source_ip TEXT, bytes_len INTEGER NOT NULL,
        raw_text TEXT
      );
    `);
    // Migracion idempotente para colas creadas antes de v0.1.2.
    if (!this.db.prepare('PRAGMA table_info(spool)').all().some(c => c.name === 'event_known')) {
      this.db.exec('ALTER TABLE spool ADD COLUMN event_known INTEGER NOT NULL DEFAULT 1');
    }
    this.insert = this.db.prepare(`INSERT INTO spool(hash,received_at,reported_at,plate,gps_valid,event_code,event_known,payload_json)
      VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(hash) DO NOTHING`);
    this.getLast = this.db.prepare('SELECT * FROM last_state WHERE plate=?');
    this.saveLast = this.db.prepare(`INSERT INTO last_state(plate,last_reported_at,last_received_at,last_valid_at,valid_lat,valid_lon,latest_gps_valid,latest_event)
      VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(plate) DO UPDATE SET
        last_reported_at=excluded.last_reported_at,last_received_at=excluded.last_received_at,
        last_valid_at=excluded.last_valid_at,valid_lat=excluded.valid_lat,valid_lon=excluded.valid_lon,
        latest_gps_valid=excluded.latest_gps_valid,latest_event=excluded.latest_event`);
    this.incr = this.db.prepare('INSERT INTO counters(name,n) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET n=n+excluded.n');
    this.insertError = this.db.prepare('INSERT INTO errors(observed_at,code,source_ip,bytes_len,raw_text) VALUES(?,?,?,?,?)');
    this.pruneErrorsStmt = this.db.prepare('DELETE FROM errors WHERE seq NOT IN (SELECT seq FROM errors ORDER BY seq DESC LIMIT ?)');
    // Aplicar el tope tambien a una tabla errors heredada de v0.1.1.
    this.pruneErrorsStmt.run(this.maxErrorsRows);
    this.pruneStmt = this.db.prepare('UPDATE errors SET raw_text=NULL WHERE observed_at < ?');
    this.insertRaw = this.db.prepare('INSERT INTO raw_diagnostic(received_at,raw_hex) VALUES(?,?)');
    this.pruneRawStmt = this.db.prepare('DELETE FROM raw_diagnostic WHERE received_at < ?');
    this.diagnostics = diagnostics;
    this.rawRetentionHours = Math.min(24, Math.max(1, rawRetentionHours));
  }
  // Fisico, incluidos archivos WAL/SHM: es un umbral de seguridad, no una cuota OS exacta.
  spoolBytes() {
    return [this.filename, this.filename + '-wal', this.filename + '-shm'].reduce((sum, f) => {
      try { return sum + fs.statSync(f).size; } catch (e) { if (e.code === 'ENOENT') return sum; throw e; }
    }, 0);
  }
  capacity() {
    const bytes = this.spoolBytes();
    const ratio = bytes / this.maxSpoolBytes;
    return {bytes, limitBytes:this.maxSpoolBytes,
      utilization:Number(ratio.toFixed(4)),
      status:ratio >= 0.95 ? 'critical' : ratio >= 0.80 ? 'warning' : 'ok',
      nearingLimit:ratio >= 0.80, acceptingFrames:ratio < 0.95};
  }
  count(name, n = 1) { this.incr.run(name, n); }
  ingest(parsed, { receivedAt = new Date().toISOString(), rawFrame = null } = {}) {
    // Dejar margen previo al 100%: si no hay espacio, rechazar explícitamente.
    // Tracer no reenvia, asi que la alerta de salud debe llegar ANTES (80%).
    if (!this.capacity().acceptingFrames) {
      const error = new Error('SPOOL_CAPACITY_EXCEEDED'); error.code = 'SPOOL_CAPACITY_EXCEEDED'; throw error;
    }
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const r = this.insert.run(parsed.hash, receivedAt, parsed.reportedAt, parsed.plate,
        parsed.gpsValid ? 1 : 0, parsed.eventCode, parsed.eventKnown === false ? 0 : 1, JSON.stringify(parsed));
      // Raw diagnostico se registra por CADA frame valido, incluidos duplicados,
      // para reconciliar el contador de frames con el stream TCP (purga <=24h).
      if (this.diagnostics && rawFrame !== null) this.insertRaw.run(receivedAt, Buffer.from(rawFrame).toString('hex'));
      if (parsed.eventKnown === false) this.count('events_unknown');
      if (r.changes === 0) {
        this.count('duplicates');
        this.db.exec('COMMIT');
        return 'duplicate';
      }
      if (parsed.eventKnown === false) this.count('events_unknown_unique');
      const last = this.getLast.get(parsed.plate);
      const newReport = !last?.last_reported_at || parsed.reportedAt >= last.last_reported_at;
      const newValid = parsed.gpsValid && (!last?.last_valid_at || parsed.reportedAt >= last.last_valid_at);
      this.saveLast.run(parsed.plate,
        newReport ? parsed.reportedAt : last.last_reported_at,
        newReport ? receivedAt : last.last_received_at,
        newValid ? parsed.reportedAt : (last?.last_valid_at ?? null),
        newValid ? parsed.latitude : (last?.valid_lat ?? null),
        newValid ? parsed.longitude : (last?.valid_lon ?? null),
        newReport ? (parsed.gpsValid ? 1 : 0) : last.latest_gps_valid,
        newReport ? parsed.eventCode : last.latest_event);
      this.count('stored');
      this.db.exec('COMMIT');
      return 'stored';
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
  }
  error(code, sourceIp = null, bytes = Buffer.alloc(0)) {
    if (!Buffer.isBuffer(bytes)) bytes = Buffer.from(bytes);
    const safeRaw = this.diagnostics && bytes.length <= 59 ? bytes.toString('hex') : null;
    // Limitar el numero de filas sin perder la metrica acumulada en counters.
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.insertError.run(new Date().toISOString(), code, sourceIp, bytes.length, safeRaw);
      this.pruneErrorsStmt.run(this.maxErrorsRows);
      this.count('error_' + code);
      this.db.exec('COMMIT');
    } catch(e) { this.db.exec('ROLLBACK'); throw e; }
  }
  pruneRaw(now = Date.now()) {
    const cutoff = new Date(now - this.rawRetentionHours * 3600000).toISOString();
    return this.pruneStmt.run(cutoff).changes + this.pruneRawStmt.run(cutoff).changes;
  }
  purgeDiagnosticRaw() {
    const a = this.db.prepare('DELETE FROM raw_diagnostic').run().changes;
    const b = this.db.prepare('UPDATE errors SET raw_text=NULL WHERE raw_text IS NOT NULL').run().changes;
    return {rawFramesRemoved:a,errorRawRedacted:b};
  }
  stats() {
    const row = this.db.prepare(`SELECT COUNT(*) total, SUM(CASE WHEN state='pending' THEN 1 ELSE 0 END) pending,
       MIN(CASE WHEN state='pending' THEN received_at ELSE NULL END) oldest_pending_at FROM spool`).get();
    const counters = Object.fromEntries(this.db.prepare('SELECT name,n FROM counters ORDER BY name').all().map(r => [r.name,r.n]));
    return { queueDepth: Number(row.pending ?? 0), totalStored: Number(row.total ?? 0), oldestPendingAt: row.oldest_pending_at, counters, spoolCapacity: this.capacity(), errorsRetained: this.db.prepare('SELECT COUNT(*) n FROM errors').get().n };
  }
  last(plate) { return this.getLast.get(plate); }
  close() { this.db.close(); }
}
