import net from 'node:net';
import http from 'node:http';
import { parsePC, FrameError } from './parser.js';
import { FrameDecoder } from './decoder.js';
import { Spool } from './spool.js';
import { createSourcePolicy, normalizeIP } from './sourcePolicy.js';

export function startReceiver(config) {
  const sourcePolicy = createSourcePolicy(config.allowedSources ?? '');
  const spool = new Spool(config.sqlitePath, { diagnostics: config.diagnostics, rawRetentionHours: config.rawRetentionHours ?? 24, maxErrorsRows: config.maxErrorsRows ?? 1000, maxSpoolBytes: config.maxSpoolBytes ?? 134217728 });
  const connections = new Set();
  const allSockets = new Set(); // incluye sockets rechazados/evictados hasta su evento close
  const ipConnections = new Map();
  let ready = false, fatal = null;
  const log = (level, event, detail = {}) => console.log(JSON.stringify({ts:new Date().toISOString(),level,event,...detail}));
  const maxConns = config.maxConnections ?? 128;
  const maxPerIP = config.maxConnectionsPerIP ?? 4;
  const maxBytes = config.maxConnectionBytes ?? 256 * 1024;
  const maxFrames = config.maxFrames ?? 1000;
  const tcp = net.createServer({ allowHalfOpen: false }, socket => {
    allSockets.add(socket);
    socket.once('close',()=>allSockets.delete(socket));
    spool.count('connections');
    const ip = normalizeIP(socket.remoteAddress ?? 'unknown');
    if (!sourcePolicy.allows(ip)) {
      spool.count('rejected_sources');
      log('warn','source_rejected',{ip});
      socket.destroy(); return;
    }
    // Si hay sockets sin DATOS ocupando cupos, desalojar el mas antiguo
    // ANTES de rechazar un lote legitimo del mismo origen. Una IP puede
    // tener como maximo maxPerIP conexiones activas; nunca se supera maxConns.
    const perIP = ipConnections.get(ip) ?? new Set();
    const evictIdle = pool => {
      const candidate = [...pool].filter(meta => meta.bytes === 0)
        .sort((a,b) => a.openedAt - b.openedAt)[0];
      if (!candidate) return false;
      candidate.release();
      candidate.socket.destroy();
      spool.count('evicted_idle_connections');
      return true;
    };
    if (perIP.size >= maxPerIP && !evictIdle(perIP)) {
      spool.count('rejected_ip_limit'); socket.destroy(); return;
    }
    if (connections.size >= maxConns && !evictIdle(connections)) {
      spool.count('rejected_connections'); socket.destroy(); return;
    }
    const meta = {socket,bytes:0,openedAt:Date.now(),released:false,release(){
      if(this.released)return;this.released=true;
      connections.delete(this);
      const pool=ipConnections.get(ip);
      if(pool){pool.delete(this);if(!pool.size)ipConnections.delete(ip);}
    }};
    connections.add(meta);
    const group=ipConnections.get(ip) ?? new Set();
    group.add(meta); ipConnections.set(ip,group);
    let totalBytes = 0, complete = false;
    const decoder = new FrameDecoder({ maxFrames,
      onFrame(frame) {
        try {
          const parsed = parsePC(frame);
          const result = spool.ingest(parsed,{rawFrame:frame});
          spool.count('frames_valid');
          if (config.diagnostics) log('info','frame_received',{
            result, frameBytes:frame.length, reportLagSeconds:Math.round((Date.now()-Date.parse(parsed.reportedAt))/1000),
            // Deliberadamente: NO incluir patente/coordenadas/crudo en journald.
          });
        } catch (e) {
          if (e instanceof FrameError) {
            spool.error(e.code, ip, frame);
            log('warn','frame_rejected',{code:e.code,bytes:frame.length});
          } else { fatal = e; log('error','spool_failure',{message:e.message}); socket.destroy(); }
        }
      },
      onError(e) { spool.error(e.code ?? 'DECODER_ERROR',ip); log('warn','framing_error',{code:e.code}); },
    });
    socket.setTimeout(config.idleTimeoutMs ?? 8000, () => {
      spool.error('SOCKET_IDLE_TIMEOUT',ip); socket.destroy();
    });
    socket.on('data', chunk => {
      totalBytes += chunk.length;
      meta.bytes += chunk.length;
      spool.count('bytes_received',chunk.length);
      if (totalBytes > maxBytes) {
        spool.error('MAX_CONNECTION_BYTES', ip);
        socket.destroy(); return;
      }
      try { decoder.feed(chunk); }
      catch (e) {
        spool.error(e.code ?? 'DECODER_ERROR',ip);
        log('warn','connection_rejected',{code:e.code ?? 'DECODER_ERROR'});
        socket.destroy();
      }
    });
    socket.on('end',() => { complete=true; decoder.eof(); spool.count('batches_completed'); });
    socket.on('error',e => log('warn','tcp_socket_error',{code:e.code}));
    socket.on('close',()=> {
      meta.release();
      if(!complete) {
        if (decoder.pending.length) spool.error('CONNECTION_CLOSED_WITH_PARTIAL',ip);
        spool.count('connections_aborted');
      }
      if(config.diagnostics) log('info','connection_closed',{ip,bytes:totalBytes,frames:decoder.frames,complete});
    });
    // PROHIBIDO: socket.write()/socket.end(data). Ningun ACK de aplicacion.
  });
  tcp.on('error', e => {fatal=e; log('error','listener_error',{code:e.code,message:e.message});});
  tcp.listen(config.port,config.host,()=>{ready=true;log('info','listener_started',{host:config.host,port:config.port,diagnostics:config.diagnostics,forwarder:false});});
  const health = http.createServer((req,res)=>{
    if(req.url !== '/live' && req.url !== '/metrics'){ res.writeHead(404);res.end();return; }
    const stats = spool.stats();
    const capacity = stats.spoolCapacity;
    const ok = ready && !fatal && capacity.status !== 'critical';
    const payload = req.url === '/live' ? {ok,alert:capacity.status === 'critical' ? 'SPOOL_CAPACITY_CRITICAL' : capacity.status === 'warning' ? 'SPOOL_NEARING_LIMIT' : null,uptimeSeconds:Math.floor(process.uptime()),mode:'DIAGNOSTIC_LOCAL_ONLY',activeConnections:connections.size,...stats} : {ok,activeConnections:connections.size,...stats};
    res.writeHead(ok?200:503, {'Content-Type':'application/json','Cache-Control':'no-store'});
    res.end(JSON.stringify(payload));
  });
  health.listen(config.healthPort ?? 9090, '127.0.0.1');
  const prune = setInterval(()=>spool.pruneRaw(),3600000);
  prune.unref();
  const close=async()=>{
    clearInterval(prune);
    // Escuchar 'close' ANTES de destruir, para no cerrar SQLite mientras
    // callbacks de sockets evacuados intenten contar errores/abortos.
    const socketClosures=[...allSockets].map(socket=>new Promise(resolve=>socket.once('close',resolve)));
    for(const socket of allSockets)socket.destroy();
    await Promise.all([new Promise(resolve=>tcp.close(resolve)),new Promise(resolve=>health.close(resolve)),...socketClosures]);
    spool.close();
  };
  return {tcp,health,spool,close};
}
