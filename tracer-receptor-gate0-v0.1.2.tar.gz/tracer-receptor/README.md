# Tracer/CAESSAT TCP receiver — v0.1.2 — GATE 0 (diagnóstico, sin integración productiva)

**Estado:** código construido y probado localmente. **No desplegado**. No usa Supabase, PostgreSQL, credenciales, aplicación By Mones ni otros sistemas de producción.

## Resumen

- Node.js **22.16+ (major 22 fijado con `apt-mark hold nodejs`)** nativo (sin Docker ni paquetes npm externos); `node:net`, `node:http`, `node:sqlite`. Probado en Node 22.16; `node:sqlite` emite `ExperimentalWarning` en esa versión.
- Puerto TCP configurable (objetivo `41873`), un socket por lote, N frames `PC` delimitados por `|`, EOF final.
- **Nunca escribe bytes en el socket de Tracer**. TCP FIN/ACK a nivel transporte no es ACK de aplicación.
- Solo `PC`, exactamente **59 bytes ASCII contando `|`**. `PS` rechaza con `PS_UNSUPPORTED_BY_SCOPE`.
- SQLite durable con `journal_mode=WAL`, `synchronous=FULL`, hashes idempotentes, reloj de reporte y de última posición válida independientes.
- **Modo GATE 0 obligatorio** `RECEIVER_MODE=gate0`, `DIAGNOSTIC_MODE=true`, `DB_FORWARDER=false`. Sin código de conexión a una base remota.
- Crudo en hexadecimal temporal (máx. 24 h), en SQLite local y **sin publicar por HTTP**; `/live` y `/metrics` escuchan únicamente en `127.0.0.1:9090`.
- Límites: 128 conexiones globales, 4/IP, timeout ocioso 8 s, bytes/frames y anti-starvation con desalojo de sockets sin datos. `ALLOWED_SOURCES` CIDR opcional además del firewall Lightsail.
- SQLite con `MAX_ERRORS_ROWS=1000` y capacidad `MAX_SPOOL_BYTES=134217728` (128 MiB): `/live` avisa al 80% y devuelve HTTP 503 al 95%; no es cuota física exacta.
- Eventos 01–11 conocidos; otros numéricos de 2 dígitos aceptados, `eventKnown=false`, almacenados y contados. Caracteres no numéricos continúan siendo inválidos.
- Simulador real de red TCP y tests locales.

## VM de Lightsail (estado confirmado por el dueño, no por acceso remoto)

- Instancia `tracer-receptor` Running, São Paulo zona A, Ubuntu 24.04 LTS, 1 GB, IPv4 estática `18.230.173.65`.
- Único perímetro: **Lightsail IPv4 Firewall**. SSH TCP 22 restringido al dueño + navegador; TCP `41873` **cerrado** fuera de ventanas. Sin reglas HTTP/IPv6; **UFW no está configurado**.
- Sistema actualizado con 2 paquetes pendientes y un **reinicio de kernel pendiente de comprobar**; NTP UTC operativo. **No instalar** antes de resolver el reinicio, dejar `PermitRootLogin no` y hacer snapshot manual PRE.
- Snapshot manual existente `base-limpia`; diarios automáticos 21:00 ART (7 retenidos). Se requieren snapshots manuales **PRE instalación** y **POST validación**. Una alerta AWS USD 15/mes no limita cargos.
- La primera ventana real Tracer **todavía no tiene fecha**; concertar >=48 h, lunes a viernes de 11:00 a 17:00 ART. Proveedor desde IP dinámica para prueba; producción desde `34.39.146.212` (no habilitar producción en GATE 0).
- Transferencia sin `scp`: `INSTALAR_SSH_PEGAR_TRACER_v0.1.2.txt`; el operador lo pega manualmente en el SSH del navegador.

Seguir en orden **0 → B → C → D → 0.4 → E → F/G** del `HOST_RECEPTOR_RUNBOOK.md`. Todo paso que modifica VM, snapshots o firewall lo ejecuta el dueño; no hay deploy automatizado.

## Inicio local sin instalación

```bash
node --version   # >= v22.16.0
npm test
RECEIVER_MODE=gate0 DIAGNOSTIC_MODE=true DB_FORWARDER=false \
  TCP_HOST=127.0.0.1 TCP_PORT=41873 SQLITE_PATH=/tmp/tracer-gate0-local.sqlite \
  node src/main.js
```

En **otra terminal**:

```bash
node bin/simulate.js --host 127.0.0.1 --port 41873 --batches 2 --per-batch 3 --chunk 7
curl -fsS http://127.0.0.1:9090/live
node bin/stats.js /tmp/tracer-gate0-local.sqlite
node bin/raw.js /tmp/tracer-gate0-local.sqlite
```

Simulador con fixture sintético antiguo: `node bin/simulate.js --fixture fixtures/PC_SINTETICOS.txt --batches 2 --per-batch 3 --chunk 1`.

**Conformidad obligatoria del fixture sanitizado de Tracer:** el propio `src/main.js` impide abrir el puerto si el fixture cambia o el parser deja de validarlo; adicionalmente `npm test` incorpora 12 pruebas nuevas sobre `fixtures/Ejemplo_paquetes_SANITIZADO.txt` (12 mensajes, 708 bytes, sin saltos). Para simular los tres lotes agrupados por patente y preservar el orden original:

```bash
node bin/simulate.js --fixture fixtures/Ejemplo_paquetes_SANITIZADO.txt --group-by-plate --chunk 7
```

`--group-by-plate` abre tres conexiones (4+5+3 frames); no ordena cronológicamente, no reescribe patentes ni genera ACK. Este fixture tiene fechas de 2018, por lo que **no sirve para medir latencia viva de Tracer**.

Los tests automatizados cubren layout, validaciones, PS, framing, EOF, GPS inválido, secuencia temporal, WAL/reinicio, duplicados y cero ACK de aplicación. No sustituyen pruebas con el TXT original del proveedor ni pruebas reales en Lightsail.

## Estructura

- `src/parser.js`: parser PC estricto, fecha UTC (18=2018), temperatura +99 nula provisional y valor crudo preservado; además genera fixtures sintéticos.
- `src/decoder.js`: framing independiente de límites de chunk TCP.
- `src/spool.js`: SQLite durable, deduplicación y contadores.
- `src/server.js`: TCP listener, endpoint de liveness local, límites y diagnóstico.
- `src/main.js`: arranque GATE0 con banderas bloqueantes.
- `bin/simulate.js`: generador de lotes sobre conexiones TCP no persistentes.
- `bin/stats.js`, `bin/raw.js`, `bin/backup.js`: inspección, purga diagnóstica y backup consistente.
- `systemd/`: unidad de servicio y heartbeat opcional.
- `HOST_RECEPTOR_RUNBOOK.md`: instrucciones operativas exactas para la VM y dos ventanas de ensayo.
- `RUNBOOK_PRUEBA_TRACER.md`: copia del runbook preexistente que rige ventana coordinada.
- `fixtures/FIXTURE_STATUS.md`: estado del fixture sanitizado, conformidad y supuestos abiertos.

## Delimitación de garantías

- No hay ACK ni replay de Tracer: SQLite garantiza persistencia solo **después** de recibir y persistir el frame. Si el puerto está cerrado, la VM cae o el disco falla, pueden perderse datos y Tracer no los reenvía.
- `frames_valid` cuenta frames parseados, incluidos duplicados; `stored` y `duplicates` separan inserciones nuevas vs duplicados. `pending` queda pendiente (no existe forwarder DB en GATE 0).
- `received_at` es del receptor, `reported_at` viene UTC de Tracer; latencia de proveedor esperada 60–90 s, no garantizada.
- Si `gpsValid=false`, jamás actualiza las coordenadas o fecha de última posición válida. No se infiere movimiento por hora nueva.
- Control de fuente IP mediante **firewall Lightsail**, no por cabecera de aplicación. Si la fuente de Tracer durante la ventana es dinámica, se abre el puerto a `0.0.0.0/0` solo durante esa ventana y se cierra inmediatamente.
- El diagnóstico almacena ubicación y patente en SQLite (dato sensible); disco restringido, no subir a GitHub/servicios de terceros. Captura PCAP aún más sensible.

## Contradicciones/bloqueos

Se recibió `Ejemplo_paquetes_SANITIZADO.txt` de 12 PC, con matrículas sintéticas. El parser y la cola se contrastaron contra esos bytes; **el fixture es sanitizado, no una captura directa independiente de la ventana real**. `+99` se interpreta provisionalmente como ausencia de sensor (`null`) manteniendo `temperatureRaw`, y **Tracer debe confirmar esta semántica**. Según el plan, una discrepancia de bytes/layout/framing en tráfico real obliga a **STOP**; no ajustar silenciosamente el parser.

**No instalar ni abrir el puerto como actividad productiva antes de GATE/ventana autorizada por el dueño.**

## Seguridad operativa de v0.1.2

- La lista `ALLOWED_SOURCES` se interpreta como IP/CIDR separados por comas; vacío no sustituye el firewall externo. Rechazo de origen en aplicación y contador `rejected_sources`.
- 40 sockets sin transmitir no impiden insertar un lote legítimo, ver test de anti-starvation. Si una IP acapara cuatro sockets activos **con datos**, las nuevas conexiones de esa IP se rechazan hasta liberar cupo; esto es una mitigación y debe observarse en los contadores.
- `events_unknown` registra cada evento desconocido recibido (incluidos duplicados); `events_unknown_unique` solo almacenados nuevos. El crudo y el hash no se alteran.
- Después de **cualquier** cambio de versión de Node (también parches), repetir `npm test` y evaluar el nuevo runtime antes de reiniciar el servicio. No habilitar ni activar forwarder o secretos.
- El umbral de spool no recupera mensajes perdidos cuando se llena o el receptor deja de escuchar: Tracer no hace reintentos.
