import test from 'node:test';import assert from 'node:assert/strict';
import { Spool } from '../src/spool.js';
import { Forwarder } from '../src/forwarder.js';
import { startMockIngest } from '../src/mockIngest.js';
import { KEY, PROFILE, tmp, syntheticParsed } from './helpers/util.js';

// Correcciones tras la validacion independiente de la IA de ByMones (rev. 1.3): H01..H06.
const T0 = Date.parse('2026-10-20T12:00:00Z');
async function setup({ rows = 3, fault = null, cfg = {} } = {}) {
  const t = tmp();
  const clock = { t: T0 };
  const spool = new Spool(t.file('staging-spool.sqlite'));
  for (let i = 0; i < rows; i++) spool.ingest(syntheticParsed(i), { receivedAt: new Date(T0 - 60000 + i).toISOString() });
  const mock = await startMockIngest({ key: KEY, ...PROFILE, fault, now: () => clock.t });
  const fw = new Forwarder({ spool, now: () => clock.t, random: () => 0.5, config: { ...PROFILE, key: KEY, url: mock.url, requestTimeoutMs: 3000, ...cfg } });
  fw.stopped = false;
  const env = { t, clock, spool, mock, fw,
    states: () => Object.fromEntries(env.spool.db.prepare('SELECT state, COUNT(*) n FROM spool GROUP BY 1').all().map(r => [r.state, r.n])),
    async done() { await env.fw.stop(); await mock.close(); env.spool.close(); t.destroy(); } };
  return env;
}

test('H01 Retry-After no se recorta: 7.200 s (y mas) se respetan en 429, 503, 401 y 400', async () => {
  for (const [status, ra, min] of [[429, '7200', 7200000], [503, '7200', 7200000], [401, '90000', 90000000], [400, '3600', 3600000], [403, '7200', 7200000]]) {
    const e = await setup({ fault: () => ({ status, headers: { 'Retry-After': ra }, body: { code: 'X' } }) });
    try {
      const d = await e.fw.cycle();
      assert.ok(d >= min, `status ${status} Retry-After ${ra}: espera ${d} < ${min}`);
      assert.deepEqual(e.states(), { pending: 3 }, 'la cola no se toca');
    } finally { await e.done(); }
  }
});
test('H01 Retry-After como fecha HTTP tambien se respeta sin recortar', async () => {
  const e = await setup({ fault: () => ({ status: 429, headers: { 'Retry-After': new Date(T0 + 7200000).toUTCString() }, body: {} }) });
  try {
    const d = await e.fw.cycle();
    assert.ok(d >= 7199000 && d <= 7201000, `espera ${d}`);
  } finally { await e.done(); }
});
test('H04 409 REPLAY con Retry-After positivo: un solo intento y pausa >= Retry-After', async () => {
  const e = await setup({ fault: () => ({ status: 409, headers: { 'Retry-After': '120' }, body: { code: 'REPLAY' } }) });
  try {
    const d = await e.fw.cycle();
    assert.equal(e.mock.requests.length, 1, 'sin reintentos inmediatos');
    assert.ok(d >= 120000);
    assert.equal(e.fw.status().lastError.code, 'REPLAY');
  } finally { await e.done(); }
});
test('409 REPLAY sin Retry-After: exactamente tres intentos totales (dos inmediatos) y luego backoff', async () => {
  const e = await setup({ fault: () => ({ status: 409, body: { code: 'REPLAY' } }) });
  try {
    const d = await e.fw.cycle();
    assert.equal(e.mock.requests.length, 3);
    assert.equal(new Set(e.mock.requests.map(r => r.auth.nonce)).size, 3, 'cada intento con nonce nuevo');
    assert.ok(d >= 1000);
    assert.deepEqual(e.states(), { pending: 3 });
  } finally { await e.done(); }
});
test('H06 409 de causa desconocida: NO se asume replay; contrato detenido >= 15 min y alerta', async () => {
  for (const body of [{ code: 'OTHER_CONFLICT' }, 'texto que no es json', { message: 'sin code' }]) {
    const e = await setup({ fault: () => ({ status: 409, body }) });
    try {
      const d = await e.fw.cycle();
      assert.equal(e.mock.requests.length, 1, 'un solo intento');
      assert.ok(d >= 900000);
      assert.equal(e.fw.status().halted.code, 'HTTP_409_UNKNOWN');
      assert.deepEqual(e.states(), { pending: 3 });
    } finally { await e.done(); }
  }
  const e = await setup({ fault: () => ({ status: 409, headers: { 'Retry-After': '7200' }, body: { code: 'OTHER' } }) });
  try { assert.ok(await e.fw.cycle() >= 7200000, 'respeta una espera mayor indicada por el servidor'); } finally { await e.done(); }
});
test('H05 400 con Retry-After mayor a 900 s: pausa >= Retry-After', async () => {
  const e = await setup({ fault: () => ({ status: 400, headers: { 'Retry-After': '3600' }, body: { code: 'INVALID_ENVELOPE' } }) });
  try { assert.ok(await e.fw.cycle() >= 3600000); assert.ok(e.fw.status().halted); } finally { await e.done(); }
});
test('HTTP 202 nunca confirma: cola intacta, contrato detenido 15 min y alerta', async () => {
  const e = await setup({ fault: () => ({ status: 202, body: { ackVersion: '1' } }) });
  try {
    const d = await e.fw.cycle();
    assert.deepEqual(e.states(), { pending: 3 });
    assert.ok(d >= 900000);
    assert.equal(e.fw.status().halted.code, 'HTTP_202');
  } finally { await e.done(); }
});

test('H02 respuesta de >1 MiB en BYTES (600.008 caracteres, 1.200.008 bytes) se rechaza como ACK invalido', async () => {
  const big = JSON.stringify({ pad: 'é'.repeat(600000) });   // 'é' = 2 bytes
  assert.ok(Buffer.byteLength(big) > 1048576 && big.length < 1048576);
  const e = await setup({ fault: () => ({ status: 200, body: big }) });
  try {
    await e.fw.cycle();
    assert.deepEqual(e.states(), { retry: 3 });
    assert.equal(e.fw.status().lastError.code, 'ACK_INVALID');
  } finally { await e.done(); }
});
test('H03 respuestas de error tambien se leen con tope y se cancelan (2 MiB en un 401)', async () => {
  const e = await setup({ fault: () => ({ status: 401, body: 'x'.repeat(2 * 1048576) }) });
  try {
    const d = await e.fw.cycle();
    assert.equal(e.fw.status().lastError.code, 'AUTH_401');
    assert.ok(d >= 60000);
    assert.deepEqual(e.states(), { pending: 3 });
  } finally { await e.done(); }
});
test('readBounded cancela el flujo al superar el limite y no lo consume entero', async () => {
  const e = await setup({ rows: 1 });
  try {
    let pulled = 0, cancelled = false;
    const chunk = new Uint8Array(256 * 1024);
    const stream = new ReadableStream({
      pull(c) { pulled += chunk.byteLength; c.enqueue(chunk); },
      cancel() { cancelled = true; },
    });
    const r = await e.fw.readBounded(new Response(stream, { status: 200 }));
    assert.equal(r.tooLarge, true);
    assert.equal(cancelled, true);
    assert.ok(pulled <= 1048576 + 2 * 256 * 1024, `se consumieron ${pulled} bytes`);
  } finally { await e.done(); }
});
test('readBounded: Content-Length declarado mayor al limite se rechaza antes de leer', async () => {
  const e = await setup({ rows: 1 });
  try {
    let cancelled = false;
    const res = { headers: { get: k => (k === 'content-length' ? '2000000' : null) }, body: { cancel: async () => { cancelled = true; }, getReader() { throw new Error('no debe leer'); } } };
    assert.deepEqual(await e.fw.readBounded(res), { tooLarge: true, json: null });
    assert.equal(cancelled, true);
  } finally { await e.done(); }
});
test('readBounded: cuerpo normal y JSON invalido', async () => {
  const e = await setup({ rows: 1 });
  try {
    assert.deepEqual((await e.fw.readBounded(new Response('{"a":1}'))).json, { a: 1 });
    assert.equal((await e.fw.readBounded(new Response('no json'))).json, null);
    assert.equal((await e.fw.readBounded(new Response(null))).tooLarge, false);
  } finally { await e.done(); }
});

test('la pausa por Retry-After sobrevive a un reinicio del reenviador', async () => {
  const e = await setup({ fault: () => ({ status: 429, headers: { 'Retry-After': '3600' }, body: {} }) });
  try {
    await e.fw.cycle();
    assert.equal(e.mock.requests.length, 1);
    e.clock.t += 10 * 60000;   // 10 minutos despues, "reinicio": otra instancia sobre la misma cola
    const fw2 = new Forwarder({ spool: e.spool, now: () => e.clock.t, random: () => 0.5, config: { ...PROFILE, key: KEY, url: e.mock.url } });
    fw2.start();
    try {
      const remaining = await fw2.cycle();
      assert.equal(e.mock.requests.length, 1, 'no vuelve a golpear al destino antes de tiempo');
      assert.ok(remaining > 49 * 60000 && remaining <= 50 * 60000, `quedan ${remaining} ms`);
      assert.ok(fw2.status().pausedUntil);
    } finally { await fw2.stop(); }
  } finally { await e.done(); }
});
test('un envio exitoso borra la pausa persistida', async () => {
  const e = await setup({});
  try {
    e.fw.setPause(5000);
    assert.equal(e.spool.getState('forwarder_paused_until'), String(T0 + 5000));
    e.clock.t += 6000;
    await e.fw.cycle();
    assert.equal(e.spool.getState('forwarder_paused_until'), '0');
    assert.equal(e.fw.status().pausedUntil, null);
  } finally { await e.done(); }
});
test('esperas mayores a 2^31-1 ms se parten en tramos sin acortarse', async () => {
  const e = await setup({ rows: 0 });
  const real = globalThis.setTimeout, seen = [];
  globalThis.setTimeout = (fn, ms, ...a) => { seen.push(ms); return real(fn, 5, ...a); };
  try {
    e.fw.schedule(3e9);
    await new Promise(r => real(r, 60));
    assert.equal(seen[0], 2 ** 31 - 1, 'primer tramo = maximo del temporizador');
    assert.equal(seen[1], 3e9 - (2 ** 31 - 1), 'el resto se programa despues, sin recortar');
  } finally { globalThis.setTimeout = real; await e.done(); }
});
