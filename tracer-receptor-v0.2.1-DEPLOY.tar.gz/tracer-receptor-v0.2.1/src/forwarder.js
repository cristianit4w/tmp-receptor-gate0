import crypto from 'node:crypto';
import { signRequest, CONTRACT_VERSION, TRANSPORT_VERSION } from './signing.js';

// Reenviador cola SQLite -> pasarela HTTPS (contrato tracer-http-v1, P2 rev. 1.2).
// Reglas clave:
//  - El ACK de este modulo es SOLO con el destino HTTPS. Hacia Tracer nunca se escribe un byte.
//  - Una fila solo pasa a `sent` si el destino la confirmo (insertada/duplicada) POR FILA.
//  - Timeout, red, 5xx, ACK invalido o fila sin confirmacion => esas filas pasan a `retry`
//    con espera propia; el resto de la cola sigue siendo elegible tras la pausa global.
//  - 400/401/403/409/429/503 => pausa global; la cola NO se toca.
//  - Un request en vuelo por origen. Nunca se descarta la cola por alcanzar N reintentos.
//  - Con atraso acumulado, el siguiente lote sale apenas se persisten los resultados (sin espera de 15 s).
//  - Retry-After se respeta SIN recortar (segundos o fecha HTTP) y la pausa sobrevive a reinicios.
//  - El cuerpo de TODA respuesta se lee por bytes con tope y se cancela al superarlo.
//  - 409 solo autoriza el reintento inmediato cuando el cuerpo es {"code":"REPLAY"}.
const ERROR_CODE = /^[A-Z][A-Z0-9_]{1,63}$/;

export class Forwarder {
  constructor({ spool, config, log = () => {}, fetchImpl = globalThis.fetch, now = () => Date.now(), random = Math.random }) {
    this.spool = spool;
    this.cfg = {
      maxRows: 500, maxBodyBytes: 524288, flushIntervalMs: 15000, requestTimeoutMs: 15000,
      drainDelayMs: 0, maxBackoffSeconds: 300, replayImmediateRetries: 2, haltedDelaySeconds: 900,
      authMinDelaySeconds: 60, disabledMinDelaySeconds: 60, maxResponseBytes: 1048576, ...config,
    };
    this.log = log;
    this.fetchImpl = fetchImpl;
    this.now = now;
    this.random = random;
    this.stopped = true;
    this.inFlight = false;
    this.current = Promise.resolve();
    this.timer = null;
    this.abort = null;
    this.consecutiveFailures = 0;
    this.lastSuccessAt = null;
    this.lastError = null;
    this.halted = null;
    this.pausedUntil = 0;   // epoch ms; persistido en la cola para respetar Retry-After tras un reinicio
    this.batchId = null;
    this.maxRowsNow = this.cfg.maxRows;
    this.goodBatchesSinceShrink = 0;
  }

  start() {
    if (!this.stopped) return;
    this.stopped = false;
    this.pausedUntil = Number(this.spool.getState('forwarder_paused_until') ?? 0) || 0;
    this.schedule(1000);
  }
  async stop() {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.abort?.abort();
    await this.current;
  }
  // setTimeout no admite mas de 2^31-1 ms: una espera mayor se parte en tramos, sin acortarla.
  schedule(ms) {
    if (this.stopped) return;
    if (this.timer) clearTimeout(this.timer);
    const MAX = 2 ** 31 - 1;
    const wait = Math.max(0, ms);
    this.timer = setTimeout(() => {
      this.timer = null;
      if (wait > MAX) this.schedule(wait - MAX); else this.current = this.tick();
    }, Math.min(wait, MAX));
    this.timer.unref?.();
  }
  async tick() {
    if (this.stopped || this.inFlight) return;
    this.inFlight = true;
    let delayMs;
    try { delayMs = await this.cycle(); }
    catch (e) {
      this.log('error', 'forwarder_internal_error', { message: e.message });
      delayMs = this.failure('INTERNAL_ERROR').delayMs;
    } finally { this.inFlight = false; }
    this.schedule(delayMs);
  }

  status() {
    return { enabled: true, environment: this.cfg.environment, consecutiveFailures: this.consecutiveFailures,
      lastSuccessAt: this.lastSuccessAt, lastError: this.lastError, halted: this.halted, maxRowsNow: this.maxRowsNow,
      pausedUntil: this.pausedUntil > this.now() ? new Date(this.pausedUntil).toISOString() : null };
  }

  // Un ciclo: toma un lote, lo envia y devuelve el retardo hasta el siguiente.
  async cycle() {
    const remaining = this.pausedUntil - this.now();
    if (remaining > 0) return remaining;   // pausa vigente (Retry-After / backoff / contrato detenido)
    const batch = this.spool.nextBatch({ limit: this.maxRowsNow, maxBytes: this.cfg.maxBodyBytes - 1024, now: this.now() });
    if (!batch.length) return this.cfg.flushIntervalMs;   // sin trabajo: no hay POST vacio
    return (await this.send(batch)).delayMs;
  }

  backoffSeconds(n) {
    const cap = Math.min(this.cfg.maxBackoffSeconds, 2 ** Math.min(20, Math.max(0, n - 1)));
    return Math.max(1, this.random() * cap);
  }
  // Pasa las filas del intento a `retry` con espera propia (jitter, tope 300 s).
  retryRows(rows, code) {
    this.spool.applyResults({ now: this.now(), retry: rows.map(r => ({
      seq: r.seq, code, nextRetryAt: this.now() + Math.round(this.backoffSeconds(this.spool.retryCount(r.seq) + 1) * 1000) })) });
  }
  failure(code, { retryAfterSeconds = 0, minDelaySeconds = 0, rows = null } = {}) {
    if (rows?.length) this.retryRows(rows, code);
    this.consecutiveFailures += 1;
    this.lastError = { code, at: new Date(this.now()).toISOString() };
    const seconds = Math.max(minDelaySeconds, retryAfterSeconds, this.backoffSeconds(this.consecutiveFailures));
    this.spool.count('forwarder_failures');
    this.log('warn', 'forwarder_failure', { code, consecutiveFailures: this.consecutiveFailures, retryInSeconds: Math.round(seconds) });
    const delayMs = Math.round(seconds * 1000);
    this.setPause(delayMs);
    return { ok: false, delayMs };
  }
  setPause(delayMs) {
    this.pausedUntil = delayMs > 0 ? this.now() + delayMs : 0;
    try { this.spool.setState('forwarder_paused_until', String(this.pausedUntil)); } catch { /* la pausa en memoria sigue vigente */ }
  }
  success(batchHasMore) {
    this.consecutiveFailures = 0;
    if (this.pausedUntil) this.setPause(0);
    this.halted = null;
    this.lastSuccessAt = new Date(this.now()).toISOString();
    if (this.maxRowsNow < this.cfg.maxRows && ++this.goodBatchesSinceShrink >= 10) {
      this.maxRowsNow = Math.min(this.cfg.maxRows, this.maxRowsNow * 2); this.goodBatchesSinceShrink = 0;
    }
    return { ok: true, delayMs: batchHasMore ? this.cfg.drainDelayMs : this.cfg.flushIntervalMs };
  }

  buildBody(batch) {
    this.batchId = crypto.randomUUID();   // solo correlacion del intento; no es clave de idempotencia
    const make = list => Buffer.from(JSON.stringify({
      contractVersion: CONTRACT_VERSION, transportVersion: TRANSPORT_VERSION,
      batchId: this.batchId, rows: list.map(r => r.payload),
    }), 'utf8');
    let rows = batch;
    let bodyBytes = make(rows);
    while (bodyBytes.length > this.cfg.maxBodyBytes && rows.length > 1) {
      rows = rows.slice(0, Math.max(1, Math.floor(rows.length / 2)));
      bodyBytes = make(rows);
    }
    return { rows, bodyBytes };
  }

  // Lee el cuerpo por BYTES con tope y cancela la descarga al superarlo (aplica a todo status).
  async readBounded(res) {
    const limit = this.cfg.maxResponseBytes;
    const declared = Number(res.headers.get('content-length'));
    if (Number.isFinite(declared) && declared > limit) { await res.body?.cancel().catch(() => {}); return { tooLarge: true, json: null }; }
    if (!res.body) return { tooLarge: false, json: null };
    const reader = res.body.getReader();
    const chunks = [];
    let total = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > limit) { await reader.cancel().catch(() => {}); return { tooLarge: true, json: null }; }
      chunks.push(value);
    }
    let json = null;
    try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* cuerpo no JSON */ }
    return { tooLarge: false, json };
  }

  async send(batch) {
    const started = this.now();
    for (let attempt = 0; ; attempt++) {
      const { rows, bodyBytes } = this.buildBody(batch);
      if (rows.length === 1 && bodyBytes.length > this.cfg.maxBodyBytes) {
        this.spool.applyResults({ quarantine: [{ seq: rows[0].seq, code: 'ROW_TOO_LARGE' }], now: this.now() });
        return this.success(true);
      }
      // Cada intento HTTP se firma de nuevo con timestamp y nonce nuevos.
      const headers = signRequest({ key: this.cfg.key, audience: this.cfg.audience, environment: this.cfg.environment,
        sourceId: this.cfg.sourceId, keyId: this.cfg.keyId, bodyBytes, now: this.now() });
      this.abort = new AbortController();
      const timeout = setTimeout(() => this.abort?.abort(new Error('TIMEOUT')), this.cfg.requestTimeoutMs);
      let res, json = null, tooLarge = false;
      try {
        res = await this.fetchImpl(this.cfg.url, {
          method: 'POST', redirect: 'error', body: bodyBytes, signal: this.abort.signal,
          headers: { ...headers, 'Content-Type': 'application/json' },
        });
        const body = await this.readBounded(res);
        tooLarge = body.tooLarge;
        json = body.json;
      } catch (e) {
        const timedOut = /TIMEOUT/.test(String(e?.message)) || /TIMEOUT/.test(String(e?.cause?.message)) || e?.name === 'TimeoutError';
        if (this.stopped) return { ok: false, delayMs: this.cfg.flushIntervalMs };   // apagado en curso: no marcar nada
        return this.failure(timedOut ? 'NETWORK_TIMEOUT' : 'NETWORK_ERROR', { rows });
      } finally { clearTimeout(timeout); this.abort = null; }

      this.spool.count('forwarder_http_' + res.status);
      const retryAfter = this.parseRetryAfter(res.headers.get('retry-after'));
      if (res.status === 200) {
        if (tooLarge) { this.log('warn', 'forwarder_ack_invalid', { reason: 'oversized' }); return this.failure('ACK_INVALID', { rows }); }
        return this.handleAck(rows, json, started);
      }
      if (res.status === 409) {
        if (json?.code === 'REPLAY') {
          // Solo REPLAY autoriza reintento inmediato (nonce/timestamp nuevos), y solo sin Retry-After positivo.
          if (retryAfter <= 0 && attempt < this.cfg.replayImmediateRetries) continue;
          return this.failure('REPLAY', { retryAfterSeconds: retryAfter });
        }
        // 409 de causa desconocida: NO se asume repeticion de nonce. Contrato detenido y alerta.
        this.halted = { code: 'HTTP_409_UNKNOWN', since: new Date(this.now()).toISOString() };
        return this.failure('HTTP_409_UNKNOWN', { minDelaySeconds: this.cfg.haltedDelaySeconds, retryAfterSeconds: retryAfter });
      }
      if (res.status === 413) {
        if (rows.length === 1) {
          this.spool.applyResults({ quarantine: [{ seq: rows[0].seq, code: 'PAYLOAD_TOO_LARGE' }], now: this.now() });
          return this.success(true);
        }
        this.maxRowsNow = Math.max(1, Math.floor(rows.length / 2));   // dividir; no cuarentenar el lote entero
        this.goodBatchesSinceShrink = 0;
        this.log('warn', 'forwarder_split_batch', { rows: rows.length, nextMaxRows: this.maxRowsNow });
        return { ok: false, delayMs: 0 };
      }
      if (res.status === 429) return this.failure('RATE_LIMITED', { retryAfterSeconds: retryAfter });
      if (res.status === 401 || res.status === 403) return this.failure('AUTH_' + res.status, { minDelaySeconds: this.cfg.authMinDelaySeconds, retryAfterSeconds: retryAfter });
      if (res.status === 503) return this.failure(json?.code === 'INGEST_DISABLED' ? 'INGEST_DISABLED' : 'UNAVAILABLE', { minDelaySeconds: this.cfg.disabledMinDelaySeconds, retryAfterSeconds: retryAfter });
      if (res.status >= 500 || res.status === 408 || res.status === 425) return this.failure('HTTP_' + res.status, { retryAfterSeconds: retryAfter, rows });
      // 400 y demas 4xx: el contrato/envoltorio no es aceptado. Se pausa y se alerta; la cola NO se toca.
      this.halted = { code: 'HTTP_' + res.status, since: new Date(this.now()).toISOString() };
      return this.failure('HTTP_' + res.status, { minDelaySeconds: this.cfg.haltedDelaySeconds, retryAfterSeconds: retryAfter });
    }
  }

  // Segundos o fecha HTTP. NUNCA se recorta: el techo de 300 s del backoff no limita Retry-After.
  parseRetryAfter(value) {
    if (!value) return 0;
    if (/^\d+$/.test(value)) return Number(value);
    const t = Date.parse(value);
    return Number.isFinite(t) ? Math.max(0, (t - this.now()) / 1000) : 0;
  }

  // Valida el ACK completo antes de tocar una fila. Una fila sin confirmacion individual
  // valida pasa a retry (reenviar es seguro por hash).
  handleAck(rows, json, started) {
    if (!json || json.ackVersion !== '1' || json.batchId !== this.batchId || !Array.isArray(json.rows)) {
      this.log('warn', 'forwarder_ack_invalid', { reason: 'shape' });
      return this.failure('ACK_INVALID', { rows });
    }
    const seen = new Set();
    for (const e of json.rows) {
      if (!e || !Number.isInteger(e.index) || e.index < 0 || e.index >= rows.length || seen.has(e.index)) {
        this.log('warn', 'forwarder_ack_invalid', { reason: 'index' });
        return this.failure('ACK_INVALID', { rows });
      }
      seen.add(e.index);
    }
    const sent = [], retry = [], quarantine = [];
    const unconfirmed = rows.filter((_, i) => !seen.has(i));
    for (const e of json.rows) {
      const row = rows[e.index];
      const hashOk = e.hash === row.hash;
      if (e.hash != null && !hashOk) { unconfirmed.push(row); continue; }
      if (e.status === 'insertada' || e.status === 'duplicada') {
        if (hashOk) sent.push(row.seq); else unconfirmed.push(row);
      } else if (e.status === 'rechazada') {
        const code = typeof e.code === 'string' && ERROR_CODE.test(e.code) ? e.code : 'REJECTED_UNSPECIFIED';
        if (e.permanent === true) quarantine.push({ seq: row.seq, code });
        else if (e.permanent === false) {
          retry.push({ seq: row.seq, code, nextRetryAt: this.now() + Math.round(this.backoffSeconds(this.spool.retryCount(row.seq) + 1) * 1000) });
        } else unconfirmed.push(row);
      } else unconfirmed.push(row);
    }
    for (const row of unconfirmed) {
      retry.push({ seq: row.seq, code: 'ACK_UNCONFIRMED', nextRetryAt: this.now() + Math.round(this.backoffSeconds(this.spool.retryCount(row.seq) + 1) * 1000) });
    }
    const applied = this.spool.applyResults({ sent, retry, quarantine, now: this.now() });
    this.spool.count('forwarder_batches');
    if (unconfirmed.length) this.spool.count('forwarder_rows_unconfirmed', unconfirmed.length);
    this.log('info', 'forwarder_batch', { rows: rows.length, ...applied, unconfirmed: unconfirmed.length, ms: this.now() - started });
    if (!applied.sent && !applied.quarantine) return this.failure('ACK_NO_PROGRESS');   // nada confirmado: pausa global
    const more = this.spool.nextBatch({ limit: 1, maxBytes: this.cfg.maxBodyBytes, now: this.now() }).length > 0;
    return this.success(more);
  }
}
