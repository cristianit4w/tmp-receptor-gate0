# v0.2.0 — reenviador HTTPS, cuarentena local y diagnostico desactivable

**Estado: codigo y pruebas locales. NO desplegado. El reenviador viene APAGADO y no se conecta a ningun destino.**
Basado en el contrato `CONTRATO_HTTPS_P2_PRECISADO.md` (rev. 1.2) y `02_CONTRATO_DATOS_RECEPTOR_v2.md`
(SHA-256 `0d2cf62e7f400352aba6a2067ee513830c6b83dde14f78b599a3202132d4ba60`).

## Que cambia respecto de v0.1.2

| Area | Cambio |
|---|---|
| Cola SQLite | Nuevo estado `quarantine` y columnas `sent_at`, `quarantined_at`, `quarantine_code`, `last_error_code`. Migracion idempotente que **reconstruye la tabla** dentro de una transaccion (SQLite no permite cambiar un CHECK con ALTER), verifica conteos y conserva `seq`, hash, payload, estados, reintentos y el contador AUTOINCREMENT. Rollback si algo falla. |
| Reenviador | `src/forwarder.js`: lotes de hasta 500 filas / 512 KiB, firma HMAC-SHA-256 (`TRACER-HMAC-V1`), un request en vuelo, ACK **por fila**, backoff con jitter 1..300 s, `Retry-After`, 413 parte el lote, 409 firma de nuevo, 401/403/429/503/400 pausan sin tocar la cola. Con atraso acumulado el siguiente lote sale sin esperar los 15 s. |
| Confirmacion por fila | `insertada`/`duplicada` -> `sent`. `rechazada` permanente -> `quarantine` (no bloquea el resto). `rechazada` transitoria, timeout, red, 5xx, ACK invalido o fila sin confirmar -> `retry` con espera propia. |
| Retencion local | `sent` 72 h desde `sent_at`; `quarantine` 7 dias desde `quarantined_at`; poda diaria (y una vez 5 min despues de arrancar). Nunca se podan `pending`/`retry`. Sin reloj de transicion la fila se conserva y se audita. |
| Configuracion | `src/config.js` valida TODO antes de abrir puertos. `RECEIVER_MODE=gate0` conserva v0.1.2; `standard` permite `DIAGNOSTIC_MODE=false`. Perfiles `staging`/`production` con los literales exactos del contrato; sin alias `prod`; sin fallback a produccion. |
| Clave HMAC | Solo desde **archivo** (`FORWARDER_KEY_FILE`, hex o base64url, >= 32 bytes, permisos 0640/0600). Nunca desde variable de entorno ni en logs. |
| Seguridad de arranque | Reenviador apagado salvo `FORWARDER_ENABLED=true`. Produccion exige ademas `FORWARDER_PRODUCTION_AUTHORIZATION=G5`. Staging exige un spool aparte (`staging*`). |
| Salud | `/live` incluye `forwarder{...}` y la alerta `FORWARDER_STALLED` (contrato detenido o >= 5 fallos seguidos). `queueDepth` = pending + retry. |
| Herramientas | `bin/migrate.js` (respaldo consistente + migracion + verificacion), `bin/quarantine.js` (resumen / reproceso EXPRESO y auditado), `bin/mock-ingest.js` (destino simulado). `bin/stats.js` no migra. |

## Que NO cambia
Protocolo PC, parser, hash, deduplicacion por hash, **cero bytes de respuesta a Tracer** (ahora tambien con test automatico), limites de conexion, ALLOWED_SOURCES, puertos.

## Pruebas (local, Node 24; en la VM correr con Node 22)
89 pruebas en verde: las 41 de v0.1.2 + 48 nuevas (firma con vector publico generado en Python, migracion desde v0.1.1/v0.1.2, rollback, poda, cuarentena, 17 escenarios del reenviador contra un destino simulado, configuracion y extremo a extremo TCP -> HTTPS).
Verificado aparte: **v0.1.2 puede abrir una cola ya migrada** (reversa segura).

## Que NO esta probado ni hecho
- No hay destino real: no se probo contra Supabase/Vercel, ni la verificacion HMAC del lado servidor.
- No se desplego en la VM ni se toco produccion.
- Capacidad: el tope de cola sigue siendo el de `MAX_SPOOL_BYTES`; no se certifico para 72 h de `sent` a 40.000 filas/dia (ver RUNBOOK §Capacidad).
