import test from 'node:test';import assert from 'node:assert/strict';import net from 'node:net';import fs from 'node:fs';
import { startReceiver } from '../src/server.js';
import { createSyntheticPC } from '../src/parser.js';
import { startMockIngest } from '../src/mockIngest.js';
import { KEY, PROFILE, tmp, waitFor } from './helpers/util.js';

function tcpSession(port, data) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(port, '127.0.0.1');
    let received = Buffer.alloc(0);
    const timer = setTimeout(() => { socket.destroy(); reject(new Error('timeout')); }, 3000);
    socket.on('connect', () => { socket.write(data); socket.end(); });
    socket.on('data', b => received = Buffer.concat([received, b]));
    socket.on('error', reject);
    socket.on('close', () => { clearTimeout(timer); resolve(received); });
  });
}

test('extremo a extremo: Tracer (TCP) -> cola -> HTTPS firmado -> sent; JAMAS un byte de vuelta a Tracer', async () => {
  const t = tmp();
  const mock = await startMockIngest({ key: KEY, ...PROFILE });
  let r;
  try {
    r = startReceiver({
      host: '127.0.0.1', port: 0, healthPort: 0, sqlitePath: t.file('staging-spool.sqlite'), diagnostics: false, idleTimeoutMs: 2000,
      forwarder: { ...PROFILE, key: KEY, url: mock.url, flushIntervalMs: 50, requestTimeoutMs: 2000 }, firstPruneDelayMs: 3600000,
    });
    await new Promise(resolve => r.tcp.once('listening', resolve));
    const port = r.tcp.address().port;
    const frames = Buffer.concat(['01', '03', '09'].map((ev, i) => createSyntheticPC({ event: ev, time: '15300' + i, plate: 'SYN00' + i })));
    const back = await tcpSession(port, frames);
    assert.equal(back.length, 0, 'ningun ACK de aplicacion hacia Tracer');
    await waitFor(() => r.spool.stats().sentRetained === 3);
    assert.equal(r.spool.stats().queueDepth, 0);
    assert.equal(mock.store.size, 3);
    assert.ok(mock.requests.every(q => q.auth.sigOk));
    const back2 = await tcpSession(port, frames);   // reenvio fisico del proveedor: duplicados, nada nuevo
    assert.equal(back2.length, 0);
  } finally { if (r) await r.close(); await mock.close(); t.destroy(); }
});

test('la recepcion TCP sigue funcionando aunque el destino HTTPS este caido', async () => {
  const t = tmp();
  const mock = await startMockIngest({ key: KEY, ...PROFILE, fault: () => ({ status: 503, body: { code: 'INGEST_DISABLED' } }) });
  let r;
  try {
    r = startReceiver({
      host: '127.0.0.1', port: 0, healthPort: 0, sqlitePath: t.file('staging-spool.sqlite'), diagnostics: false, idleTimeoutMs: 2000,
      forwarder: { ...PROFILE, key: KEY, url: mock.url, flushIntervalMs: 50, requestTimeoutMs: 2000 }, firstPruneDelayMs: 3600000,
    });
    await new Promise(resolve => r.tcp.once('listening', resolve));
    const back = await tcpSession(r.tcp.address().port, createSyntheticPC());
    assert.equal(back.length, 0);
    await waitFor(() => r.forwarder.status().lastError?.code === 'INGEST_DISABLED');
    assert.equal(r.spool.stats().queueDepth, 1, 'se conserva en la cola');
    const live = await fetch(`http://127.0.0.1:${r.health.address().port}/live`).then(x => x.json());
    assert.equal(live.forwarder.enabled, true);
    assert.equal(live.forwarder.environment, 'staging');
    assert.equal(live.queueDepth, 1);
  } finally { if (r) await r.close(); await mock.close(); t.destroy(); }
});

test('sin reenviador configurado, /live lo informa apagado y la cola solo acumula', async () => {
  const t = tmp();
  let r;
  try {
    r = startReceiver({ host: '127.0.0.1', port: 0, healthPort: 0, sqlitePath: t.file('q.sqlite'), diagnostics: false, idleTimeoutMs: 2000 });
    await new Promise(resolve => r.tcp.once('listening', resolve));
    await tcpSession(r.tcp.address().port, createSyntheticPC());
    const live = await fetch(`http://127.0.0.1:${r.health.address().port}/live`).then(x => x.json());
    assert.deepEqual(live.forwarder, { enabled: false });
    assert.equal(live.mode, 'DIAGNOSTIC_LOCAL_ONLY');
    assert.equal(r.forwarder, null);
  } finally { if (r) await r.close(); t.destroy(); }
});

test('el codigo del reenviador no escribe jamas en sockets de Tracer', () => {
  const src = fs.readFileSync(new URL('../src/forwarder.js', import.meta.url), 'utf8');
  assert.ok(!/socket\.(write|end)\(/.test(src));
  const srv = fs.readFileSync(new URL('../src/server.js', import.meta.url), 'utf8');
  assert.ok(!/socket\.(write|end)\([^)]/.test(srv.replace(/\/\/.*$/gm, '')), 'server.js sin socket.write/end con datos');
});
