# v0.2.3 — Posiciones REALES al staging (espejo + reenviador de staging)

**Decisión de Cristian (21/10/2026):** probar el monitoreo en vivo con los camiones reales usando el staging que ya existe, sin crear nada nuevo.
Esto NO es producción (G4/G5 siguen pendientes) y NO toca el receptor real ni su spool.

## Cómo funciona
```
Tracer -> receptor de PRODUCCION (sin cambios, reenviador OFF) -> spool.sqlite
                                                   | (solo lectura, cada 5 s)
                                                   v
                                    tracer-mirror-staging.service
                                                   v
                                   staging-spool.sqlite (copia aparte)
                                                   v
                       tracer-forwarder-staging.service (perfil staging, firmado)
                                                   v
        https://bymones-tracer-staging.vercel.app -> Supabase staging -> mapa interno
```
- El receptor de producción no se reinicia ni cambia de configuración.
- El espejo abre el spool de producción en **solo lectura** (no cambia estados, no borra).
- El reenviador de staging es otra instancia (escucha solo en 127.0.0.1:41874, puerto no expuesto) y solo drena `staging-spool.sqlite`.
- Las patentes del laboratorio (`SYN###`) las rechaza la base y quedan en cuarentena local; no llegan al mapa.

## Instalación (sobre la VM, con v0.2.1 o v0.2.2 corriendo)
1. Verificar SHA-256 del paquete y extraer en `/opt/tracer-receptor/releases/0.2.3` (`--strip-components=1`, `chown -R root:root`).
2. Pruebas: `sudo -u tracerrx node --test --test-concurrency=1 /opt/tracer-receptor/releases/0.2.3/test/*.test.js` -> `fail 0`.
3. Crear `/etc/tracer-receptor/forwarder-staging.env` (copiar `systemd/forwarder-staging.env.example`, `0640 root:tracerrx`).
4. Crear `/etc/tracer-receptor/forwarder-staging.key` con la clave de staging (hex de 64 caracteres, `0640 root:tracerrx`). **La escribe Cristian**.
5. Copiar las dos unidades a `/etc/systemd/system/`, `systemctl daemon-reload`.
6. **No** cambiar `current` del receptor de producción: las dos unidades nuevas ya apuntan directo a `/opt/tracer-receptor/releases/0.2.3`; el receptor real sigue en su versión.
7. `systemctl enable --now tracer-forwarder-staging` y luego `tracer-mirror-staging`.

## Apagar / revertir (en segundos)
- `systemctl disable --now tracer-mirror-staging tracer-forwarder-staging` (el receptor real no se entera).
- Kill switch en la base: script 5.
- Borrar `staging-spool.sqlite*` y `forwarder-staging.key` deja todo como antes.

## Qué mirar
- `curl -s localhost:9091/live` (forwarder staging): `sent` sube, `quarantine` = patentes SYN.
- `journalctl -u tracer-mirror-staging -n 20`: `mirror_batch` con `behind` bajando a 0.
- `/live` del receptor real (puerto 9090): debe seguir igual y la cola real creciendo.

