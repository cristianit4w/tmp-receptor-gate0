# RUNBOOK 0.2.0 -> 0.2.1 (NO ejecutar sin autorizacion)

La VM ya corre 0.2.0 con el reenviador apagado: **no hay urgencia** (las correcciones solo afectan al reenviador). Se instala junto con el ensayo G3.
No hace falta migrar la cola: el esquema es el mismo; 0.2.1 solo agrega la tabla `forwarder_state` (CREATE IF NOT EXISTS, sin tocar filas).

1. Snapshot previo (opcional si ya hay uno reciente) y verificar SHA-256 del paquete.
2. `sudo install -d -m 0755 /opt/tracer-receptor/releases/0.2.1` y extraer el paquete con `--strip-components=1`; `chown -R root:root`.
3. Pruebas en la VM (Node 22), desde `/`: `sudo -u tracerrx node --test --test-concurrency=1 /opt/tracer-receptor/releases/0.2.1/test/*.test.js` -> `fail 0`.
4. Cambio de version con reversa automatica si no arranca (igual que en el RUNBOOK de 0.2.0): guardar `PREV=$(readlink /opt/tracer-receptor/current)`, apuntar `current` a 0.2.1, reiniciar, y si no esta activo en 4 s volver a `$PREV`.
5. Verificar `/live` (`forwarder.enabled:false`, `mode:LOCAL_QUEUE_ONLY`) y que la cola siga creciendo.
Reversa: `current` -> `releases/0.2.0`; la tabla nueva es inocua.
