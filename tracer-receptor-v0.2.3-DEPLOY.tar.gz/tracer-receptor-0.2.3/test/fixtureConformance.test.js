import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
import { parsePC } from '../src/parser.js';
import { FrameDecoder } from '../src/decoder.js';
import { Spool } from '../src/spool.js';
import { startReceiver } from '../src/server.js';
import { assertConformanceFixture } from '../src/fixtureGate.js';

const fixturePath = fileURLToPath(new URL('../fixtures/Ejemplo_paquetes_SANITIZADO.txt', import.meta.url));
const raw = fs.readFileSync(fixturePath);
const frames = raw.toString('ascii').split('|').slice(0, -1).map(f => Buffer.from(f + '|', 'ascii'));
const parsed = frames.map(parsePC);

// Bloqueo obligatorio de layout: falla npm test si cambia un solo offset/largo.
test('CONFORMIDAD: 12 PC concatenados, 708 bytes, cero saltos, ASCII, terminador |', () => {
  assert.equal(raw.length, 708);
  assert.equal(raw.includes(0x0a) || raw.includes(0x0d), false);
  assert.equal(raw.at(-1), 0x7c);
  assert.equal(raw.filter(b => b === 0x7c).length, 12);
  assert.equal(frames.length, 12);
  for(const f of frames) {
    assert.equal(f.length, 59);
    assert.equal(f.subarray(0,2).toString('ascii'), 'PC');
    for(const b of f) assert.ok(b >= 32 && b <= 126);
  }
});
test('CONFORMIDAD: patentes sinteticas de 6 caracteres con padding izquierdo', () => {
  const counts = {};
  for (const p of parsed) {
    assert.match(p.plateRaw, /^ AAA00[123]$/);
    assert.equal(p.plateRaw.length, 7);
    counts[p.plate] = (counts[p.plate] ?? 0) + 1;
  }
  assert.deepEqual(counts, {AAA001:4, AAA002:5, AAA003:3});
});
test('CONFORMIDAD: año 18 interpretado 2018 UTC, sin heuristica siglo', () => {
  assert.equal(parsed[0].reportedAt, '2018-09-06T19:21:37.000Z');
  assert.equal(parsed[4].reportedAt, '2018-09-06T18:36:55.000Z');
  assert.ok(parsed.every(p => p.reportedAt.startsWith('2018-09-06T')));
});
test('CONFORMIDAD: +99 como null, CRUDO preservado y supuesto no confirmado', () => {
  for (const p of parsed) {
    assert.deepEqual(p.temperatures, [null,null,null]);
    assert.deepEqual(p.temperatureRaw, ['+99','+99','+99']);
    assert.equal(p.temperatureSentinelAssumption, 'PLUS_99_NO_SENSOR_UNCONFIRMED');
  }
  assert.deepEqual(parsePC(Buffer.from(frames[0].toString('ascii').slice(0,49) + '+99-99+01|','ascii')).temperatures, [null,-99,1]);
});
test('CONFORMIDAD: segundo grupo inicia evento 03 (AAA002)', () => {
  assert.equal(parsed[4].plate, 'AAA002');
  assert.equal(parsed[4].eventCode, '03');
  assert.equal(parsed.filter(p=>p.eventCode === '03').length, 1);
});
test('CONFORMIDAD: grupos sin orden cronologico global; preservar orden por patente', () => {
  const stamps=parsed.map(p=>Date.parse(p.reportedAt));
  assert.ok(stamps[4] < stamps[3]);
  assert.ok(stamps[9] < stamps[8]);
  for(const [a,b] of [[0,4],[4,9],[9,12]])
    assert.ok(parsed.slice(a,b).every((p,i,list)=>i===0||p.reportedAt>=list[i-1].reportedAt));
});
test('CONFORMIDAD: hash canonico por reporte, sin perder precision ni ordenar entre placas', () => {
  assert.equal(new Set(parsed.map(p => p.hash)).size, 12);
  assert.notEqual(parsed[3].hash, parsed[4].hash);
  assert.equal(frames[3].subarray(14,21).toString('ascii'), ' AAA001');
  assert.equal(frames[4].subarray(14,21).toString('ascii'), ' AAA002');
});
test('CONFORMIDAD: decoder por | conserva 12 frames con chunks arbitrarios y EOF', () => {
  for(const size of [1,2,7,59,60,91,708]) {
    const got=[],errors=[];
    const d=new FrameDecoder({onFrame:f=>got.push(f),onError:e=>errors.push(e.code)});
    for(let i=0;i<raw.length;i+=size)d.feed(raw.subarray(i,i+size));
    d.eof();
    assert.equal(got.length,12);
    assert.deepEqual(errors,[]);
    assert.deepEqual(Buffer.concat(got),raw);
  }
});
test('CONFORMIDAD: SQLite preserva 12 mensajes y relojes por patente', () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-conform-'));
  let s;
  try {
    s=new Spool(path.join(dir,'queue.sqlite'),{diagnostics:true});
    for (let i=0;i<parsed.length;i++) assert.equal(s.ingest(parsed[i],{rawFrame:frames[i]}),'stored');
    assert.equal(s.stats().queueDepth,12);
    assert.equal(s.stats().counters.stored,12);
    assert.equal(s.db.prepare('SELECT COUNT(*) n FROM raw_diagnostic').get().n,12);
    assert.deepEqual(s.db.prepare('SELECT plate, COUNT(*) n FROM spool GROUP BY plate ORDER BY plate').all().map(x=>[x.plate,x.n]), [['AAA001',4],['AAA002',5],['AAA003',3]]);
    assert.equal(s.last('AAA001').last_reported_at,'2018-09-06T19:30:37.000Z');
    assert.equal(s.last('AAA002').last_reported_at,'2018-09-06T19:28:36.000Z');
    assert.equal(s.last('AAA003').last_reported_at,'2018-09-06T19:18:21.000Z');
    assert.equal(s.db.prepare('SELECT COUNT(*) n FROM spool WHERE event_code=?').get('03').n,1);
    s.close();s=null;
    s=new Spool(path.join(dir,'queue.sqlite'));
    assert.equal(s.stats().queueDepth,12);
    assert.equal(s.ingest(parsed[0]),'duplicate');
    assert.equal(s.stats().queueDepth,12);
  } finally {s?.close();fs.rmSync(dir,{recursive:true,force:true});}
});
function send(port, framesToSend) {
  return new Promise((resolve,reject)=>{
    const sock=net.connect(port,'127.0.0.1');let read=0;let finished=false;
    const timer=setTimeout(()=>{sock.destroy();reject(Error('connection timeout'))},4000);
    sock.on('connect',()=>{ const b=Buffer.concat(framesToSend); for(let p=0;p<b.length;p+=7)sock.write(b.subarray(p,p+7));sock.end(); });
    sock.on('data',x=>{read+=x.length;});
    sock.on('error',e=>{if(!finished){finished=true;clearTimeout(timer);reject(e);}});
    sock.on('close',()=>{if(!finished){finished=true;clearTimeout(timer);resolve(read);}});
  });
}
test('CONFORMIDAD: 3 conexiones por grupos (4+5+3), 708 bytes y 0 ACK', async () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-conform-tcp-'));
  const receiver=startReceiver({host:'127.0.0.1',port:0,sqlitePath:path.join(dir,'q.sqlite'),healthPort:0,diagnostics:false,idleTimeoutMs:2000});
  try {
    await new Promise(resolve=>receiver.tcp.once('listening',resolve));
    const port=receiver.tcp.address().port;
    for(const [start,end] of [[0,4],[4,9],[9,12]])assert.equal(await send(port,frames.slice(start,end)),0);
    await new Promise(resolve=>setTimeout(resolve,30));
    const stats=receiver.spool.stats();
    assert.equal(stats.queueDepth,12);
    assert.equal(stats.counters.stored,12);
    assert.equal(stats.counters.frames_valid,12);
    assert.equal(stats.counters.bytes_received,708);
    assert.equal(stats.counters.batches_completed,3);
  }finally{await receiver.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('GATE de arranque: fixture oficial sanitizado validado antes de escuchar TCP', () => {
  const r=assertConformanceFixture();
  assert.deepEqual(r.groups,[4,5,3]);
  assert.equal(r.frames,12);
});
test('GATE de arranque falla cerrado si el fixture fue alterado', () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-fixture-tamper-'));
  try {
    const f=path.join(dir,'fixture.txt');
    const corrupted=Buffer.from(raw);corrupted[20]=0x39;
    fs.writeFileSync(f,corrupted);
    assert.throws(()=>assertConformanceFixture(f),/GATE0_CONFORMANCE_FIXTURE_FAILED/);
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
});
