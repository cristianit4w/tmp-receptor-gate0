import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { Spool } from '../src/spool.js';
import { Mirror, assertMirrorPaths } from '../src/mirror.js';
import { createSyntheticPC, parsePC } from '../src/parser.js';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'mirror-'));
function fill(spool, n, offset = 0) {
  for (let i = 0; i < n; i++) {
    const t = offset + i;
    const row = parsePC(createSyntheticPC({ time: '1' + String(Math.floor(t / 3600)).padStart(1, '0') + String(Math.floor((t % 3600) / 60)).padStart(2, '0') + String(t % 60).padStart(2, '0'), plate: 'AB' + String(100 + (t % 50)).padStart(3, '0') + 'C' }));
    const receivedAt = new Date(1760961600000 + t * 1000).toISOString();
    spool.insert.run(row.hash, receivedAt, row.reportedAt, row.plate, row.gpsValid ? 1 : 0, row.eventCode, row.eventKnown ? 1 : 0, JSON.stringify(row));
  }
}

test('rutas: exige destino "staging*", distinto del origen y origen que no sea de staging', () => {
  const d = tmp(); const src = path.join(d, 'spool.sqlite'); fs.writeFileSync(src, '');
  assert.throws(() => assertMirrorPaths(src, path.join(d, 'spool.sqlite')), /differ/);
  assert.throws(() => assertMirrorPaths(src, path.join(d, 'otro.sqlite')), /staging/);
  assert.throws(() => assertMirrorPaths(path.join(d, 'staging-a.sqlite'), path.join(d, 'staging-b.sqlite')), /production spool/);
  assert.throws(() => assertMirrorPaths(path.join(d, 'no-existe.sqlite'), path.join(d, 'staging-x.sqlite')), /does not exist/);
  assert.doesNotThrow(() => assertMirrorPaths(src, path.join(d, 'staging-spool.sqlite')));
});

test('copia por lotes con cursor, es idempotente y NO modifica el spool de origen', () => {
  const d = tmp(); const srcPath = path.join(d, 'spool.sqlite'); const dstPath = path.join(d, 'staging-spool.sqlite');
  const prod = new Spool(srcPath); fill(prod, 2500);
  const before = prod.db.prepare("SELECT COUNT(*) n, SUM(CASE WHEN state='pending' THEN 1 ELSE 0 END) p, MAX(seq) m FROM spool").get();
  const m = new Mirror({ sourcePath: srcPath, targetPath: dstPath, batch: 1000 });
  let r = m.once(); assert.deepEqual([r.copied, r.inserted, r.behind], [1000, 1000, 1500]);
  r = m.once(); assert.deepEqual([r.copied, r.inserted, r.behind], [1000, 1000, 500]);
  r = m.once(); assert.deepEqual([r.copied, r.inserted, r.behind], [500, 500, 0]);
  r = m.once(); assert.deepEqual([r.copied, r.inserted], [0, 0]);
  const dst = new DatabaseSync(dstPath);
  assert.equal(dst.prepare('SELECT COUNT(*) n FROM spool').get().n, 2500);
  assert.equal(dst.prepare("SELECT COUNT(*) n FROM spool WHERE state='pending'").get().n, 2500);
  const after = prod.db.prepare("SELECT COUNT(*) n, SUM(CASE WHEN state='pending' THEN 1 ELSE 0 END) p, MAX(seq) m FROM spool").get();
  assert.deepEqual({ ...after }, { ...before }, 'el origen no cambio');
  // filas nuevas en produccion mientras corre el espejo
  fill(prod, 40, 5000);
  r = m.once(); assert.deepEqual([r.copied, r.inserted], [40, 40]);
  // cursor perdido: se vuelve a recorrer todo pero el hash unico evita duplicados
  m.target.setState('mirror_last_seq', 0);
  let ins = 0; for (let i = 0; i < 4; i++) ins += m.once().inserted;
  assert.equal(ins, 0); assert.equal(dst.prepare('SELECT COUNT(*) n FROM spool').get().n, 2540);
  m.close(); prod.close(); dst.close();
});

test('el espejo no escribe en el origen aunque se lo intente (conexion de solo lectura)', () => {
  const d = tmp(); const srcPath = path.join(d, 'spool.sqlite');
  const prod = new Spool(srcPath); fill(prod, 3);
  const m = new Mirror({ sourcePath: srcPath, targetPath: path.join(d, 'staging-spool.sqlite') });
  assert.throws(() => m.src.exec("UPDATE spool SET state='sent'"), /readonly|read-only|attempt to write/i);
  m.close(); prod.close();
});

test('origen reemplazado (cursor mayor al maximo): se reinicia el cursor y no se duplica', () => {
  const d = tmp(); const srcPath = path.join(d, 'spool.sqlite');
  const prod = new Spool(srcPath); fill(prod, 10);
  const m = new Mirror({ sourcePath: srcPath, targetPath: path.join(d, 'staging-spool.sqlite') });
  m.target.setState('mirror_last_seq', 99999);
  const r = m.once(); assert.equal(r.copied, 10); assert.equal(r.inserted, 10);
  m.close(); prod.close();
});

test('el reenviador de staging drena lo espejado (nextBatch ve las filas como pending)', () => {
  const d = tmp(); const srcPath = path.join(d, 'spool.sqlite'); const dstPath = path.join(d, 'staging-spool.sqlite');
  const prod = new Spool(srcPath); fill(prod, 20);
  const m = new Mirror({ sourcePath: srcPath, targetPath: dstPath }); m.once();
  const b = m.target.nextBatch({ limit: 500 });
  assert.equal(b.length, 20); assert.ok(b.every(x => x.payload.hash === x.hash));
  m.close(); prod.close();
});
