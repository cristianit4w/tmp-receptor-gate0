import test from 'node:test';import assert from 'node:assert/strict';
import { Spool } from '../src/spool.js';
import { Forwarder } from '../src/forwarder.js';
import { startMockIngest } from '../src/mockIngest.js';
import { KEY, PROFILE, tmp, syntheticParsed, waitFor } from './helpers/util.js';

const T0 = Date.parse('2026-10-20T12:00:00Z');

// Entorno de prueba: spool real + destino simulado + reloj controlado (determinista).
async function setup({ rows = 5, fault = null, cfg = {} } = {}) {
  const t = tmp();
  const clock = { t: T0 };
  const spool = new Spool(t.file('staging-spool.sqlite'));
  for (let i = 0; i < rows; i++) spool.ingest(syntheticParsed(i), { receivedAt: new Date(T0 - 60000 + i).toISOString() });
  const mock = await startMockIngest({ key: KEY, ...PROFILE, fault, now: () => clock.t });
  const logs = [];
  const fw = new Forwarder({
    spool, log: (l, e, d) => logs.push({ l, e, ...d }), now: () => clock.t, random: () => 0.5,
    config: { ...PROFILE, key: KEY, url: mock.url, requestTimeoutMs: 2000, ...cfg },
  });
  fw.stopped = false;   // los tests llaman cycle() directamente: el reenviador esta "activo" sin temporizador
  const env = { t, clock, spool, mock, fw, logs,
    states: () => Object.fromEntries(env.spool.db.prepare('SELECT state, COUNT(*) n FROM spool GROUP BY 1').all().map(r => [r.state, r.n])),
    async done() { await env.fw.stop(); await mock.close(); env.spool.close(); t.destroy(); } };
  return env;
}

test('camino feliz: lote firmado y verificado, 16 claves, fila a fila sent; sin trabajo no hay POST', async () => {
  const e = await setup({ rows: 5 });
  try {
    const delay = await e.fw.cycle();
    assert.equal(delay, 15000, 'sin mas trabajo: espera del regimen estable');
    const req = e.mock.requests[0];
    assert.equal(req.auth.sigOk, true);
    assert.equal(req.method, 'POST');
    assert.equal(req.headers['content-type'], 'application/json');
    assert.equal(req.rows, 5);
    assert.deepEqual(e.states(), { sent: 5 });
    assert.equal(e.mock.store.size, 5);
    const stored = [...e.mock.store.values()][0];
    assert.equal(Object.keys(stored).length, 16);
    assert.equal(stored.receivedAt, new Date(T0 - 60000).toISOString());
    await e.fw.cycle();
    assert.equal(e.mock.requests.length, 1, 'cola vacia => ningun POST vacio');
    assert.ok(e.fw.status().lastSuccessAt);
  } finally { await e.done(); }
});

test('el destino que ya tiene las filas responde duplicada: tambien pasan a sent', async () => {
  const e = await setup({ rows: 3 });
  try {
    await e.fw.cycle();
    e.spool.db.exec("UPDATE spool SET state='pending',sent_at=NULL");   // simula ACK perdido tras commit
    await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 3 });
    assert.equal(e.mock.store.size, 3, 'sin duplicar efectos');
  } finally { await e.done(); }
});

test('rechazo permanente => quarantine con codigo, sin bloquear a las demas; transitorio => retry con espera propia', async () => {
  const fault = Object.assign(() => undefined, {
    rowStatus: (row, i) => i === 1 ? { status: 'rechazada', permanent: true, code: 'INVALID_COORDINATES' }
      : i === 2 ? { status: 'rechazada', permanent: false, code: 'DB_BUSY' } : null,
  });
  const e = await setup({ rows: 5, fault });
  try {
    await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 3, quarantine: 1, retry: 1 });
    assert.equal(e.spool.quarantineSummary()[0].code, 'INVALID_COORDINATES');
    const r = e.spool.db.prepare("SELECT retry_count,next_retry_at,last_error_code FROM spool WHERE state='retry'").get();
    assert.equal(r.retry_count, 1);
    assert.equal(r.last_error_code, 'DB_BUSY');
    assert.ok(Date.parse(r.next_retry_at) > T0, 'espera propia en el futuro');
    assert.equal(e.spool.nextBatch({ now: T0 }).length, 0, 'un retry futuro no se adelanta');
    e.clock.t += 400000;
    assert.equal(e.spool.nextBatch({ now: e.clock.t }).length, 1);
  } finally { await e.done(); }
});

test('ACK perdido despues del commit: no se confirma nada, el reintento recibe duplicada', async () => {
  let drop = true;
  const fault = Object.assign(() => undefined, { afterCommit: () => { if (drop) { drop = false; return { destroy: true }; } } });
  const e = await setup({ rows: 4, fault });
  try {
    await e.fw.cycle();
    assert.deepEqual(e.states(), { retry: 4 }, 'sin ACK no hay sent');
    assert.equal(e.mock.store.size, 4, 'el destino SI habia guardado');
    assert.equal(e.fw.status().lastError.code, 'NETWORK_ERROR');
    e.clock.t += 400000;
    await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 4 });
    assert.equal(e.mock.store.size, 4, 'sin duplicar registros');
    const nonces = e.mock.requests.map(r => r.auth.nonce);
    assert.equal(new Set(nonces).size, 2, 'cada intento usa nonce nuevo');
  } finally { await e.done(); }
});

test('500: filas a retry y backoff global; al volver el destino se resetea', async () => {
  let fail = true;
  const fault = () => (fail ? { status: 500, body: { code: 'DB_DOWN' } } : undefined);
  const e = await setup({ rows: 3, fault });
  try {
    const d1 = await e.fw.cycle();
    assert.deepEqual(e.states(), { retry: 3 });
    assert.equal(e.fw.status().consecutiveFailures, 1);
    assert.ok(d1 >= 1000);
    e.clock.t += 400000; fail = false;
    await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 3 });
    assert.equal(e.fw.status().consecutiveFailures, 0);
  } finally { await e.done(); }
});

test('timeout del cliente: nada se confirma, filas a retry (NETWORK_TIMEOUT)', async () => {
  const e = await setup({ rows: 2, fault: () => ({ hang: true }), cfg: { requestTimeoutMs: 60 } });
  try {
    await e.fw.cycle();
    assert.deepEqual(e.states(), { retry: 2 });
    assert.equal(e.fw.status().lastError.code, 'NETWORK_TIMEOUT');
  } finally { await e.done(); }
});

test('413: parte el lote por la mitad; un unico mensaje demasiado grande va a cuarentena', async () => {
  let limit = 2;
  const e = await setup({ rows: 8, cfg: { maxRows: 8 } });
  try {
    // Reemplazo del destino: 413 mientras el lote exceda `limit`.
    const original = e.fw.fetchImpl;
    e.fw.fetchImpl = async (url, init) => {
      const n = JSON.parse(Buffer.from(init.body).toString()).rows.length;
      if (n > limit) return new Response('{"code":"PAYLOAD_TOO_LARGE"}', { status: 413 });
      return original(url, init);
    };
    assert.equal(await e.fw.cycle(), 0);                 // 8 -> 4
    assert.equal(e.fw.status().maxRowsNow, 4);
    assert.equal(await e.fw.cycle(), 0);                 // 4 -> 2
    assert.equal(e.fw.status().maxRowsNow, 2);
    assert.deepEqual(e.states(), { pending: 8 }, '413 no cuarentena el lote');
    await e.fw.cycle();                                  // 2 filas: pasan
    assert.deepEqual(e.states(), { sent: 2, pending: 6 });
    limit = 0;                                           // ahora ni una fila entra
    e.fw.maxRowsNow = 1;
    await e.fw.cycle();
    assert.equal(e.states().quarantine, 1);
    assert.equal(e.spool.quarantineSummary()[0].code, 'PAYLOAD_TOO_LARGE');
  } finally { await e.done(); }
});

test('429 respeta Retry-After; la cola no se toca', async () => {
  const e = await setup({ rows: 3, fault: () => ({ status: 429, headers: { 'Retry-After': '120' }, body: { code: 'RATE' } }) });
  try {
    const d = await e.fw.cycle();
    assert.ok(d >= 120000);
    assert.deepEqual(e.states(), { pending: 3 });
    assert.equal(e.fw.status().lastError.code, 'RATE_LIMITED');
  } finally { await e.done(); }
});

test('409 REPLAY: reintento inmediato con timestamp y nonce nuevos', async () => {
  let first = true;
  const e = await setup({ rows: 3, fault: () => { if (first) { first = false; return { status: 409, body: { code: 'REPLAY' } }; } } });
  try {
    await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 3 });
    const [a, b] = e.mock.requests.map(r => r.auth.nonce);
    assert.notEqual(a, b);
  } finally { await e.done(); }
});

test('401/403: pausa espaciada >= 60 s y la cola intacta; 503 INGEST_DISABLED igual; 400 detiene el contrato (halted)', async () => {
  for (const [status, body, code, minMs] of [[401, { code: 'X' }, 'AUTH_401', 60000], [403, { code: 'X' }, 'AUTH_403', 60000], [503, { code: 'INGEST_DISABLED' }, 'INGEST_DISABLED', 60000], [400, { code: 'INVALID_ENVELOPE' }, 'HTTP_400', 900000]]) {
    const e = await setup({ rows: 2, fault: () => ({ status, body }) });
    try {
      const d = await e.fw.cycle();
      assert.deepEqual(e.states(), { pending: 2 }, `status ${status}: cola intacta`);
      assert.ok(d >= minMs, `status ${status}: espera ${d}`);
      assert.equal(e.fw.status().lastError.code, code);
      assert.equal(!!e.fw.status().halted, status === 400);
    } finally { await e.done(); }
  }
});

test('ACKs invalidos NUNCA confirman: indice duplicado, batchId ajeno, forma incorrecta, 200 sin JSON', async () => {
  const cases = {
    'indice duplicado': ack => ({ ...ack, rows: [ack.rows[0], ack.rows[0], ...ack.rows.slice(2)] }),
    'batchId ajeno': ack => ({ ...ack, batchId: '00000000-0000-4000-8000-000000000000' }),
    'sin rows': ack => ({ ackVersion: '1', batchId: ack.batchId }),
    'ackVersion distinta': ack => ({ ...ack, ackVersion: '2' }),
    'indice fuera de rango': ack => ({ ...ack, rows: [...ack.rows, { index: 99, hash: null, status: 'insertada' }] }),
  };
  for (const [name, mutate] of Object.entries(cases)) {
    const fault = Object.assign(() => undefined, { afterCommit: () => ({ ack: mutate }) });
    const e = await setup({ rows: 3, fault });
    try {
      await e.fw.cycle();
      assert.deepEqual(e.states(), { retry: 3 }, name);
      assert.equal(e.fw.status().lastError.code, 'ACK_INVALID', name);
    } finally { await e.done(); }
  }
  const e = await setup({ rows: 2, fault: () => ({ status: 200, body: 'esto no es json' }) });
  try { await e.fw.cycle(); assert.deepEqual(e.states(), { retry: 2 }); assert.equal(e.fw.status().lastError.code, 'ACK_INVALID'); } finally { await e.done(); }
  const e2 = await setup({ rows: 2, fault: () => ({ status: 202, body: { ackVersion: '1' } }) });
  try { await e2.fw.cycle(); assert.deepEqual(e2.states(), { pending: 2 }, 'HTTP 202 no confirma ni toca la cola'); } finally { await e2.done(); }
});

test('ACK parcial: fila ausente o con hash distinto queda en retry (ACK_UNCONFIRMED); las confirmadas pasan a sent', async () => {
  const fault = Object.assign(() => undefined, {
    afterCommit: () => ({ ack: ack => ({ ...ack, rows: ack.rows.filter(r => r.index !== 1).map(r => r.index === 2 ? { ...r, hash: 'f'.repeat(64) } : r) }) }),
  });
  const e = await setup({ rows: 5, fault });
  try {
    await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 3, retry: 2 });
    const codes = e.spool.db.prepare("SELECT last_error_code c FROM spool WHERE state='retry'").all().map(r => r.c);
    assert.deepEqual(codes, ['ACK_UNCONFIRMED', 'ACK_UNCONFIRMED']);
  } finally { await e.done(); }
});

test('atraso acumulado: lotes de 500 consecutivos sin espera de 15 s, un solo request en vuelo', async () => {
  const e = await setup({ rows: 1250 });
  try {
    assert.equal(await e.fw.cycle(), 0, 'quedan filas: siguiente lote inmediato');
    assert.equal(await e.fw.cycle(), 0);
    assert.equal(await e.fw.cycle(), 15000, 'ultimo lote: regimen estable');
    assert.deepEqual(e.states(), { sent: 1250 });
    assert.deepEqual(e.mock.requests.map(r => r.rows), [500, 500, 250]);
    assert.equal(e.mock.maxInflight(), 1);
  } finally { await e.done(); }
});

test('bucle real con temporizadores: drena una cola de 1.100 filas y queda en espera', async () => {
  const e = await setup({ rows: 1100, cfg: { flushIntervalMs: 50 } });
  try {
    e.fw.stopped = true;   // arranque limpio: start() programa el bucle real
    e.fw.start();
    await waitFor(() => e.states().sent === 1100);
    assert.equal(e.mock.maxInflight(), 1);
  } finally { await e.done(); }
});

test('limite de bytes del cuerpo: nunca se supera, los lotes se recomponen y todo termina enviado', async () => {
  const e = await setup({ rows: 40, cfg: { maxBodyBytes: 6000 } });
  try {
    for (let i = 0; i < 40 && e.states().sent !== 40; i++) await e.fw.cycle();
    assert.deepEqual(e.states(), { sent: 40 });
    assert.ok(e.mock.requests.every(r => r.bytes <= 6000), 'cada POST respeta el tope');
    assert.ok(e.mock.requests.length > 1);
  } finally { await e.done(); }
});

test('reinicio: lo pendiente sobrevive y otro reenviador lo envia con batchId distinto; el destino no duplica', async () => {
  const e = await setup({ rows: 3, fault: () => ({ status: 500 }) });
  try {
    await e.fw.cycle();
    const batch1 = e.fw.batchId;
    e.spool.close();
    e.spool = new Spool(e.t.file('staging-spool.sqlite'));
    const fw2 = new Forwarder({ spool: e.spool, now: () => e.clock.t, random: () => 0.5, config: { ...PROFILE, key: KEY, url: e.mock.url } });
    fw2.stopped = false;
    e.clock.t += 400000;
    e.mock.server.removeAllListeners('request');   // reemplazar el destino por uno sano
    const ok = await startMockIngest({ key: KEY, ...PROFILE, now: () => e.clock.t });
    fw2.cfg.url = ok.url;
    await fw2.cycle();
    assert.deepEqual(e.states(), { sent: 3 });
    assert.notEqual(fw2.batchId, batch1);
    await ok.close();
  } finally { await e.done(); }
});

test('apagar durante un envio en vuelo no marca ni pierde filas', async () => {
  const e = await setup({ rows: 3, fault: () => ({ hang: true }), cfg: { requestTimeoutMs: 5000 } });
  try {
    const inflight = e.fw.cycle();
    await new Promise(r => setTimeout(r, 50));
    await e.fw.stop();
    await inflight;
    assert.deepEqual(e.states(), { pending: 3 });
  } finally { await e.done(); }
});
