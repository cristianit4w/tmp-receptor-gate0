import test from 'node:test';
import assert from 'node:assert/strict';
import {createSourcePolicy,normalizeIP} from '../src/sourcePolicy.js';

test('ALLOWED_SOURCES CIDR IPv4 y normalizacion IPv4-mapeada',()=>{
 const p=createSourcePolicy('127.0.0.0/8,192.0.2.5/32');
 assert.equal(normalizeIP('::ffff:127.0.0.1'),'127.0.0.1');
 assert.equal(p.allows('::ffff:127.0.0.1'),true);
 assert.equal(p.allows('192.0.2.5'),true);
 assert.equal(p.allows('192.0.2.6'),false);
 assert.equal(p.allows('::1'),false);
 assert.equal(createSourcePolicy('').allows('203.0.113.5'),true);
});
test('ALLOWED_SOURCES rechaza CIDR o IP incorrectos en startup',()=>{
 for (const v of ['999.2.3.4','127.0.0.1/33','bad-ip','192.0.2.0/-1','192.0.2.0/abc'])
  assert.throws(()=>createSourcePolicy(v),/INVALID_ALLOWED_SOURCES/);
});
