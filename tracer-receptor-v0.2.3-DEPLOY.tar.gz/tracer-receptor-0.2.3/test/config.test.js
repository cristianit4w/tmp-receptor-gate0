import test from 'node:test';import assert from 'node:assert/strict';
import { loadConfig, readHmacKey } from '../src/config.js';

const io = (mode = 0o100640, text = 'ab'.repeat(32)) => ({ statSync: () => ({ isFile: () => true, mode }), readFileSync: () => text });
const gate0 = { RECEIVER_MODE: 'gate0', DIAGNOSTIC_MODE: 'true', DB_FORWARDER: 'false', TCP_PORT: '41873' };
const std = { RECEIVER_MODE: 'standard', DIAGNOSTIC_MODE: 'false', SQLITE_PATH: '/var/lib/tracer-receptor/spool.sqlite' };
const fwStaging = { ...std, SQLITE_PATH: '/var/lib/tracer-receptor/staging-spool.sqlite', FORWARDER_ENABLED: 'true', FORWARDER_PROFILE: 'staging',
  FORWARDER_URL: 'https://ingest.example.test/api/tracer/v1/batches', FORWARDER_KEY_FILE: '/etc/tracer-receptor/forwarder.key' };
const fwProd = { ...std, FORWARDER_ENABLED: 'true', FORWARDER_PROFILE: 'production', FORWARDER_PRODUCTION_AUTHORIZATION: 'G5',
  FORWARDER_URL: 'https://ingest.example.test/api/tracer/v1/batches', FORWARDER_KEY_FILE: '/etc/tracer-receptor/forwarder.key' };

test('gate0 conserva el comportamiento v0.1.2: diagnostico forzado y reenviador prohibido', () => {
  const c = loadConfig(gate0);
  assert.equal(c.receiver.diagnostics, true);
  assert.equal(c.forwarder, null);
  assert.throws(() => loadConfig({ ...gate0, DIAGNOSTIC_MODE: 'false' }), /DIAGNOSTIC_MODE must be true/);
  assert.throws(() => loadConfig({ ...gate0, DB_FORWARDER: 'true' }), /DB_FORWARDER MUST be false/);
  assert.throws(() => loadConfig({ ...gate0, FORWARDER_ENABLED: 'true' }), /not allowed in gate0/);
});
test('RECEIVER_MODE obligatorio y solo gate0|standard', () => {
  assert.throws(() => loadConfig({}), /RECEIVER_MODE/);
  assert.throws(() => loadConfig({ RECEIVER_MODE: 'production' }), /RECEIVER_MODE/);
});
test('standard: el diagnostico se puede apagar; sin FORWARDER_ENABLED el reenviador queda APAGADO', () => {
  const c = loadConfig(std);
  assert.equal(c.receiver.diagnostics, false);
  assert.equal(c.forwarder, null);
  assert.throws(() => loadConfig({ RECEIVER_MODE: 'standard' }), /DIAGNOSTIC_MODE must be/);
  // Tener perfil, URL y clave configurados NO lo activa.
  const c2 = loadConfig({ ...std, FORWARDER_PROFILE: 'production', FORWARDER_URL: 'https://x/api/tracer/v1/batches', FORWARDER_KEY_FILE: '/k' });
  assert.equal(c2.forwarder, null);
  assert.throws(() => loadConfig({ ...std, FORWARDER_ENABLED: 'yes' }), /must be true or false/);
});
test('perfil staging: literales exactos del contrato P2 rev. 1.2 y spool separado', () => {
  const c = loadConfig(fwStaging, io());
  assert.deepEqual([c.forwarder.audience, c.forwarder.environment, c.forwarder.sourceId, c.forwarder.keyId],
    ['bymones-tracer-ingesta-staging', 'staging', 'bymones-tracer-staging-01', 'bymones-tracer-staging-k01']);
  assert.equal(c.forwarder.key.length, 32);
  assert.equal(c.forwarder.maxRows, 500);
  assert.equal(c.forwarder.maxBodyBytes, 524288);
  assert.equal(c.forwarder.flushIntervalMs, 15000);
  assert.equal(c.forwarder.requestTimeoutMs, 15000);
  assert.throws(() => loadConfig({ ...fwStaging, SQLITE_PATH: '/var/lib/tracer-receptor/spool.sqlite' }, io()), /separate spool/);
});
test('perfil production: exige autorizacion explicita G5 y literales de produccion', () => {
  const c = loadConfig(fwProd, io());
  assert.deepEqual([c.forwarder.audience, c.forwarder.environment, c.forwarder.sourceId, c.forwarder.keyId],
    ['bymones-tracer-ingesta-production', 'production', 'bymones-tracer-production-01', 'bymones-tracer-production-k01']);
  const { FORWARDER_PRODUCTION_AUTHORIZATION, ...sinG5 } = fwProd; void FORWARDER_PRODUCTION_AUTHORIZATION;
  assert.throws(() => loadConfig(sinG5, io()), /G5/);
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_PRODUCTION_AUTHORIZATION: 'G4' }, io()), /G5/);
});
test('entornos mezclados o alias no se aceptan: no hay fallback a produccion', () => {
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_PROFILE: 'prod' }, io()), /staging or production/);
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_SOURCE_ID: 'bymones-tracer-staging-01' }, io()), /does not match profile/);
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_ENVIRONMENT: 'staging' }, io()), /does not match profile/);
  assert.throws(() => loadConfig({ ...fwStaging, FORWARDER_KEY_ID: 'bymones-tracer-production-k01' }, io()), /does not match profile/);
  assert.throws(() => loadConfig({ ...fwStaging, FORWARDER_AUDIENCE: 'bymones-tracer-ingesta-production' }, io()), /does not match profile/);
  const sinPerfil = { ...fwProd }; delete sinPerfil.FORWARDER_PROFILE;
  assert.throws(() => loadConfig(sinPerfil, io()), /staging or production/);
});
test('URL: https obligatorio, ruta exacta, sin credenciales ni query; http solo local+staging+flag explicito', () => {
  for (const url of ['http://ingest.example.test/api/tracer/v1/batches', 'https://ingest.example.test/otra', 'https://user:pw@ingest.example.test/api/tracer/v1/batches',
    'https://ingest.example.test/api/tracer/v1/batches?x=1', 'https://ingest.example.test/api/tracer/v1/batches#f', '', 'no es url'])
    assert.throws(() => loadConfig({ ...fwProd, FORWARDER_URL: url }, io()), /FORWARDER_URL/, url);
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_URL: 'http://127.0.0.1:9/api/tracer/v1/batches', FORWARDER_ALLOW_LOCAL_HTTP: 'true' }, io()), /https/, 'produccion nunca http');
  assert.throws(() => loadConfig({ ...fwStaging, FORWARDER_URL: 'http://127.0.0.1:9/api/tracer/v1/batches' }, io()), /https/, 'http local requiere flag');
  assert.throws(() => loadConfig({ ...fwStaging, FORWARDER_URL: 'http://ingest.example.test/api/tracer/v1/batches', FORWARDER_ALLOW_LOCAL_HTTP: 'true' }, io()), /https/, 'http solo para host local');
  assert.ok(loadConfig({ ...fwStaging, FORWARDER_URL: 'http://127.0.0.1:9/api/tracer/v1/batches', FORWARDER_ALLOW_LOCAL_HTTP: 'true' }, io()).forwarder);
});
test('clave HMAC: desde archivo, hex o base64url, >= 32 bytes, permisos cerrados; nunca desde variable de entorno', () => {
  assert.equal(readHmacKey('/k', io(0o100600, 'cd'.repeat(32))).length, 32);
  assert.equal(readHmacKey('/k', io(0o100640, Buffer.alloc(32, 7).toString('base64url'))).length, 32);
  assert.throws(() => readHmacKey('/k', io(0o100644)), /permissions too open/);
  assert.throws(() => readHmacKey('/k', io(0o100660)), /permissions too open/);
  assert.throws(() => readHmacKey('/k', io(0o100640, 'abcd')), /32 bytes/);
  assert.throws(() => readHmacKey('/k', io(0o100640, 'no hex ni base64 ' + 'x'.repeat(40))), /32 bytes/);
  assert.throws(() => readHmacKey('/k', { statSync: () => ({ isFile: () => false, mode: 0o100600 }), readFileSync: () => '' }), /regular file/);
  const { FORWARDER_KEY_FILE, ...sinArchivo } = fwProd; void FORWARDER_KEY_FILE;
  assert.throws(() => loadConfig({ ...sinArchivo, FORWARDER_HMAC_KEY: 'ab'.repeat(32) }, io()), /FORWARDER_KEY_FILE required/);
});
test('limites del contrato: no se pueden superar 500 filas ni 512 KiB', () => {
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_MAX_ROWS: '501' }, io()), /FORWARDER_MAX_ROWS/);
  assert.throws(() => loadConfig({ ...fwProd, FORWARDER_MAX_BODY_BYTES: '524289' }, io()), /FORWARDER_MAX_BODY_BYTES/);
  assert.equal(loadConfig({ ...fwProd, FORWARDER_MAX_ROWS: '100' }, io()).forwarder.maxRows, 100);
});
test('retencion local por defecto: sent 72 h, cuarentena 7 dias, poda diaria', () => {
  const r = loadConfig(std).retention;
  assert.deepEqual(r, { sentRetentionHours: 72, quarantineRetentionDays: 7, pruneIntervalSeconds: 86400 });
});
