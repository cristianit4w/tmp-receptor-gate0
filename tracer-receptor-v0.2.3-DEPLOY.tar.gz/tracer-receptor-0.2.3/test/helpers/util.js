import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import { createSyntheticPC, parsePC } from '../../src/parser.js';
export const KEY = Buffer.from('k'.repeat(32));
export const PROFILE = { audience: 'bymones-tracer-ingesta-staging', environment: 'staging', sourceId: 'bymones-tracer-staging-01', keyId: 'bymones-tracer-staging-k01' };
export function tmp(prefix = 'tracer-v020-') {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), prefix));
  return { dir, file: name => path.join(dir, name), destroy() { fs.rmSync(dir, { recursive: true, force: true }); } };
}
// Mensaje sintetico unico por indice (patente sintetica, hora distinta).
export function syntheticParsed(i, over = {}) {
  const sec = String(i % 60).padStart(2, '0'), min = String(Math.floor(i / 60) % 60).padStart(2, '0'), hr = String(Math.floor(i / 3600) % 24).padStart(2, '0');
  return parsePC(createSyntheticPC({ time: `${hr}${min}${sec}`, plate: 'SYN' + String(i % 1000).padStart(3, '0'), ...over }));
}
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export async function waitFor(fn, ms = 4000, step = 10) {
  const end = Date.now() + ms;
  for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('waitFor timeout'); await sleep(step); }
}
