import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {Spool} from '../src/spool.js';import {parsePC,createSyntheticPC} from '../src/parser.js';
function fixture(){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-gate0-'));return {dir,db:path.join(dir,'queue.sqlite'),destroy(){fs.rmSync(dir,{recursive:true,force:true})}}}
test('SQLite WAL+FULL, durable across restart, idempotent duplicate',()=>{
 const f=fixture();try{let s=new Spool(f.db);const p=parsePC(createSyntheticPC());assert.equal(s.ingest(p,{rawFrame:createSyntheticPC()}),'stored');assert.equal(s.ingest(p),'duplicate');
 assert.equal(s.stats().queueDepth,1);assert.equal(s.db.prepare('PRAGMA journal_mode').get().journal_mode,'wal');assert.equal(s.db.prepare('PRAGMA synchronous').get().synchronous,2);s.close();
 s=new Spool(f.db);assert.equal(s.stats().queueDepth,1);assert.equal(s.ingest(p),'duplicate');assert.equal(s.stats().queueDepth,1);s.close();}finally{f.destroy()}
});
test('GPS invalid and out-of-order never regress latest valid coords',()=>{
 const f=fixture();try{const s=new Spool(f.db);const base=parsePC(createSyntheticPC({time:'153045',lat:'-34.60372'}));s.ingest(base);
 s.ingest(parsePC(createSyntheticPC({time:'153047',lat:'-34.60372',gpsValid:'0'})));
 let state=s.last('AB123CD');assert.equal(state.last_reported_at,'2026-10-13T15:30:47.000Z');assert.equal(state.last_valid_at,base.reportedAt);
 s.ingest(parsePC(createSyntheticPC({time:'153046',lat:'-34.70211',gpsValid:'1'})));
 state=s.last('AB123CD');assert.equal(state.last_reported_at,'2026-10-13T15:30:47.000Z');assert.equal(state.last_valid_at,'2026-10-13T15:30:46.000Z');assert.equal(state.valid_lat,-34.70211);
 s.ingest(parsePC(createSyntheticPC({time:'153044',lat:'-34.99999',gpsValid:'1'})));
 assert.equal(s.last('AB123CD').valid_lat,-34.70211);s.close();}finally{f.destroy()}
});
test('diagnostic raw hex retained short-term and pruned <=24h',()=>{
 const f=fixture();try{const s=new Spool(f.db,{diagnostics:true,rawRetentionHours:24});s.error('PC_BAD_EVENT','127.0.0.1',Buffer.from('bad'));
 assert.equal(s.db.prepare('SELECT raw_text FROM errors').get().raw_text,'626164');
 s.ingest(parsePC(createSyntheticPC()),{receivedAt:new Date(Date.now()-26*3600000).toISOString(),rawFrame:createSyntheticPC()});
 assert.equal(s.db.prepare('SELECT COUNT(*) n FROM raw_diagnostic').get().n,1);
 assert.equal(s.pruneRaw(Date.now()+25*3600000),2);assert.equal(s.db.prepare('SELECT raw_text FROM errors').get().raw_text,null);
 s.close();}finally{f.destroy()}
});

test('eventos fuera de 01..11 se persisten y cuentan (con duplicados)', () => {
 const f=fixture();try {const s=new Spool(f.db);
  const raw=createSyntheticPC({event:'12'}),p=parsePC(raw);
  assert.equal(p.eventKnown,false);
  assert.equal(s.ingest(p),'stored');assert.equal(s.ingest(p),'duplicate');
  const row=s.db.prepare('SELECT event_code,event_known,payload_json FROM spool').get();
  assert.equal(row.event_code,'12');assert.equal(row.event_known,0);
  assert.equal(JSON.parse(row.payload_json).eventKnown,false);
  assert.equal(s.stats().counters.events_unknown,2);
  assert.equal(s.stats().counters.events_unknown_unique,1);
  s.close();
 }finally{f.destroy()}
});

test('errors solo guarda las ultimas N filas sin perder contadores',()=>{
 const f=fixture();try {const s=new Spool(f.db,{maxErrorsRows:3,diagnostics:true});
  for(let i=1;i<=15;i++)s.error('ERROR_'+i,'127.0.0.1',Buffer.from('x'));
  assert.deepEqual(s.db.prepare('SELECT code FROM errors ORDER BY seq').all().map(v=>v.code), ['ERROR_13','ERROR_14','ERROR_15']);
  assert.equal(s.stats().errorsRetained,3);
  assert.equal(s.stats().counters.error_ERROR_1,1);
  s.close();
 } finally {f.destroy()}
});

test('MAX_SPOOL_BYTES monitorea db, WAL, SHM y suspende ingesta en critico',()=>{
 const f=fixture();try{const s=new Spool(f.db,{maxSpoolBytes:134217728});
  const current=s.spoolBytes();
  assert.ok(current>0);
  s.maxSpoolBytes=Math.ceil(current/.85); 
  assert.equal(s.capacity().status,'warning');
  assert.equal(s.capacity().nearingLimit,true);
  s.maxSpoolBytes=Math.ceil(current/.97);
  assert.equal(s.capacity().status,'critical');
  assert.throws(()=>s.ingest(parsePC(createSyntheticPC())),e=>e.code==='SPOOL_CAPACITY_EXCEEDED');
  assert.equal(s.db.prepare('SELECT COUNT(*) n FROM spool').get().n,0);
  s.close();
 }finally{f.destroy()}
});


test('upgrade de sqlite v0.1.1 preserva filas anteriores y agrega event_known',async()=>{
 const { DatabaseSync }=await import('node:sqlite');
 const f=fixture();try{
  const old=new DatabaseSync(f.db);
  old.exec(`CREATE TABLE spool(
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    hash TEXT NOT NULL UNIQUE,
    received_at TEXT NOT NULL,
    reported_at TEXT NOT NULL,
    plate TEXT NOT NULL,
    gps_valid INTEGER NOT NULL,
    event_code TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','retry','sent')),
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TEXT
  )`);
  const legacy=parsePC(createSyntheticPC());
  old.prepare(`INSERT INTO spool (hash,received_at,reported_at,plate,gps_valid,event_code,payload_json)
     VALUES (?,?,?,?,?,?,?)`).run(legacy.hash,new Date().toISOString(),legacy.reportedAt,
       legacy.plate,1,legacy.eventCode,JSON.stringify(legacy));
  old.close();
  const next=new Spool(f.db);
  assert.equal(next.stats().queueDepth,1);
  assert.equal(next.db.prepare('SELECT event_known FROM spool').get().event_known,1);
  assert.equal(next.ingest(legacy),'duplicate');
  next.close();
 }finally{f.destroy()}
});

test('MAX_ERRORS_ROWS tambien poda errores previos al arrancar',()=>{
 const f=fixture();try{
  let s=new Spool(f.db,{maxErrorsRows:100});
  for(let i=0;i<9;i++)s.error('OLD');s.close();
  s=new Spool(f.db,{maxErrorsRows:2});
  assert.equal(s.stats().errorsRetained,2);
  assert.equal(s.stats().counters.error_OLD,9);
  s.close();
 }finally{f.destroy()}
});
