import test from 'node:test';
import assert from 'node:assert/strict';
import {parsePC,createSyntheticPC,FRAME_LENGTH} from '../src/parser.js';
function err(code,fn){assert.throws(fn,e=>e.code===code)}
const good=()=>createSyntheticPC();
test('PC exactly 59 ASCII including |, offsets, UTC, hash',()=>{
 const b=good();assert.equal(b.length,59);const p=parsePC(b);
 assert.equal(p.plate,'AB123CD');assert.equal(p.reportedAt,'2026-10-13T15:30:45.000Z');
 assert.equal(p.latitude,-34.60372);assert.equal(p.longitude,-58.38158);assert.equal(p.headingDegrees,180);
 assert.equal(p.gpsValid,true);assert.equal(p.eventCode,'01');assert.deepEqual(p.temperatures,[22,18,0]);
 assert.equal(p.hash,parsePC(good()).hash);
});
test('PS rejected explicitly even short',()=>err('PS_UNSUPPORTED_BY_SCOPE',()=>parsePC('PS|')));
test('all truncated sizes 1..58 rejected',()=>{for(let n=1;n<59;n++)err('PC_INVALID_LENGTH',()=>parsePC(good().subarray(0,n)))});
test('long, wrong terminator, control/non ascii',()=>{
 err('PC_INVALID_LENGTH',()=>parsePC(Buffer.concat([good(),Buffer.from('x')])));
 const term=good();term[58]=0x2a;err('PC_INVALID_TERMINATOR',()=>parsePC(term));
 const non=good();non[20]=0x80;err('PC_NON_ASCII',()=>parsePC(non));
});
test('right-padded license? accepted only left padding',()=>{
 assert.equal(parsePC(createSyntheticPC({plate:'AC123B'})).plate,'AC123B');
 err('PC_BAD_PLATE',()=>parsePC(createSyntheticPC({plate:'AB12 CD'})));
});
test('gps invalid does not imply movement',()=>assert.equal(parsePC(createSyntheticPC({gpsValid:'0'})).gpsValid,false));
test('latitude longitude out of range and heading 361',()=>{
 err('PC_LATITUDE_OUT_OF_RANGE',()=>parsePC(createSyntheticPC({lat:'-91.00000'})));
 err('PC_LONGITUDE_OUT_OF_RANGE',()=>parsePC(createSyntheticPC({lon:'+181.00000'})));
 err('PC_HEADING_OUT_OF_RANGE',()=>parsePC(createSyntheticPC({heading:'361'})));
 for(const h of ['000','360'])assert.equal(parsePC(createSyntheticPC({heading:h})).headingDegrees,Number(h));
});
test('event 01-11 known, 00/12/99 kept as unknown, nonnumeric rejected',()=>{
 for(const e of ['01','03','05','09','11']){const p=parsePC(createSyntheticPC({event:e}));assert.equal(p.eventCode,e);assert.equal(p.eventKnown,true)}
 for(const e of ['00','12','99']){const p=parsePC(createSyntheticPC({event:e}));assert.equal(p.eventCode,e);assert.equal(p.eventKnown,false)}
 err('PC_BAD_EVENT',()=>parsePC(createSyntheticPC({event:'AA'})));
 assert.deepEqual(parsePC(createSyntheticPC({t1:'-09',t2:'+00',t3:'-02'})).temperatures,[-9,0,-2]);
});
test('reject nonexistent date, impossible UTC clock',()=>{
 err('PC_BAD_DATETIME',()=>parsePC(createSyntheticPC({date:'311126'})));
 err('PC_BAD_DATETIME',()=>parsePC(createSyntheticPC({time:'246099'})));
});
