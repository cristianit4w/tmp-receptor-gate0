import test from 'node:test';import assert from 'node:assert/strict';
import { Spool } from '../src/spool.js';
import { Forwarder } from '../src/forwarder.js';
import { KEY, PROFILE, tmp, syntheticParsed } from './helpers/util.js';

// H07: los headers (status, Retry-After) llegaron pero el cuerpo falla al leerse.
// Deben conservar la politica del status; no se tratan como error de red.
const T0 = Date.parse('2026-10-20T12:00:00Z');
function brokenBodyResponse(status, headers = {}) {
  const stream = new ReadableStream({ pull() { throw new Error('socket hang up mientras se leia el cuerpo'); } });
  return new Response(stream, { status, headers });
}
async function run(status, headers) {
  const t = tmp();
  const spool = new Spool(t.file('staging-spool.sqlite'));
  for (let i = 0; i < 3; i++) spool.ingest(syntheticParsed(i), { receivedAt: new Date(T0 - 60000 + i).toISOString() });
  const fw = new Forwarder({ spool, now: () => T0, random: () => 0.5,
    fetchImpl: async () => brokenBodyResponse(status, headers), config: { ...PROFILE, key: KEY, url: 'https://x.example.test/api/tracer/v1/batches' } });
  fw.stopped = false;
  const delay = await fw.cycle();
  const states = Object.fromEntries(spool.db.prepare('SELECT state, COUNT(*) n FROM spool GROUP BY 1').all().map(r => [r.state, r.n]));
  const out = { delay, states, status: fw.status(), requests: 1 };
  fw.stopped = true; spool.close(); t.destroy();
  return out;
}

test('H07 401/429/503 con Retry-After 7200 y cuerpo roto: espera >= 7.200 s, cola intacta, sin NETWORK_ERROR', async () => {
  for (const [status, code] of [[401, 'AUTH_401'], [403, 'AUTH_403'], [429, 'RATE_LIMITED'], [503, 'UNAVAILABLE']]) {
    const r = await run(status, { 'Retry-After': '7200' });
    assert.ok(r.delay >= 7200000, `status ${status}: espera ${r.delay}`);
    assert.deepEqual(r.states, { pending: 3 }, `status ${status}: cola intacta`);
    assert.equal(r.status.lastError.code, code, `status ${status}`);
  }
});
test('H07 200 con cuerpo roto: no confirma nada, filas a retry (ACK_INVALID)', async () => {
  const r = await run(200);
  assert.deepEqual(r.states, { retry: 3 });
  assert.equal(r.status.lastError.code, 'ACK_INVALID');
});
test('H07 409 con cuerpo roto: sin REPLAY verificado no hay reintento inmediato; contrato detenido', async () => {
  const r = await run(409, { 'Retry-After': '7200' });
  assert.deepEqual(r.states, { pending: 3 });
  assert.equal(r.status.lastError.code, 'HTTP_409_UNKNOWN');
  assert.ok(r.status.halted);
  assert.ok(r.delay >= 7200000);
});
test('H07 500 y 400 con cuerpo roto conservan su politica de status', async () => {
  const r500 = await run(500, { 'Retry-After': '120' });
  assert.deepEqual(r500.states, { retry: 3 });
  assert.equal(r500.status.lastError.code, 'HTTP_500');
  assert.ok(r500.delay >= 120000);
  const r400 = await run(400, { 'Retry-After': '3600' });
  assert.deepEqual(r400.states, { pending: 3 });
  assert.ok(r400.status.halted);
  assert.ok(r400.delay >= 3600000);
});
test('un fallo real al recibir headers sigue siendo error de red', async () => {
  const t = tmp();
  const spool = new Spool(t.file('staging-spool.sqlite'));
  spool.ingest(syntheticParsed(1), { receivedAt: new Date(T0).toISOString() });
  const fw = new Forwarder({ spool, now: () => T0, random: () => 0.5, fetchImpl: async () => { throw new TypeError('fetch failed'); },
    config: { ...PROFILE, key: KEY, url: 'https://x.example.test/api/tracer/v1/batches' } });
  fw.stopped = false;
  await fw.cycle();
  assert.equal(fw.status().lastError.code, 'NETWORK_ERROR');
  assert.equal(spool.stats().retrying, 1);
  spool.close(); t.destroy();
});
