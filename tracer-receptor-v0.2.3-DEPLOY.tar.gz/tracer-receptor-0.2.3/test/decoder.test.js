import test from 'node:test';
import assert from 'node:assert/strict';
import { FrameDecoder } from '../src/decoder.js';
import {createSyntheticPC} from '../src/parser.js';
function d(maxFrames=1000){const arr=[],errs=[];return {arr,errs,dec:new FrameDecoder({maxFrames,onFrame:frame=>arr.push(frame),onError:e=>errs.push(e.code)})};}
test('one frame in one chunk',()=>{const x=d();x.dec.feed(createSyntheticPC());x.dec.eof();assert.equal(x.arr.length,1);assert.deepEqual(x.errs,[])});
test('any-size fragmented TCP chunks',()=>{
 const b=createSyntheticPC();for(const size of [1,2,3,7,58]){
 const x=d();for(let i=0;i<b.length;i+=size)x.dec.feed(b.subarray(i,i+size));x.dec.eof();assert.equal(x.arr.length,1);assert.equal(x.arr[0].length,59);assert.deepEqual(x.errs,[])
 }
});
test('multiple frames in single TCP chunk and multi-chunk batch',()=>{
 const frames=Buffer.concat([createSyntheticPC(),createSyntheticPC({event:'05'}),createSyntheticPC({event:'09'})]);
 const x=d();x.dec.feed(frames.subarray(0,73));x.dec.feed(frames.subarray(73));x.dec.eof();assert.equal(x.arr.length,3);assert.deepEqual(x.errs,[]);
});
test('EOF with partial bytes signals error',()=>{const x=d();x.dec.feed(createSyntheticPC().subarray(0,19));x.dec.eof();assert.deepEqual(x.errs,['EOF_PARTIAL_FRAME']);});
test('too many frames, unterminated bytes overflow',()=>{
 const x=d(1);assert.throws(()=>x.dec.feed(Buffer.concat([createSyntheticPC(),createSyntheticPC()])),e=>e.code==='TOO_MANY_FRAMES');
 const y=d();assert.throws(()=>y.dec.feed(Buffer.alloc(60,0x41)),e=>e.code==='FRAME_TOO_LONG_UNTERMINATED');
});
