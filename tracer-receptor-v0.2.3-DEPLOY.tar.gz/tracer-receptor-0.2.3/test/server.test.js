import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import net from 'node:net';
import {startReceiver} from '../src/server.js';import {createSyntheticPC} from '../src/parser.js';
async function session(port,frames,chunks=[frames]){return new Promise((resolve,reject)=>{
 const socket=net.connect(port,'127.0.0.1');let received=Buffer.alloc(0);const timer=setTimeout(()=>{socket.destroy();reject(new Error('timeout'))},2000);
 socket.on('connect',()=>{for(const c of chunks)socket.write(c);socket.end()});
 socket.on('data',b=>received=Buffer.concat([received,b]));socket.on('error',reject);
 socket.on('close',()=>{clearTimeout(timer);resolve(received)});
});}
async function start(db){const r=startReceiver({host:'127.0.0.1',port:0,sqlitePath:db,healthPort:0,diagnostics:true,idleTimeoutMs:2000});await new Promise(resolve=>r.tcp.once('listening',resolve));return r;}
test('two nonpersistent batches with split frames, PS and truncated; NEVER application ACK',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-network-'));let r;
 try{
  r=await start(path.join(dir,'spool.sqlite'));const port=r.tcp.address().port;
  const b=Buffer.concat([createSyntheticPC(),createSyntheticPC({event:'08'})]);
  const received=await session(port,b,[b.subarray(0,1),b.subarray(1,47),b.subarray(47,63),b.subarray(63)]);
  assert.equal(received.length,0);assert.equal(r.spool.stats().queueDepth,2);
  const second=await session(port,Buffer.from('PS123|'));assert.equal(second.length,0);
  await session(port,createSyntheticPC().subarray(0,22));
  await new Promise(resolve=>setTimeout(resolve,40));
  assert.equal(r.spool.stats().queueDepth,2);
  assert.equal(r.spool.stats().counters.error_PS_UNSUPPORTED_BY_SCOPE,1);
  assert.equal(r.spool.stats().counters.error_EOF_PARTIAL_FRAME,1);
  assert.equal(r.spool.stats().counters.batches_completed,3);
 }finally{if(r)await r.close();fs.rmSync(dir,{recursive:true,force:true});}
});

// Anti-starvation: abrir 40 sesiones de la misma IP sin datos. Los nuevos
// sockets desalojan conexiones ociosas, no un lote real con datos.
test('40 conexiones sin datos no bloquean un lote legítimo', async () => {
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-starvation-'));let receiver; const clients=[];
 try {
  receiver=startReceiver({host:'127.0.0.1',port:0,sqlitePath:path.join(dir,'q.sqlite'),healthPort:0,
    diagnostics:false,maxConnections:8,maxConnectionsPerIP:4,idleTimeoutMs:8000});
  await new Promise(resolve=>receiver.tcp.once('listening',resolve));
  const port=receiver.tcp.address().port;
  const attempts=Array.from({length:40},()=>new Promise(resolve=>{
    const socket=net.connect(port,'127.0.0.1');clients.push(socket);
    socket.on('error',()=>resolve());socket.once('connect',resolve);
  }));
  await Promise.all(attempts);
  await new Promise(resolve=>setTimeout(resolve,30));
  const valid=createSyntheticPC({plate:'AAA001'});
  assert.equal((await session(port,valid)).length,0);
  await new Promise(resolve=>setTimeout(resolve,30));
  const stats=receiver.spool.stats();
  assert.equal(stats.queueDepth,1);
  assert.ok((stats.counters.evicted_idle_connections??0)>=1);
  assert.ok(stats.counters.connections>=41);
 }finally{for(const c of clients)c.destroy();if(receiver)await receiver.close();fs.rmSync(dir,{recursive:true,force:true});}
});

test('ALLOWED_SOURCES cierra en aplicación fuentes no autorizadas',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-source-'));let receiver;
 try{
  receiver=startReceiver({host:'127.0.0.1',port:0,sqlitePath:path.join(dir,'q.sqlite'),healthPort:0,
     diagnostics:false,allowedSources:'192.0.2.5/32'});
  await new Promise(resolve=>receiver.tcp.once('listening',resolve));
  const p=receiver.tcp.address().port;
  await new Promise(resolve=>{
    const s=net.connect(p,'127.0.0.1');s.on('connect',()=>s.end());s.on('error',()=>{});s.on('close',resolve);
  });
  assert.equal(receiver.spool.stats().queueDepth,0);
  assert.equal(receiver.spool.stats().counters.rejected_sources,1);
 }finally{if(receiver)await receiver.close();fs.rmSync(dir,{recursive:true,force:true})}
});

test('/live da warning 80% y HTTP 503 al 95% de la capacidad',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-health-'));let r;
 try{
  r=startReceiver({host:'127.0.0.1',port:0,sqlitePath:path.join(dir,'q.sqlite'),healthPort:0,diagnostics:false});
  await new Promise(resolve=>r.health.once('listening',resolve));
  const port=r.health.address().port;
  const req=()=>new Promise((resolve,reject)=>{import('node:http').then(({get})=>get(`http://127.0.0.1:${port}/live`,res=>{
    let raw='';res.on('data',d=>raw+=d);res.on('end',()=>resolve({status:res.statusCode,data:JSON.parse(raw)}));
  }).on('error',reject));});
  const current=r.spool.spoolBytes();
  r.spool.maxSpoolBytes=Math.ceil(current/.85);
  let response=await req();assert.equal(response.status,200);assert.equal(response.data.alert,'SPOOL_NEARING_LIMIT');
  r.spool.maxSpoolBytes=Math.ceil(current/.97);
  response=await req();assert.equal(response.status,503);assert.equal(response.data.alert,'SPOOL_CAPACITY_CRITICAL');
 }finally{if(r)await r.close();fs.rmSync(dir,{recursive:true,force:true})}
});

test('TCP acepta evento numerico desconocido sin enviar ACK y persiste event_known=0',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tracer-event-'));let receiver;
 try{
  receiver=startReceiver({host:'127.0.0.1',port:0,sqlitePath:path.join(dir,'q.sqlite'),healthPort:0,diagnostics:false});
  await new Promise(resolve=>receiver.tcp.once('listening',resolve));
  const read=await session(receiver.tcp.address().port,createSyntheticPC({event:'98'}));
  assert.equal(read.length,0);
  assert.equal(receiver.spool.stats().queueDepth,1);
  assert.equal(receiver.spool.stats().counters.events_unknown,1);
  assert.equal(receiver.spool.db.prepare('SELECT event_known FROM spool').get().event_known,0);
 }finally{if(receiver)await receiver.close();fs.rmSync(dir,{recursive:true,force:true})}
});
