import test from 'node:test';import assert from 'node:assert/strict';import crypto from 'node:crypto';
import { signingString, hmacHex, signRequest, bodySha256Hex, newNonce, INGEST_PATH } from '../src/signing.js';
import { KEY, PROFILE } from './helpers/util.js';

test('cadena de firma: 10 lineas exactas unidas por LF, sin LF final', () => {
  const s = signingString({ ...PROFILE, timestamp: 1760961600, nonce: 'AAAAAAAAAAAAAAAAAAAAAA', bodyHashHex: 'ab'.repeat(32) });
  assert.deepEqual(s.split('\n'), ['TRACER-HMAC-V1', 'POST', INGEST_PATH, PROFILE.audience, PROFILE.environment, PROFILE.sourceId, PROFILE.keyId, '1760961600', 'AAAAAAAAAAAAAAAAAAAAAA', 'ab'.repeat(32)]);
  assert.ok(!s.endsWith('\n'));
});
test('HMAC coincide con una implementacion independiente (crypto directo)', () => {
  const body = Buffer.from('{"x":1}');
  const h = signRequest({ key: KEY, ...PROFILE, bodyBytes: body, now: 1760961600123, nonce: 'bm9uY2Utbm9uY2Utbm9uY2U' });
  const text = ['TRACER-HMAC-V1', 'POST', '/api/tracer/v1/batches', PROFILE.audience, PROFILE.environment, PROFILE.sourceId, PROFILE.keyId, '1760961600', 'bm9uY2Utbm9uY2Utbm9uY2U', crypto.createHash('sha256').update(body).digest('hex')].join('\n');
  assert.equal(h['X-Tracer-Signature'], crypto.createHmac('sha256', KEY).update(text, 'utf8').digest('hex'));
  assert.equal(h['X-Tracer-Timestamp'], '1760961600');   // segundos UTC, no milisegundos
  assert.equal(h['X-Tracer-Source'], PROFILE.sourceId);
  assert.equal(h['X-Tracer-Key-Id'], PROFILE.keyId);
});
test('cambiar audience, entorno, fuente, cuerpo, timestamp o nonce invalida la firma', () => {
  const base = { ...PROFILE, timestamp: 1, nonce: 'n'.repeat(22), bodyHashHex: bodySha256Hex(Buffer.from('a')) };
  const ref = hmacHex(KEY, signingString(base));
  for (const change of [{ audience: 'otro' }, { environment: 'production' }, { sourceId: 'x' }, { keyId: 'x' }, { timestamp: 2 }, { nonce: 'm'.repeat(22) }, { bodyHashHex: bodySha256Hex(Buffer.from('b')) }])
    assert.notEqual(hmacHex(KEY, signingString({ ...base, ...change })), ref);
});
test('campos con salto de linea o vacios se rechazan', () => {
  assert.throws(() => signingString({ ...PROFILE, audience: 'a\nb', timestamp: 1, nonce: 'n', bodyHashHex: 'h' }), /SIGNING_FIELD_INVALID/);
  assert.throws(() => signingString({ ...PROFILE, sourceId: '', timestamp: 1, nonce: 'n', bodyHashHex: 'h' }), /SIGNING_FIELD_INVALID/);
  assert.throws(() => signingString({ ...PROFILE, timestamp: 1.5, nonce: 'n', bodyHashHex: 'h' }), /SIGNING_FIELD_INVALID/);
});
test('nonce: 16 bytes aleatorios en base64url, unico', () => {
  const a = newNonce(), b = newNonce();
  assert.match(a, /^[A-Za-z0-9_-]{22}$/);
  assert.equal(Buffer.from(a, 'base64url').length, 16);
  assert.notEqual(a, b);
});

test('vector publico de firma (Python independiente): el codigo Node lo reproduce byte a byte', async () => {
  const fs = await import('node:fs');
  const v = JSON.parse(fs.readFileSync(new URL('./vectors/signing-vector.json', import.meta.url), 'utf8'));
  const key = Buffer.from(v.keyHex, 'hex');
  const body = Buffer.from(v.bodyUtf8, 'utf8');
  assert.equal(bodySha256Hex(body), v.bodySha256Hex);
  const h = signRequest({ key, audience: v.audience, environment: v.environment, sourceId: v.sourceId, keyId: v.keyId, bodyBytes: body, now: v.timestamp * 1000, nonce: v.nonce });
  assert.equal(h['X-Tracer-Signature'], v.signatureHex);
  assert.deepEqual(h, v.headers);
});
