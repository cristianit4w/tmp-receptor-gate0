import test from 'node:test';import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { Spool } from '../src/spool.js';
import { tmp, syntheticParsed } from './helpers/util.js';

const NOW = Date.parse('2026-10-20T12:00:00Z');
const LEGACY_DDL = (withEventKnown = true) => `
  CREATE TABLE spool (seq INTEGER PRIMARY KEY AUTOINCREMENT, hash TEXT NOT NULL UNIQUE, received_at TEXT NOT NULL, reported_at TEXT NOT NULL,
    plate TEXT NOT NULL, gps_valid INTEGER NOT NULL, event_code TEXT NOT NULL, ${withEventKnown ? 'event_known INTEGER NOT NULL DEFAULT 1,' : ''}
    payload_json TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','retry','sent')),
    retry_count INTEGER NOT NULL DEFAULT 0, next_retry_at TEXT);`;
function legacyDb(file, withEventKnown = true) {
  const d = new DatabaseSync(file);
  d.exec(LEGACY_DDL(withEventKnown));
  const ins = d.prepare(`INSERT INTO spool(seq,hash,received_at,reported_at,plate,gps_valid,event_code,${withEventKnown ? 'event_known,' : ''}payload_json,state,retry_count,next_retry_at)
    VALUES (?,?,?,?,?,?,?,${withEventKnown ? '?,' : ''}?,?,?,?)`);
  const rows = [[1, 'pending', 0, null], [2, 'retry', 3, '2026-10-20T12:00:30.000Z'], [3, 'sent', 0, null], [4, 'pending', 0, null], [5, 'pending', 0, null]];
  for (const [seq, state, rc, nra] of rows) {
    const p = syntheticParsed(seq);
    const args = [seq, p.hash, '2026-10-20T11:00:0' + seq + '.000Z', p.reportedAt, p.plate, 1, p.eventCode];
    if (withEventKnown) args.push(1);
    ins.run(...args, JSON.stringify(p), state, rc, nra);
  }
  d.exec('DELETE FROM spool WHERE seq IN (4,5)');   // el contador AUTOINCREMENT queda en 5 > max(seq)=3
  d.close();
}

test('migracion v0.1.2 -> v0.2.0: conserva filas, estados, reintentos y contador seq; es idempotente', () => {
  const t = tmp();
  try {
    legacyDb(t.file('q.sqlite'));
    let s = new Spool(t.file('q.sqlite'));
    const rows = s.db.prepare('SELECT seq,state,retry_count,next_retry_at FROM spool ORDER BY seq').all();
    assert.deepEqual(rows.map(r => [r.seq, r.state, r.retry_count]), [[1, 'pending', 0], [2, 'retry', 3], [3, 'sent', 0]]);
    assert.equal(rows[1].next_retry_at, '2026-10-20T12:00:30.000Z');
    s.applyResults({ quarantine: [{ seq: 1, code: 'INVALID_COORDINATES' }], now: NOW });   // el CHECK nuevo admite quarantine
    assert.equal(s.db.prepare('SELECT state FROM spool WHERE seq=1').get().state, 'quarantine');
    const p = syntheticParsed(99);
    s.ingest(p);
    assert.equal(s.db.prepare('SELECT seq FROM spool WHERE hash=?').get(p.hash).seq, 6, 'AUTOINCREMENT no retrocede');
    assert.equal(s.migrateSpool(), false, 'segunda migracion no hace nada');
    assert.equal(s.db.prepare('PRAGMA integrity_check').get().integrity_check, 'ok');
    s.close();
    s = new Spool(t.file('q.sqlite'));   // reabrir tampoco cambia nada
    assert.equal(s.stats().totalStored, 4);
    s.close();
  } finally { t.destroy(); }
});
test('migracion desde v0.1.1 (sin event_known) tambien funciona', () => {
  const t = tmp();
  try {
    legacyDb(t.file('q.sqlite'), false);
    const s = new Spool(t.file('q.sqlite'));
    assert.equal(s.db.prepare('SELECT COUNT(*) n FROM spool').get().n, 3);
    assert.ok(s.db.prepare('PRAGMA table_info(spool)').all().some(c => c.name === 'event_known'));
    s.close();
  } finally { t.destroy(); }
});
test('migrate:false no toca el esquema (herramientas de solo estadisticas)', () => {
  const t = tmp();
  try {
    legacyDb(t.file('q.sqlite'));
    const s = new Spool(t.file('q.sqlite'), { migrate: false });
    assert.ok(!/quarantine/.test(s.db.prepare("SELECT sql FROM sqlite_master WHERE name='spool'").get().sql));
    assert.equal(s.stats().queueDepth, 2);   // pending + retry
    s.close();
  } finally { t.destroy(); }
});
test('una migracion fallida hace rollback y deja la cola original intacta', () => {
  const t = tmp();
  try {
    legacyDb(t.file('q.sqlite'));
    const s = new Spool(t.file('q.sqlite'), { migrate: false });
    s.db.exec('CREATE TABLE spool_v020 (x INTEGER)');   // obliga a fallar el CREATE de la migracion
    assert.throws(() => s.migrateSpool());
    assert.equal(s.db.prepare('SELECT COUNT(*) n FROM spool').get().n, 3);
    assert.ok(!/quarantine/.test(s.db.prepare("SELECT sql FROM sqlite_master WHERE name='spool'").get().sql));
    s.close();
  } finally { t.destroy(); }
});

test('nextBatch: orden por seq, retry solo si vencio, sin sent ni quarantine, limites por filas y bytes', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    for (let i = 0; i < 6; i++) s.ingest(syntheticParsed(i));
    s.applyResults({ sent: [1], quarantine: [{ seq: 2, code: 'X_CODE' }], retry: [{ seq: 3, code: 'RETRY_X', nextRetryAt: NOW + 60000 }], now: NOW });
    let b = s.nextBatch({ now: NOW });
    assert.deepEqual(b.map(r => r.seq), [4, 5, 6], 'retry futuro no bloquea a las filas posteriores');
    b = s.nextBatch({ now: NOW + 61000 });
    assert.deepEqual(b.map(r => r.seq), [3, 4, 5, 6]);
    assert.equal(s.nextBatch({ now: NOW + 61000, limit: 2 }).length, 2);
    const one = Buffer.byteLength(JSON.stringify(b[0].payload)) + 1;
    assert.equal(s.nextBatch({ now: NOW + 61000, maxBytes: one * 2 + 5 }).length, 2, 'limite por bytes');
    assert.equal(s.nextBatch({ now: NOW + 61000, maxBytes: 10 }).length, 1, 'siempre al menos una fila');
    s.close();
  } finally { t.destroy(); }
});
test('payload del lote: 16 claves del contrato v2, receivedAt tomado de la columna', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    const p = syntheticParsed(1);
    s.ingest(p, { receivedAt: '2026-10-20T11:11:11.111Z' });
    const [row] = s.nextBatch({ now: NOW });
    assert.deepEqual(Object.keys(row.payload).sort(), ['eventCode', 'eventKnown', 'gpsValid', 'hash', 'headingDegrees', 'kind', 'latitude', 'longitude',
      'plate', 'plateRaw', 'receivedAt', 'reportedAt', 'speedKmh', 'temperatureRaw', 'temperatureSentinelAssumption', 'temperatures'].sort());
    assert.equal(row.payload.receivedAt, '2026-10-20T11:11:11.111Z');
    assert.equal(row.hash, p.hash);
    s.close();
  } finally { t.destroy(); }
});
test('fila ilegible o con hash inconsistente va a cuarentena sin bloquear a las demas', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    s.ingest(syntheticParsed(1)); s.ingest(syntheticParsed(2)); s.ingest(syntheticParsed(3));
    s.db.prepare("UPDATE spool SET payload_json='{no es json' WHERE seq=1").run();
    s.db.prepare("UPDATE spool SET hash='0'||substr(hash,2) WHERE seq=2").run();
    assert.deepEqual(s.nextBatch({ now: NOW }).map(r => r.seq), [3]);
    assert.equal(s.stats().quarantined, 2);
    assert.deepEqual(s.quarantineSummary().map(q => q.code), ['LOCAL_PAYLOAD_INVALID']);
    s.close();
  } finally { t.destroy(); }
});
test('applyResults: una fila ya resuelta no se vuelve a modificar', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    s.ingest(syntheticParsed(1));
    assert.equal(s.applyResults({ sent: [1], now: NOW }).sent, 1);
    assert.equal(s.applyResults({ quarantine: [{ seq: 1, code: 'X_CODE' }], retry: [{ seq: 1, code: 'R', nextRetryAt: NOW }], now: NOW }).quarantine, 0);
    assert.equal(s.db.prepare('SELECT state FROM spool WHERE seq=1').get().state, 'sent');
    s.close();
  } finally { t.destroy(); }
});
test('poda: sent 72 h y quarantine 7 dias desde su reloj; pending/retry JAMAS; sin reloj no se borra', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    for (let i = 0; i < 6; i++) s.ingest(syntheticParsed(i));
    s.applyResults({ sent: [1, 2], quarantine: [{ seq: 3, code: 'X_CODE' }, { seq: 4, code: 'X_CODE' }], retry: [{ seq: 5, code: 'R', nextRetryAt: NOW }], now: NOW });
    s.db.prepare('UPDATE spool SET sent_at=? WHERE seq=1').run(new Date(NOW - 73 * 3600000).toISOString());   // vencido
    s.db.prepare('UPDATE spool SET sent_at=? WHERE seq=2').run(new Date(NOW - 71 * 3600000).toISOString());   // vigente
    s.db.prepare('UPDATE spool SET quarantined_at=? WHERE seq=3').run(new Date(NOW - 8 * 86400000).toISOString());
    s.db.prepare('UPDATE spool SET quarantined_at=NULL WHERE seq=4').run();                                    // sin reloj
    s.db.prepare("UPDATE spool SET received_at='2020-01-01T00:00:00.000Z' WHERE state IN ('pending','retry')").run();   // muy viejos
    const r = s.pruneForwarded({ now: NOW });
    assert.deepEqual(r, { sentPruned: 1, quarantinePurged: 1 });
    assert.deepEqual(s.db.prepare('SELECT seq FROM spool ORDER BY seq').all().map(x => x.seq), [2, 4, 5, 6]);
    assert.equal(s.db.prepare("SELECT COUNT(*) n FROM audit_events WHERE action='PRUNE_SKIPPED_NO_TRANSITION_CLOCK'").get().n, 1);
    assert.equal(s.stats().counters.sent_pruned, 1);
    s.close();
  } finally { t.destroy(); }
});
test('requeueQuarantine es expreso, mantiene el hash y queda auditado', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    s.ingest(syntheticParsed(1)); s.ingest(syntheticParsed(2));
    const hash = s.db.prepare('SELECT hash FROM spool WHERE seq=1').get().hash;
    s.applyResults({ quarantine: [{ seq: 1, code: 'A_CODE' }, { seq: 2, code: 'B_CODE' }], now: NOW });
    assert.equal(s.requeueQuarantine('A_CODE'), 1);
    assert.equal(s.db.prepare('SELECT state,hash FROM spool WHERE seq=1').get().state, 'pending');
    assert.equal(s.db.prepare('SELECT hash FROM spool WHERE seq=1').get().hash, hash);
    assert.equal(s.db.prepare('SELECT state FROM spool WHERE seq=2').get().state, 'quarantine');
    assert.equal(s.db.prepare("SELECT COUNT(*) n FROM audit_events WHERE action='QUARANTINE_REQUEUED'").get().n, 1);
    s.close();
  } finally { t.destroy(); }
});
test('stats: queueDepth = pending + retry; informa sent y quarantine aparte', () => {
  const t = tmp();
  try {
    const s = new Spool(t.file('q.sqlite'));
    for (let i = 0; i < 4; i++) s.ingest(syntheticParsed(i));
    s.applyResults({ sent: [1], quarantine: [{ seq: 2, code: 'X_CODE' }], retry: [{ seq: 3, code: 'R', nextRetryAt: NOW }], now: NOW });
    const st = s.stats();
    assert.deepEqual([st.queueDepth, st.retrying, st.sentRetained, st.quarantined, st.totalStored], [2, 1, 1, 1, 4]);
    s.close();
  } finally { t.destroy(); }
});
