# Estado y conformidad del fixture Tracer

`Ejemplo_paquetes_SANITIZADO.txt` fue aportado por el usuario el 15/10/2026 y
contiene **12 PC consecutivos de 59 bytes** (708 bytes, ASCII, 12 `|`, SIN newlines).
Las patentes `AAA001`, `AAA002`, `AAA003` son sintéticas; no usar este TXT para
identificar camiones reales. Los mensajes son del 06/09/2018 UTC, agrupados por
patente en bloques 4+5+3; **NO ordenar por fecha global**.

Prueba bloqueante: `npm test` ejecuta `test/fixtureConformance.test.js`.
Verifica offsets, espacio izquierdo de patente (7 posiciones para 6 caracteres),
año de dos dígitos 18=2018, evento `03` al inicio del grupo AAA002,
`+99` => null, crudo +99 conservado, framing en chunks, SQLite y cero ACK.

**Supuesto no confirmado por Tracer:** `+99` significa ausencia de sensor de
temperatura. En el parser se representa como `null` y se preserva el campo
original en `temperatureRaw`; `-99` NO se declara sentinel. Antes de producción,
pedir confirmación expresa a Tracer de la semántica y de posibles otros códigos.

El fixture fue SANITIZADO, no es captura independiente de tráfico TCP real.
Se validó su layout, NO su autenticidad ni la latencia de 60–90 s. Si durante
la prueba el protocolo real difiere (59 bytes ASCII, offsets, delimitador),
STOP: conservar evidencia de manera segura; NO adaptar el parser en vivo.
`PC_SINTETICOS.txt` es un fixture de diseño previo y sigue disponible.

El arranque normal del receptor ejecuta `assertConformanceFixture()` y se detiene
antes de abrir el socket si falta el fixture, cambia su SHA256 o cambian las
interpretaciones críticas. Es un bloqueo deliberado de GATE 0.
