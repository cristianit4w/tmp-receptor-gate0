import crypto from 'node:crypto';

// Contrato HTTPS tracer-http-v1 (propuesta P2). Entrada exacta de firma:
// campos unidos por LF, sin LF final. HMAC-SHA-256 sobre bytes UTF-8.
export const SIGNATURE_SCHEME = 'TRACER-HMAC-V1';
export const INGEST_PATH = '/api/tracer/v1/batches';
export const CONTRACT_VERSION = 'tracer-payload-v2';
export const TRANSPORT_VERSION = 'tracer-http-v1';

export const bodySha256Hex = bodyBytes => crypto.createHash('sha256').update(bodyBytes).digest('hex');

export function signingString({ audience, environment, sourceId, keyId, timestamp, nonce, bodyHashHex, method = 'POST', path = INGEST_PATH }) {
  for (const [name, value] of Object.entries({ audience, environment, sourceId, keyId, nonce, bodyHashHex })) {
    if (typeof value !== 'string' || value === '' || /[\n\r]/.test(value)) throw new Error('SIGNING_FIELD_INVALID:' + name);
  }
  if (!Number.isSafeInteger(timestamp) || timestamp < 0) throw new Error('SIGNING_FIELD_INVALID:timestamp');
  return [SIGNATURE_SCHEME, method, path, audience, environment, sourceId, keyId, String(timestamp), nonce, bodyHashHex].join('\n');
}

export function hmacHex(key, text) {
  return crypto.createHmac('sha256', key).update(text, 'utf8').digest('hex');
}

// 16 bytes aleatorios en base64url sin padding.
export const newNonce = () => crypto.randomBytes(16).toString('base64url');

// Devuelve los headers de autenticacion para un cuerpo ya serializado.
export function signRequest({ key, audience, environment, sourceId, keyId, bodyBytes, now = Date.now(), nonce = newNonce() }) {
  const timestamp = Math.floor(now / 1000);
  const text = signingString({ audience, environment, sourceId, keyId, timestamp, nonce, bodyHashHex: bodySha256Hex(bodyBytes) });
  return {
    'X-Tracer-Source': sourceId,
    'X-Tracer-Key-Id': keyId,
    'X-Tracer-Timestamp': String(timestamp),
    'X-Tracer-Nonce': nonce,
    'X-Tracer-Signature': hmacHex(key, text),
  };
}
