import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const SPOOL_COLUMNS = `
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  hash TEXT NOT NULL UNIQUE, received_at TEXT NOT NULL, reported_at TEXT NOT NULL,
  plate TEXT NOT NULL, gps_valid INTEGER NOT NULL, event_code TEXT NOT NULL,
  event_known INTEGER NOT NULL DEFAULT 1,
  payload_json TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','retry','sent','quarantine')),
  retry_count INTEGER NOT NULL DEFAULT 0, next_retry_at TEXT,
  sent_at TEXT, quarantine_code TEXT, quarantined_at TEXT, last_error_code TEXT`;
// Columnas que existen desde v0.1.x; la copia de la migracion solo usa estas.
const LEGACY_COPY_COLUMNS = 'seq,hash,received_at,reported_at,plate,gps_valid,event_code,event_known,payload_json,state,retry_count,next_retry_at';

export class Spool {
  constructor(filename, { diagnostics = false, rawRetentionHours = 24, maxErrorsRows = 1000, maxSpoolBytes = 134217728, migrate = true } = {}) {
    if (!Number.isSafeInteger(maxErrorsRows) || maxErrorsRows < 1) throw Error('INVALID_MAX_ERRORS_ROWS');
    if (!Number.isSafeInteger(maxSpoolBytes) || maxSpoolBytes < 65536) throw Error('INVALID_MAX_SPOOL_BYTES');
    this.filename = filename;
    this.maxErrorsRows = maxErrorsRows;
    this.maxSpoolBytes = maxSpoolBytes;
    fs.mkdirSync(path.dirname(filename), { recursive: true, mode: 0o750 });
    this.db = new DatabaseSync(filename);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
      PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS last_state (
        plate TEXT PRIMARY KEY, last_reported_at TEXT, last_received_at TEXT,
        last_valid_at TEXT, valid_lat REAL, valid_lon REAL,
        latest_gps_valid INTEGER, latest_event TEXT
      );
      CREATE TABLE IF NOT EXISTS counters (name TEXT PRIMARY KEY, n INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS raw_diagnostic (
        seq INTEGER PRIMARY KEY AUTOINCREMENT, received_at TEXT NOT NULL, raw_hex TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS audit_events (
        seq INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, action TEXT NOT NULL, detail TEXT
      );
      CREATE TABLE IF NOT EXISTS forwarder_state (k TEXT PRIMARY KEY, v TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS errors (
        seq INTEGER PRIMARY KEY AUTOINCREMENT, observed_at TEXT NOT NULL,
        code TEXT NOT NULL, source_ip TEXT, bytes_len INTEGER NOT NULL,
        raw_text TEXT
      );
    `);
    const hasSpool = !!this.db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='spool'").get();
    if (!hasSpool) this.db.exec(`CREATE TABLE spool (${SPOOL_COLUMNS});`);
    else if (migrate) this.migrateSpool();
    this.db.exec('CREATE INDEX IF NOT EXISTS spool_state_seq ON spool(state, seq);');
    this.insert = this.db.prepare(`INSERT INTO spool(hash,received_at,reported_at,plate,gps_valid,event_code,event_known,payload_json)
      VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(hash) DO NOTHING`);
    this.getLast = this.db.prepare('SELECT * FROM last_state WHERE plate=?');
    this.saveLast = this.db.prepare(`INSERT INTO last_state(plate,last_reported_at,last_received_at,last_valid_at,valid_lat,valid_lon,latest_gps_valid,latest_event)
      VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(plate) DO UPDATE SET
        last_reported_at=excluded.last_reported_at,last_received_at=excluded.last_received_at,
        last_valid_at=excluded.last_valid_at,valid_lat=excluded.valid_lat,valid_lon=excluded.valid_lon,
        latest_gps_valid=excluded.latest_gps_valid,latest_event=excluded.latest_event`);
    this.incr = this.db.prepare('INSERT INTO counters(name,n) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET n=n+excluded.n');
    this.insertError = this.db.prepare('INSERT INTO errors(observed_at,code,source_ip,bytes_len,raw_text) VALUES(?,?,?,?,?)');
    this.pruneErrorsStmt = this.db.prepare('DELETE FROM errors WHERE seq NOT IN (SELECT seq FROM errors ORDER BY seq DESC LIMIT ?)');
    // Aplicar el tope tambien a una tabla errors heredada de v0.1.1.
    this.pruneErrorsStmt.run(this.maxErrorsRows);
    this.pruneStmt = this.db.prepare('UPDATE errors SET raw_text=NULL WHERE observed_at < ?');
    this.insertRaw = this.db.prepare('INSERT INTO raw_diagnostic(received_at,raw_hex) VALUES(?,?)');
    this.pruneRawStmt = this.db.prepare('DELETE FROM raw_diagnostic WHERE received_at < ?');
    // Las sentencias del reenviador necesitan las columnas v0.2.0. Con migrate:false sobre una cola
    // heredada (herramientas de solo estadisticas) no se preparan y esas operaciones fallan explicitamente.
    this.forwardReady = this.db.prepare('PRAGMA table_info(spool)').all().some(c => c.name === 'sent_at');
    if (this.forwardReady) {
      this.selectBatchStmt = this.db.prepare(`SELECT seq,hash,received_at,payload_json FROM spool
        WHERE state='pending' OR (state='retry' AND next_retry_at<=?) ORDER BY seq LIMIT ?`);
      this.markSentStmt = this.db.prepare(`UPDATE spool SET state='sent',sent_at=?,next_retry_at=NULL,last_error_code=NULL
        WHERE seq=? AND state IN ('pending','retry')`);
      this.markRetryStmt = this.db.prepare(`UPDATE spool SET state='retry',retry_count=retry_count+1,next_retry_at=?,last_error_code=?
        WHERE seq=? AND state IN ('pending','retry')`);
      this.markQuarantineStmt = this.db.prepare(`UPDATE spool SET state='quarantine',quarantine_code=?,quarantined_at=?,next_retry_at=NULL
        WHERE seq=? AND state IN ('pending','retry')`);
    }
    this.diagnostics = diagnostics;
    this.rawRetentionHours = Math.min(24, Math.max(1, rawRetentionHours));
  }

  // Migracion idempotente a v0.2.0. SQLite no permite cambiar un CHECK con ALTER,
  // asi que se reconstruye la tabla dentro de UNA transaccion, verificando conteos.
  // Conserva seq, estados, reintentos y el contador AUTOINCREMENT.
  migrateSpool() {
    const cols = this.db.prepare('PRAGMA table_info(spool)').all().map(c => c.name);
    if (!cols.includes('event_known')) this.db.exec('ALTER TABLE spool ADD COLUMN event_known INTEGER NOT NULL DEFAULT 1');
    const ddl = this.db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='spool'").get().sql;
    if (/quarantine/.test(ddl) && cols.includes('sent_at')) return false;
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const old = this.db.prepare('SELECT COUNT(*) n FROM spool').get().n;
      const oldSeq = this.db.prepare("SELECT seq FROM sqlite_sequence WHERE name='spool'").get()?.seq ?? 0;
      this.db.exec(`CREATE TABLE spool_v020 (${SPOOL_COLUMNS});
        INSERT INTO spool_v020(${LEGACY_COPY_COLUMNS}) SELECT ${LEGACY_COPY_COLUMNS} FROM spool ORDER BY seq;`);
      const copied = this.db.prepare('SELECT COUNT(*) n FROM spool_v020').get().n;
      if (copied !== old) throw new Error(`SPOOL_MIGRATION_COUNT_MISMATCH:${old}:${copied}`);
      this.db.exec('DROP TABLE spool; ALTER TABLE spool_v020 RENAME TO spool;');
      const cur = this.db.prepare("SELECT seq FROM sqlite_sequence WHERE name='spool'").get();
      if (!cur) this.db.prepare("INSERT INTO sqlite_sequence(name,seq) VALUES('spool',?)").run(oldSeq);
      else if (cur.seq < oldSeq) this.db.prepare("UPDATE sqlite_sequence SET seq=? WHERE name='spool'").run(oldSeq);
      this.db.exec('COMMIT');
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
    return true;
  }

  // Fisico, incluidos archivos WAL/SHM: es un umbral de seguridad, no una cuota OS exacta.
  spoolBytes() {
    return [this.filename, this.filename + '-wal', this.filename + '-shm'].reduce((sum, f) => {
      try { return sum + fs.statSync(f).size; } catch (e) { if (e.code === 'ENOENT') return sum; throw e; }
    }, 0);
  }
  capacity() {
    const bytes = this.spoolBytes();
    const ratio = bytes / this.maxSpoolBytes;
    return {bytes, limitBytes:this.maxSpoolBytes,
      utilization:Number(ratio.toFixed(4)),
      status:ratio >= 0.95 ? 'critical' : ratio >= 0.80 ? 'warning' : 'ok',
      nearingLimit:ratio >= 0.80, acceptingFrames:ratio < 0.95};
  }
  count(name, n = 1) { this.incr.run(name, n); }
  ingest(parsed, { receivedAt = new Date().toISOString(), rawFrame = null } = {}) {
    // Dejar margen previo al 100%: si no hay espacio, rechazar explícitamente.
    // Tracer no reenvia, asi que la alerta de salud debe llegar ANTES (80%).
    if (!this.capacity().acceptingFrames) {
      const error = new Error('SPOOL_CAPACITY_EXCEEDED'); error.code = 'SPOOL_CAPACITY_EXCEEDED'; throw error;
    }
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const r = this.insert.run(parsed.hash, receivedAt, parsed.reportedAt, parsed.plate,
        parsed.gpsValid ? 1 : 0, parsed.eventCode, parsed.eventKnown === false ? 0 : 1, JSON.stringify(parsed));
      // Raw diagnostico se registra por CADA frame valido, incluidos duplicados,
      // para reconciliar el contador de frames con el stream TCP (purga <=24h).
      if (this.diagnostics && rawFrame !== null) this.insertRaw.run(receivedAt, Buffer.from(rawFrame).toString('hex'));
      if (parsed.eventKnown === false) this.count('events_unknown');
      if (r.changes === 0) {
        this.count('duplicates');
        this.db.exec('COMMIT');
        return 'duplicate';
      }
      if (parsed.eventKnown === false) this.count('events_unknown_unique');
      const last = this.getLast.get(parsed.plate);
      const newReport = !last?.last_reported_at || parsed.reportedAt >= last.last_reported_at;
      const newValid = parsed.gpsValid && (!last?.last_valid_at || parsed.reportedAt >= last.last_valid_at);
      this.saveLast.run(parsed.plate,
        newReport ? parsed.reportedAt : last.last_reported_at,
        newReport ? receivedAt : last.last_received_at,
        newValid ? parsed.reportedAt : (last?.last_valid_at ?? null),
        newValid ? parsed.latitude : (last?.valid_lat ?? null),
        newValid ? parsed.longitude : (last?.valid_lon ?? null),
        newReport ? (parsed.gpsValid ? 1 : 0) : last.latest_gps_valid,
        newReport ? parsed.eventCode : last.latest_event);
      this.count('stored');
      this.db.exec('COMMIT');
      return 'stored';
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
  }
  error(code, sourceIp = null, bytes = Buffer.alloc(0)) {
    if (!Buffer.isBuffer(bytes)) bytes = Buffer.from(bytes);
    const safeRaw = this.diagnostics && bytes.length <= 59 ? bytes.toString('hex') : null;
    // Limitar el numero de filas sin perder la metrica acumulada en counters.
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.insertError.run(new Date().toISOString(), code, sourceIp, bytes.length, safeRaw);
      this.pruneErrorsStmt.run(this.maxErrorsRows);
      this.count('error_' + code);
      this.db.exec('COMMIT');
    } catch(e) { this.db.exec('ROLLBACK'); throw e; }
  }
  pruneRaw(now = Date.now()) {
    const cutoff = new Date(now - this.rawRetentionHours * 3600000).toISOString();
    return this.pruneStmt.run(cutoff).changes + this.pruneRawStmt.run(cutoff).changes;
  }
  purgeDiagnosticRaw() {
    const a = this.db.prepare('DELETE FROM raw_diagnostic').run().changes;
    const b = this.db.prepare('UPDATE errors SET raw_text=NULL WHERE raw_text IS NOT NULL').run().changes;
    return {rawFramesRemoved:a,errorRawRedacted:b};
  }

  // ---- Cola hacia el destino (reenviador) ----
  // Filas elegibles: pending, y retry cuyo next_retry_at ya vencio. Orden de seq.
  // Omite sent y quarantine. Devuelve el objeto del contrato v2 (16 claves) por fila.
  nextBatch({ limit = 500, maxBytes = 524288, now = Date.now() } = {}) {
    const out = [];
    let bytes = 0;
    for (const r of this.selectBatchStmt.all(new Date(now).toISOString(), limit)) {
      let payload;
      try { payload = JSON.parse(r.payload_json); } catch { payload = null; }
      if (!payload || typeof payload !== 'object' || payload.hash !== r.hash) {
        // Fila ilegible o inconsistente: no se puede enviar; se aisla sin bloquear el resto.
        this.applyResults({ quarantine: [{ seq: r.seq, code: 'LOCAL_PAYLOAD_INVALID' }], now });
        continue;
      }
      payload.receivedAt = r.received_at;
      const size = Buffer.byteLength(JSON.stringify(payload)) + 1;
      if (out.length && bytes + size > maxBytes) break;
      out.push({ seq: r.seq, hash: r.hash, payload });
      bytes += size;
    }
    return out;
  }
  // Resuelve filas en UNA transaccion. Una fila ya resuelta no se modifica.
  applyResults({ sent = [], retry = [], quarantine = [], now = Date.now() } = {}) {
    const nowIso = new Date(now).toISOString();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      let nSent = 0, nRetry = 0, nQuar = 0;
      for (const seq of sent) nSent += this.markSentStmt.run(nowIso, seq).changes;
      for (const r of retry) nRetry += this.markRetryStmt.run(new Date(r.nextRetryAt).toISOString(), String(r.code ?? 'RETRY'), r.seq).changes;
      for (const q of quarantine) nQuar += this.markQuarantineStmt.run(String(q.code ?? 'QUARANTINE'), nowIso, q.seq).changes;
      if (nSent) this.count('forwarder_sent', nSent);
      if (nRetry) this.count('forwarder_rows_retry', nRetry);
      if (nQuar) this.count('forwarder_quarantined', nQuar);
      this.db.exec('COMMIT');
      return { sent: nSent, retry: nRetry, quarantine: nQuar };
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
  }
  // Registro de acciones manuales / incidencias (sin datos de la flota).
  audit(action, detail = {}) {
    this.db.prepare('INSERT INTO audit_events(at,action,detail) VALUES(?,?,?)').run(new Date().toISOString(), action, JSON.stringify(detail));
  }
  getState(key) { return this.db.prepare('SELECT v FROM forwarder_state WHERE k=?').get(key)?.v ?? null; }
  setState(key, value) { this.db.prepare('INSERT INTO forwarder_state(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(key, String(value)); }
  retryCount(seq) { return this.db.prepare('SELECT retry_count n FROM spool WHERE seq=?').get(seq)?.n ?? 0; }
  // Poda lo ya confirmado y la cuarentena vencida. Nunca toca pending/retry.
  pruneForwarded({ now = Date.now(), sentRetentionHours = 72, quarantineRetentionDays = 7 } = {}) {
    const sentCut = new Date(now - sentRetentionHours * 3600000).toISOString();
    const quarCut = new Date(now - quarantineRetentionDays * 86400000).toISOString();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const s = this.db.prepare("DELETE FROM spool WHERE state='sent' AND sent_at<?").run(sentCut).changes;
      const q = this.db.prepare("DELETE FROM spool WHERE state='quarantine' AND quarantined_at<?").run(quarCut).changes;
      // Sin reloj de transicion demostrable la fila se CONSERVA y se registra la incidencia.
      const noClock = this.db.prepare("SELECT COUNT(*) n FROM spool WHERE (state='sent' AND sent_at IS NULL) OR (state='quarantine' AND quarantined_at IS NULL)").get().n;
      if (noClock) this.audit('PRUNE_SKIPPED_NO_TRANSITION_CLOCK', { rows: Number(noClock) });
      if (s) this.count('sent_pruned', s);
      if (q) this.count('quarantine_purged', q);
      this.db.exec('COMMIT');
      return { sentPruned: s, quarantinePurged: q };
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
  }
  // Reproceso EXPRESO de cuarentena (no automatico). Mantiene el hash original.
  requeueQuarantine(code = null) {
    const r = code === null
      ? this.db.prepare("UPDATE spool SET state='pending',retry_count=0,next_retry_at=NULL,quarantine_code=NULL,quarantined_at=NULL WHERE state='quarantine'").run()
      : this.db.prepare("UPDATE spool SET state='pending',retry_count=0,next_retry_at=NULL,quarantine_code=NULL,quarantined_at=NULL WHERE state='quarantine' AND quarantine_code=?").run(code);
    if (r.changes) { this.count('quarantine_requeued', Number(r.changes)); this.audit('QUARANTINE_REQUEUED', { code, rows: Number(r.changes) }); }
    return Number(r.changes);
  }
  quarantineSummary() {
    return this.db.prepare("SELECT quarantine_code code, COUNT(*) n, MIN(quarantined_at) desde FROM spool WHERE state='quarantine' GROUP BY 1 ORDER BY 2 DESC").all();
  }

  stats() {
    const row = this.db.prepare(`SELECT COUNT(*) total,
       SUM(CASE WHEN state='pending' THEN 1 ELSE 0 END) pending,
       SUM(CASE WHEN state='retry' THEN 1 ELSE 0 END) retry,
       SUM(CASE WHEN state='sent' THEN 1 ELSE 0 END) sent,
       SUM(CASE WHEN state='quarantine' THEN 1 ELSE 0 END) quarantine,
       MIN(CASE WHEN state IN ('pending','retry') THEN received_at ELSE NULL END) oldest_pending_at,
       ${this.forwardReady ? "MIN(CASE WHEN state='quarantine' THEN quarantined_at ELSE NULL END)" : 'NULL'} oldest_quarantine_at FROM spool`).get();
    const counters = Object.fromEntries(this.db.prepare('SELECT name,n FROM counters ORDER BY name').all().map(r => [r.name,r.n]));
    const pending = Number(row.pending ?? 0), retry = Number(row.retry ?? 0);
    return { queueDepth: pending + retry, retrying: retry, sentRetained: Number(row.sent ?? 0), quarantined: Number(row.quarantine ?? 0),
      totalStored: Number(row.total ?? 0), oldestPendingAt: row.oldest_pending_at, oldestQuarantineAt: row.oldest_quarantine_at,
      counters, spoolCapacity: this.capacity(), errorsRetained: this.db.prepare('SELECT COUNT(*) n FROM errors').get().n };
  }
  last(plate) { return this.getLast.get(plate); }
  close() { this.db.close(); }
}
