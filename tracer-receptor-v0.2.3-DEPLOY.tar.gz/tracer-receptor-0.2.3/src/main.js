import { startReceiver } from './server.js';
import { assertConformanceFixture } from './fixtureGate.js';
import { loadConfig } from './config.js';

// Valida y construye TODA la configuracion antes de abrir puertos. Cualquier error
// (modo, perfil, URL, clave, permisos) impide el arranque; no hay fallback a produccion.
const cfg = loadConfig(process.env);
// No iniciar el TCP listener si no pasa la conformidad de 12 PC sanitizados.
assertConformanceFixture();
const receiver = startReceiver({
  ...cfg.receiver,
  forwarder: cfg.forwarder,
  retention: cfg.retention,
  modeLabel: cfg.mode === 'gate0' ? 'DIAGNOSTIC_LOCAL_ONLY' : undefined,
});
let stopping = false;
async function stop(sig) { if (stopping) return; stopping = true; console.log(JSON.stringify({ event: 'stop', signal: sig })); await receiver.close(); process.exit(0); }
process.on('SIGTERM', () => stop('SIGTERM'));
process.on('SIGINT', () => stop('SIGINT'));
