import net from 'node:net';

// Check de segundo perimetro. El firewall Lightsail sigue siendo primario.
export function normalizeIP(ip) {
  if (typeof ip !== 'string') return '';
  const m = /^::ffff:(\d+\.\d+\.\d+\.\d+)$/i.exec(ip);
  return m && net.isIP(m[1]) === 4 ? m[1] : ip;
}
export function createSourcePolicy(raw = '') {
  const entries = Array.isArray(raw) ? raw : String(raw ?? '').split(',');
  const sources = entries.map(x => String(x).trim()).filter(Boolean);
  if (!sources.length) return {restricted:false, allows:()=>true, entries:[]};
  const block = new net.BlockList();
  for (const item of sources) {
    const bits = item.split('/');
    if (bits.length > 2 || !net.isIP(bits[0])) throw Error('INVALID_ALLOWED_SOURCES: ' + item);
    const family = net.isIP(bits[0]) === 4 ? 'ipv4' : 'ipv6';
    if (bits.length === 1) block.addAddress(bits[0], family);
    else {
      const max = family === 'ipv4' ? 32 : 128;
      const prefix = Number(bits[1]);
      if (!/^\d+$/.test(bits[1]) || !Number.isInteger(prefix) || prefix < 0 || prefix > max)
        throw Error('INVALID_ALLOWED_SOURCES: ' + item);
      block.addSubnet(bits[0], prefix, family);
    }
  }
  return {restricted:true, entries:sources, allows:address=>{
    const ip=normalizeIP(address);
    const kind=net.isIP(ip) === 4 ? 'ipv4' : net.isIP(ip) === 6 ? 'ipv6' : null;
    return kind ? block.check(ip, kind) : false;
  }};
}
