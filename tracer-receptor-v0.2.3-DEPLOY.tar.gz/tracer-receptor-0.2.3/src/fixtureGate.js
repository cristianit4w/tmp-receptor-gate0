// Gate de conformidad offline obligatorio antes de abrir el listener de Tracer.
// 12 PC SANITIZADOS (patentes sinteticas), NO evidencia de trafico vivo.
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { parsePC } from './parser.js';

export const FIXTURE_SHA256 = 'cf9a0e70baae43be9c9b171ca877eb9bca1de12c125aa01962c1dcdb88e1976f';
const defaultPath = fileURLToPath(new URL('../fixtures/Ejemplo_paquetes_SANITIZADO.txt', import.meta.url));
export function assertConformanceFixture(filename = defaultPath) {
  const fail = reason => { throw new Error('GATE0_CONFORMANCE_FIXTURE_FAILED: ' + reason); };
  let b;
  try { b = fs.readFileSync(filename); } catch { return fail('fixture absent/unreadable'); }
  if (b.length !== 708 || b.includes(10) || b.includes(13) || b.at(-1) !== 124)
    fail('expected exactly 708 bytes, no newline, ending in |');
  if (crypto.createHash('sha256').update(b).digest('hex') !== FIXTURE_SHA256)
    fail('SHA256 differs from validated sanitized fixture');
  const frames=b.toString('ascii').split('|').slice(0,-1).map(x=>Buffer.from(x+'|','ascii'));
  if(frames.length !== 12 || frames.some(x=>x.length !== 59))fail('expected exactly 12 PC frames of 59 bytes');
  let parsed;
  try { parsed=frames.map(parsePC); } catch(e) { return fail(e.code || e.message); }
  const groups=['AAA001','AAA001','AAA001','AAA001','AAA002','AAA002','AAA002','AAA002','AAA002','AAA003','AAA003','AAA003'];
  if(parsed.some((p,i)=>p.kind!=='PC'||p.plate!==groups[i]||p.plateRaw!==' '+groups[i]
    || !p.reportedAt.startsWith('2018-09-06T')
    || p.temperatures.some(t=>t!==null)
    || p.temperatureRaw.some(t=>t!=='+99')
    || p.temperatureSentinelAssumption!=='PLUS_99_NO_SENSOR_UNCONFIRMED'))
    fail('parsed offsets, plate padding, UTC year or +99 assumption mismatch');
  if(parsed[4].eventCode!=='03'||!(parsed[4].reportedAt<parsed[3].reportedAt))
    fail('event 03 / cross-plate nonchronological ordering mismatch');
  return Object.freeze({frames:12,bytes:708,groups:[4,5,3],hash:FIXTURE_SHA256});
}
