import http from 'node:http';
import crypto from 'node:crypto';

// Destino HTTPS SIMULADO del contrato tracer-http-v1 (rev. 1.2). Solo para pruebas locales y
// para el ensayo G3 contra datos sinteticos. NO es el destino real y NO guarda nada en disco.
// La verificacion HMAC esta escrita con `crypto` directo (independiente de src/signing.js)
// para que los tests comprueben la compatibilidad entre dos implementaciones.
const ROW_KEYS = ['kind','hash','reportedAt','receivedAt','plate','plateRaw','latitude','longitude','speedKmh','headingDegrees',
  'gpsValid','eventCode','eventKnown','temperatures','temperatureRaw','temperatureSentinelAssumption'];

export function startMockIngest({ key, audience, environment, sourceId, keyId, path = '/api/tracer/v1/batches', fault = null, now = () => Date.now() }) {
  const nonces = new Set();
  const store = new Map();            // hash -> payload (confirmado/commiteado)
  const requests = [];                // metadatos por request (sin datos de flota)
  let inflight = 0, maxInflight = 0;
  const server = http.createServer((req, res) => {
    inflight++; maxInflight = Math.max(maxInflight, inflight);
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', async () => {
      const body = Buffer.concat(chunks);
      const meta = { method: req.method, url: req.url, headers: req.headers, bytes: body.length, auth: null, rows: 0, status: null };
      requests.push(meta);
      const reply = (status, obj, headers = {}) => {
        meta.status = status;
        const text = obj === undefined ? '' : (typeof obj === 'string' ? obj : JSON.stringify(obj));
        res.writeHead(status, { 'Content-Type': 'application/json', ...headers });
        res.end(text);
        inflight--;
      };
      try {
        if (req.method !== 'POST' || req.url !== path) return reply(404, { code: 'NOT_FOUND' });
        const h = req.headers;
        const canonical = ['TRACER-HMAC-V1', 'POST', path, audience, environment, h['x-tracer-source'], h['x-tracer-key-id'],
          h['x-tracer-timestamp'], h['x-tracer-nonce'], crypto.createHash('sha256').update(body).digest('hex')].join('\n');
        const expected = crypto.createHmac('sha256', key).update(canonical, 'utf8').digest('hex');
        const given = String(h['x-tracer-signature'] ?? '');
        const sigOk = given.length === expected.length && crypto.timingSafeEqual(Buffer.from(given), Buffer.from(expected));
        const skew = Math.abs(Math.floor(now() / 1000) - Number(h['x-tracer-timestamp']));
        meta.auth = { sigOk, skew, source: h['x-tracer-source'], keyId: h['x-tracer-key-id'], nonce: h['x-tracer-nonce'] };
        if (h['x-tracer-source'] !== sourceId || h['x-tracer-key-id'] !== keyId || !sigOk || !(skew <= 300)) return reply(401, { code: 'UNAUTHORIZED' });
        if (fault) {
          const f = typeof fault === 'function' ? await fault(meta, requests.length) : undefined;
          if (f?.hang) { inflight--; return; }
          if (f?.destroy) { inflight--; return req.socket.destroy(); }
          if (f && f.status !== undefined) return reply(f.status, f.body, f.headers);
        }
        if (nonces.has(h['x-tracer-nonce'])) return reply(409, { code: 'REPLAY' });
        let parsed;
        try { parsed = JSON.parse(body.toString('utf8')); } catch { return reply(400, { code: 'INVALID_JSON' }); }
        if (parsed.contractVersion !== 'tracer-payload-v2' || parsed.transportVersion !== 'tracer-http-v1' || !Array.isArray(parsed.rows)) return reply(400, { code: 'INVALID_ENVELOPE' });
        if (parsed.rows.length === 0) return reply(400, { code: 'EMPTY_BATCH' });
        if (parsed.rows.length > 500 || body.length > 524288) return reply(413, { code: 'PAYLOAD_TOO_LARGE' });
        nonces.add(h['x-tracer-nonce']);   // tras validar HMAC, junto con el ingreso
        meta.rows = parsed.rows.length;
        const acks = parsed.rows.map((row, index) => {
          const keys = Object.keys(row ?? {}).sort().join(',');
          if (!row || keys !== [...ROW_KEYS].sort().join(',')) return { index, hash: null, status: 'rechazada', permanent: true, code: 'INVALID_KIND' };
          if (row.kind !== 'PC') return { index, hash: row.hash, status: 'rechazada', permanent: true, code: 'PS_UNSUPPORTED_BY_SCOPE' };
          if (!/^[0-9a-f]{64}$/.test(row.hash)) return { index, hash: null, status: 'rechazada', permanent: true, code: 'INVALID_HASH' };
          if (typeof fault?.rowStatus === 'function') { const r = fault.rowStatus(row, index); if (r) return { index, hash: row.hash, ...r }; }
          if (store.has(row.hash)) return { index, hash: row.hash, status: 'duplicada' };
          store.set(row.hash, row);
          return { index, hash: row.hash, status: 'insertada' };
        });
        const counts = {};
        for (const a of acks) counts[a.status] = (counts[a.status] ?? 0) + 1;
        const ack = { ackVersion: '1', batchId: parsed.batchId, rows: acks, counts };
        if (typeof fault?.afterCommit === 'function') { const f = fault.afterCommit(meta); if (f?.destroy) { inflight--; return req.socket.destroy(); } if (f?.ack) return reply(200, f.ack(ack)); }
        return reply(200, ack);
      } catch (e) { return reply(500, { code: 'MOCK_ERROR' }); }
    });
  });
  return new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve({
    server, store, requests, nonces,
    url: `http://127.0.0.1:${server.address().port}${path}`,
    maxInflight: () => maxInflight,
    close: () => new Promise(r => { server.closeAllConnections?.(); server.close(r); }),
  })));
}
