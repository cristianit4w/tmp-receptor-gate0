import { INGEST_PATH } from './signing.js';

// Literales del contrato HTTPS P2 rev. 1.2 (CONFIG_CONTRATO_P2.json). No son hosts ni
// proyectos descubiertos. Se usan exactamente; `prod` NO es alias de `production`.
export const PROFILES = Object.freeze({
  staging: Object.freeze({
    audience: 'bymones-tracer-ingesta-staging',
    environment: 'staging',
    sourceId: 'bymones-tracer-staging-01',
    keyId: 'bymones-tracer-staging-k01',
  }),
  production: Object.freeze({
    audience: 'bymones-tracer-ingesta-production',
    environment: 'production',
    sourceId: 'bymones-tracer-production-01',
    keyId: 'bymones-tracer-production-k01',
  }),
});
export { INGEST_PATH };
