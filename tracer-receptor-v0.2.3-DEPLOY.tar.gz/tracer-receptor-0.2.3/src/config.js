import fs from 'node:fs';
import path from 'node:path';
import { PROFILES, INGEST_PATH } from './profiles.js';

const intIn = (env, key, dflt, min, max) => {
  const raw = env[key] ?? String(dflt);
  const n = Number(raw);
  if (raw === '' || !Number.isInteger(n) || n < min || n > max) throw Error(`${key} out of range`);
  return n;
};
const flag = (env, key) => {
  const v = env[key];
  if (v === undefined || v === '' || v === 'false') return false;
  if (v === 'true') return true;
  throw Error(`${key} must be true or false`);
};

// Clave HMAC desde ARCHIVO (no desde una variable de entorno): hex o base64url, >= 32 bytes.
export function readHmacKey(file, { statSync = fs.statSync, readFileSync = fs.readFileSync } = {}) {
  const st = statSync(file);
  if (!st.isFile()) throw Error('FORWARDER_KEY_FILE must be a regular file');
  // Sin lectura de "otros" ni escritura de grupo (mismo criterio que una clave SSH).
  if ((st.mode & 0o007) !== 0 || (st.mode & 0o022) !== 0) throw Error('FORWARDER_KEY_FILE permissions too open (use 0640 or 0600)');
  const text = String(readFileSync(file, 'utf8')).trim();
  const key = /^[0-9a-fA-F]{64,}$/.test(text) && text.length % 2 === 0 ? Buffer.from(text, 'hex')
    : /^[A-Za-z0-9_-]{43,}$/.test(text) ? Buffer.from(text, 'base64url') : null;
  if (!key || key.length < 32) throw Error('FORWARDER_KEY_FILE must hold >= 32 bytes as hex or base64url');
  return key;
}

function forwarderConfig(env, sqlitePath, io) {
  const profileName = env.FORWARDER_PROFILE;
  const profile = PROFILES[profileName];
  if (!profile) throw Error('FORWARDER_PROFILE must be staging or production');
  // Los literales no se eligen libremente: si se declaran, deben coincidir con el perfil.
  for (const [envKey, field] of [['FORWARDER_AUDIENCE', 'audience'], ['FORWARDER_ENVIRONMENT', 'environment'], ['FORWARDER_SOURCE_ID', 'sourceId'], ['FORWARDER_KEY_ID', 'keyId']]) {
    if (env[envKey] !== undefined && env[envKey] !== '' && env[envKey] !== profile[field]) throw Error(`${envKey} does not match profile ${profileName}`);
  }
  if (profileName === 'production' && env.FORWARDER_PRODUCTION_AUTHORIZATION !== 'G5') {
    throw Error('FORWARDER production requires FORWARDER_PRODUCTION_AUTHORIZATION=G5 (approved gate)');
  }
  if (profileName === 'staging' && !path.basename(sqlitePath).startsWith('staging')) {
    throw Error('FORWARDER staging requires a separate spool (SQLITE_PATH basename must start with "staging")');
  }
  let url;
  try { url = new URL(env.FORWARDER_URL ?? ''); } catch { throw Error('FORWARDER_URL invalid'); }
  const local = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && local && profileName === 'staging' && flag(env, 'FORWARDER_ALLOW_LOCAL_HTTP'))) {
    throw Error('FORWARDER_URL must be https');
  }
  if (url.username || url.password || url.search || url.hash || url.pathname !== INGEST_PATH) throw Error(`FORWARDER_URL path must be exactly ${INGEST_PATH} without credentials or query`);
  if (!env.FORWARDER_KEY_FILE) throw Error('FORWARDER_KEY_FILE required');
  return {
    ...profile,
    url: url.toString(),
    key: readHmacKey(env.FORWARDER_KEY_FILE, io),
    maxRows: intIn(env, 'FORWARDER_MAX_ROWS', 500, 1, 500),
    maxBodyBytes: intIn(env, 'FORWARDER_MAX_BODY_BYTES', 524288, 4096, 524288),
    flushIntervalMs: intIn(env, 'FORWARDER_FLUSH_SECONDS', 15, 1, 300) * 1000,
    requestTimeoutMs: intIn(env, 'FORWARDER_REQUEST_TIMEOUT_SECONDS', 15, 1, 60) * 1000,
  };
}

// Devuelve la configuracion del receptor a partir de variables de entorno.
// RECEIVER_MODE=gate0   : comportamiento v0.1.2 (diagnostico forzado, sin reenviador).
// RECEIVER_MODE=standard: v0.2.0. Diagnostico configurable; reenviador APAGADO salvo FORWARDER_ENABLED=true.
export function loadConfig(env = process.env, io = {}) {
  const mode = env.RECEIVER_MODE;
  if (mode !== 'gate0' && mode !== 'standard') throw Error('RECEIVER_MODE must be gate0 or standard');
  const sqlitePath = env.SQLITE_PATH ?? './data/spool.sqlite';
  let diagnostics, forwarder = null;
  if (mode === 'gate0') {
    if (env.DB_FORWARDER && env.DB_FORWARDER !== 'false') throw Error('GATE0: DB_FORWARDER MUST be false');
    if (env.DIAGNOSTIC_MODE !== 'true') throw Error('GATE0: DIAGNOSTIC_MODE must be true');
    if (flag(env, 'FORWARDER_ENABLED')) throw Error('GATE0: FORWARDER_ENABLED not allowed in gate0 mode');
    diagnostics = true;
  } else {
    if (env.DIAGNOSTIC_MODE !== 'true' && env.DIAGNOSTIC_MODE !== 'false') throw Error('DIAGNOSTIC_MODE must be true or false');
    diagnostics = env.DIAGNOSTIC_MODE === 'true';
    if (flag(env, 'FORWARDER_ENABLED')) forwarder = forwarderConfig(env, sqlitePath, io);
  }
  return {
    mode,
    forwarder,
    retention: {
      sentRetentionHours: intIn(env, 'SENT_RETENTION_HOURS', 72, 1, 24 * 30),
      quarantineRetentionDays: intIn(env, 'QUARANTINE_RETENTION_DAYS', 7, 1, 90),
      pruneIntervalSeconds: intIn(env, 'PRUNE_INTERVAL_SECONDS', 86400, 60, 7 * 86400),
    },
    receiver: {
      host: env.TCP_HOST ?? '127.0.0.1',
      port: intIn(env, 'TCP_PORT', 41873, 1, 65535),
      sqlitePath,
      healthPort: intIn(env, 'HEALTH_PORT', 9090, 1, 65535),
      diagnostics,
      maxConnections: intIn(env, 'MAX_ACTIVE_CONNECTIONS', 128, 1, 1000),
      maxConnectionsPerIP: intIn(env, 'MAX_CONNECTIONS_PER_IP', 4, 1, 128),
      allowedSources: env.ALLOWED_SOURCES ?? '',
      maxErrorsRows: intIn(env, 'MAX_ERRORS_ROWS', 1000, 1, 100000),
      maxSpoolBytes: intIn(env, 'MAX_SPOOL_BYTES', 134217728, 65536, 10000000000),
      maxFrames: intIn(env, 'MAX_FRAMES_PER_CONNECTION', 1000, 1, 100000),
      maxConnectionBytes: intIn(env, 'MAX_CONNECTION_BYTES', 262144, 59, 10000000),
      idleTimeoutMs: intIn(env, 'SOCKET_IDLE_TIMEOUT_MS', 8000, 1000, 300000),
      rawRetentionHours: intIn(env, 'RAW_RETENTION_HOURS', 24, 1, 24),
    },
  };
}
