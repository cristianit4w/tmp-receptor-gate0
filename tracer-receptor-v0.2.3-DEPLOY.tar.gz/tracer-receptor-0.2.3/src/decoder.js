import { FrameError, FRAME_LENGTH } from './parser.js';

// State machine per TCP connection: chunking arbitrario, no delimitacion por read().
export class FrameDecoder {
  constructor({ onFrame, onError, maxFrames = 1000 }) {
    this.onFrame = onFrame;
    this.onError = onError;
    this.maxFrames = maxFrames;
    this.pending = Buffer.alloc(0);
    this.frames = 0;
    this.closed = false;
  }
  feed(chunk) {
    if (this.closed) throw new FrameError('DECODER_CLOSED');
    if (!Buffer.isBuffer(chunk)) chunk = Buffer.from(chunk);
    let from = 0;
    for (let i = 0; i < chunk.length; i++) {
      if (chunk[i] !== 0x7c) continue;
      const tail = chunk.subarray(from, i + 1);
      const frame = Buffer.concat([this.pending, tail]);
      this.pending = Buffer.alloc(0);
      from = i + 1;
      this.frames += 1;
      if (this.frames > this.maxFrames) throw new FrameError('TOO_MANY_FRAMES');
      this.onFrame(frame);
    }
    if (from < chunk.length) this.pending = Buffer.concat([this.pending, chunk.subarray(from)]);
    if (this.pending.length > FRAME_LENGTH) throw new FrameError('FRAME_TOO_LONG_UNTERMINATED');
  }
  eof() {
    if (this.closed) return;
    this.closed = true;
    if (this.pending.length > 0) {
      this.onError(new FrameError('EOF_PARTIAL_FRAME', `Residual bytes=${this.pending.length}`));
      this.pending = Buffer.alloc(0);
    }
  }
}
