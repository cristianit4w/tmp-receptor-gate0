import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';
import { Spool } from './spool.js';

// ESPEJO PARA STAGING (v0.2.3). Copia, SOLO LEYENDO, las filas del spool de produccion a un spool aparte
// ("staging-*.sqlite") que drena el reenviador del perfil staging. No toca estados, no borra, no escribe en el
// spool de produccion: el receptor real sigue igual. Idempotente (hash UNICO) y con cursor persistido.
const COLS = 'seq,hash,received_at,reported_at,plate,gps_valid,event_code,event_known,payload_json';
const CURSOR_KEY = 'mirror_last_seq';

export function assertMirrorPaths(sourcePath, targetPath) {
  if (!sourcePath || !targetPath) throw Error('MIRROR requires MIRROR_SOURCE_SPOOL and MIRROR_TARGET_SPOOL');
  if (path.resolve(sourcePath) === path.resolve(targetPath)) throw Error('MIRROR source and target must differ');
  if (!path.basename(targetPath).startsWith('staging')) throw Error('MIRROR target basename must start with "staging"');
  if (path.basename(sourcePath).startsWith('staging')) throw Error('MIRROR source must be the production spool, not a staging one');
  if (!fs.existsSync(sourcePath)) throw Error('MIRROR source spool does not exist');
}

export class Mirror {
  constructor({ sourcePath, targetPath, batch = 1000, maxSpoolBytes = 2147483648 }) {
    assertMirrorPaths(sourcePath, targetPath);
    this.batch = batch;
    this.target = new Spool(targetPath, { maxSpoolBytes });
    // Solo lectura: abrir el spool de produccion con readOnly impide cualquier escritura por error.
    this.src = new DatabaseSync(sourcePath, { readOnly: true });
    this.src.exec('PRAGMA busy_timeout=5000;');
    this.selectStmt = this.src.prepare(`SELECT ${COLS} FROM spool WHERE seq > ? ORDER BY seq LIMIT ?`);
    this.maxStmt = this.src.prepare('SELECT COALESCE(MAX(seq),0) AS m FROM spool');
  }

  cursor() { return Number(this.target.getState(CURSOR_KEY) ?? 0); }

  // Copia un lote. Devuelve { copied, inserted, cursor, behind }.
  once() {
    let cur = this.cursor();
    const max = this.maxStmt.get().m;
    if (cur > max) { this.target.audit('mirror_cursor_reset', { cursor: cur, sourceMax: max }); cur = 0; }   // spool de origen reemplazado
    const rows = this.selectStmt.all(cur, this.batch);
    if (!rows.length) return { copied: 0, inserted: 0, cursor: cur, behind: 0 };
    let inserted = 0;
    this.target.db.exec('BEGIN IMMEDIATE');
    try {
      for (const r of rows) {
        const res = this.target.insert.run(r.hash, r.received_at, r.reported_at, r.plate, r.gps_valid, r.event_code, r.event_known, r.payload_json);
        inserted += Number(res.changes);
      }
      const last = rows[rows.length - 1].seq;
      this.target.setState(CURSOR_KEY, last);
      this.target.db.exec('COMMIT');
      return { copied: rows.length, inserted, cursor: last, behind: Math.max(0, max - last) };
    } catch (e) { this.target.db.exec('ROLLBACK'); throw e; }
  }

  close() { try { this.src.close(); } catch { /* ya cerrada */ } this.target.close(); }
}
