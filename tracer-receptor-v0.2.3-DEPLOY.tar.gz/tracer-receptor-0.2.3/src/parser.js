import crypto from 'node:crypto';

export const FRAME_LENGTH = 59;
export const OFFSETS = Object.freeze({
  header: [0, 2], date: [2, 8], time: [8, 14], plate: [14, 21],
  lat: [21, 30], lon: [30, 40], speed: [40, 43], heading: [43, 46],
  gpsValid: [46, 47], event: [47, 49], t1: [49, 52], t2: [52, 55],
  t3: [55, 58], end: [58, 59],
});

export class FrameError extends Error {
  constructor(code, message = code) { super(message); this.name = 'FrameError'; this.code = code; }
}
const part = (s, k) => s.slice(...OFFSETS[k]);
const exactly = (re, v, code) => { if (!re.test(v)) throw new FrameError(code); return v; };

export function parsePC(frame) {
  if (!Buffer.isBuffer(frame)) frame = Buffer.from(frame, 'utf8');
  if (frame.length >= 2 && frame.subarray(0, 2).toString('ascii') === 'PS')
    throw new FrameError('PS_UNSUPPORTED_BY_SCOPE');
  if (frame.length !== FRAME_LENGTH) throw new FrameError('PC_INVALID_LENGTH', `Expected 59, got ${frame.length}`);
  if (frame[58] !== 0x7c) throw new FrameError('PC_INVALID_TERMINATOR');
  for (const b of frame) if (b > 0x7e || b < 0x20) throw new FrameError('PC_NON_ASCII');
  const s = frame.toString('ascii');
  if (part(s, 'header') !== 'PC') throw new FrameError('PC_BAD_HEADER');
  const d = exactly(/^\d{6}$/, part(s, 'date'), 'PC_BAD_DATE');
  const t = exactly(/^\d{6}$/, part(s, 'time'), 'PC_BAD_TIME');
  const day = Number(d.slice(0, 2)), month = Number(d.slice(2, 4)), year = 2000 + Number(d.slice(4, 6));
  const hour = Number(t.slice(0, 2)), minute = Number(t.slice(2, 4)), second = Number(t.slice(4, 6));
  const ts = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
  if (ts.getUTCFullYear() !== year || ts.getUTCMonth() !== month - 1 || ts.getUTCDate() !== day ||
      ts.getUTCHours() !== hour || ts.getUTCMinutes() !== minute || ts.getUTCSeconds() !== second)
    throw new FrameError('PC_BAD_DATETIME');
  const rawPlate = part(s, 'plate');
  exactly(/^ *[A-Z0-9]{1,7}$/, rawPlate, 'PC_BAD_PLATE');
  const plate = rawPlate.trim();
  const latStr = exactly(/^[+-]\d{2}\.\d{5}$/, part(s, 'lat'), 'PC_BAD_LATITUDE');
  const lonStr = exactly(/^[+-]\d{3}\.\d{5}$/, part(s, 'lon'), 'PC_BAD_LONGITUDE');
  const lat = Number(latStr), lon = Number(lonStr);
  if (Math.abs(lat) > 90) throw new FrameError('PC_LATITUDE_OUT_OF_RANGE');
  if (Math.abs(lon) > 180) throw new FrameError('PC_LONGITUDE_OUT_OF_RANGE');
  const speed = Number(exactly(/^\d{3}$/, part(s, 'speed'), 'PC_BAD_SPEED'));
  const heading = Number(exactly(/^\d{3}$/, part(s, 'heading'), 'PC_BAD_HEADING'));
  if (heading > 360) throw new FrameError('PC_HEADING_OUT_OF_RANGE');
  const gps = exactly(/^[01]$/, part(s, 'gpsValid'), 'PC_BAD_GPS_FLAG') === '1';
  const event = exactly(/^\d{2}$/, part(s, 'event'), 'PC_BAD_EVENT');
  const eventKnown = Number(event) >= 1 && Number(event) <= 11;
  // REGLA PROVISIONAL: en el fixture sanitizado +99 aparece en los tres
  // sensores; el usuario solicita tratarlo como sensor ausente (null).
  // Tracer AUN NO confirmo el sentinela. Preservar el crudo por separado,
  // y no confundir -99 con +99 ni alterar el hash canonico.
  const temperatureRaw = ['t1', 't2', 't3'].map(k => exactly(/^[+-]\d{2}$/, part(s, k), 'PC_BAD_TEMPERATURE'));
  const temps = temperatureRaw.map(v => v === '+99' ? null : Number(v));
  const canonical = JSON.stringify(['PC', ts.toISOString(), plate, latStr, lonStr, speed, heading,
    gps ? 1 : 0, event, ...['t1', 't2', 't3'].map(k => part(s, k))]);
  return Object.freeze({
    kind: 'PC', reportedAt: ts.toISOString(), plate, plateRaw: rawPlate,
    latitude: lat, longitude: lon, speedKmh: speed, headingDegrees: heading,
    gpsValid: gps, eventCode: event, eventKnown, temperatures: temps,
    temperatureRaw, temperatureSentinelAssumption: 'PLUS_99_NO_SENSOR_UNCONFIRMED',
    hash: crypto.createHash('sha256').update(canonical).digest('hex'),
  });
}

export function createSyntheticPC(overrides = {}) {
  const f = {
    date: '131026', time: '153045', plate: 'AB123CD', lat: '-34.60372', lon: '-058.38158',
    speed: '045', heading: '180', gpsValid: '1', event: '01', t1: '+22', t2: '+18', t3: '+00', ...overrides,
  };
  const plate = String(f.plate).padStart(7, ' ');
  const frame = `PC${f.date}${f.time}${plate}${f.lat}${f.lon}${f.speed}${f.heading}${f.gpsValid}${f.event}${f.t1}${f.t2}${f.t3}|`;
  return Buffer.from(frame, 'ascii');
}
