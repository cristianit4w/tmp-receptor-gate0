# RUNBOOK_PRUEBA_TRACER.md — adaptación operativa incluida en paquete GATE 0

**Fuente de referencia:** RUNBOOK_PRUEBA_TRACER.md, versión 1.0 del 14/10/2026, disponible en el espacio del proyecto By Mones. Esta adaptación no modifica ese original. Para comandos de Lightsail y SHA256 ver `HOST_RECEPTOR_RUNBOOK.md`, secciones E–K.

## Estado confirmado para la VM (15/10/2026; informado por el dueño, no verificado vía SSH)

- Lightsail `tracer-receptor` **Running**, São Paulo zona A, Ubuntu 24.04 LTS, 1 GB; IPv4 estática asociada **`18.230.173.65`**. Sin cambios remotos realizados.
- Perímetro: **solo Lightsail IPv4 Firewall**. SSH TCP 22 restringido a IPv4 del dueño `/32` y SSH del navegador. `41873/TCP` **CERRADO**, sin HTTP ni IPv6. **UFW no configurado: no instalar, habilitar ni agregar reglas.** Solo el dueño abre/cierra el puerto desde la consola en cada ventana.
- Antes de instalar: revisar `ls /var/run/reboot-required; uptime -p`; si se requiere reinicio, hacerlo y reconectar. Revisar dos paquetes pendientes; `unattended-upgrades` presente, NTP UTC sincronizado. Endurecer SSH de `PermitRootLogin without-password` a **`PermitRootLogin no`**, comprobar `sshd -t` y `sshd -T` (también `PasswordAuthentication no`) y probar segunda sesión `ubuntu` antes de cerrar primera.
- Snapshot `base-limpia` ya existe; automáticos 21:00 ART diarios, 7 retenidos. Crear **snapshot manual PRE instalación** y **snapshot manual POST validación** en consola, comprobando que terminen. Alerta presupuestaria AWS USD 15/mes no es tope de costo.
- Tracer: solicitudes en preparación, **fecha no agendada**; coordinar **>=48 horas**, exclusivamente **lunes–viernes 11:00–17:00 ART**. Necesita **IPv4 literal** `18.230.173.65`. IP dinámica en prueba; producción sale de `34.39.146.212`, pero **no habilitar producción bajo GATE 0**.
- Preensayo desde PC del dueño: permitir únicamente `TU_IP_PUBLICA/32` a TCP 41873 en Lightsail, cerrar después. Prueba Tracer: preferir IP source `/32` si pueden comunicarla; si no, requerir aceptación explícita del dueño de **Any IPv4 temporal solo durante la ventana**; el dueño elimina regla al terminar. Sin TLS ni ACK.
- Comandos exactos y puertas GO/NO-GO: `HOST_RECEPTOR_RUNBOOK.md` secciones **0, B, C, D, E–K**; no ejecutar un deploy automático.

## Objetivo

Tracer → IPv4 literal:puerto → receptor PC estricto → SQLite WAL + diagnóstico/PCAP **sin Supabase, Postgres, base remota ni forwarder**.

## Coordinación / reglas

- Coordinar **mínimo 48 h** con Tracer, **lunes a viernes 11:00–17:00 ART**. **Aún no hay fecha**. Confirmar hora ART+UTC, unidades, responsables, `18.230.173.65:41873`.
- Solo `PC` 59 bytes ASCII incluidos `|`, `PS` rechazado; N frames por conexión, cierre del socket como fin del lote; cero ACK y cero replay.
- Tracer prueba desde IP **dinámica**: permitir IP de Tracer `/32` si confirma la actual; caso contrario solo con permiso expreso del dueño, `0.0.0.0/0` temporal durante ventana acordada. Abrir y cerrar **siempre en Lightsail IPv4 Firewall por el dueño**. Preensayo desde PC propia: solo `TU_IP/32`.
- Tráfico real SIN TLS; no habilitar fuera de ventana.

## Antes: GO solo cuando

1. reinicio pendiente revisado, SSH endurecido y verificado, snapshot manual PRE completo y snapshot manual POST tras ensayo local; tests parser/framing/spool/ACK y las 12 pruebas de conformidad del `Ejemplo_paquetes_SANITIZADO.txt` pasen; cualquier discrepancia de layout en TCP real obliga STOP;
2. liveness y SQLite persistente tras restart;
3. `RECEIVER_MODE=gate0`, `DIAGNOSTIC_MODE=true`, `DB_FORWARDER=false`;
4. límites bytes, conexiones, frames y timeout activados;
5. reloj sincronizado y disco holgado; pruebas de cierre del firewall exitosas;
6. PCAP acotada y crudo diagnóstico con purga <=24h;
7. personas disponibles para abrir/cerrar la regla.

## Secuencia temporal

- **T-15 min**: `systemctl status`, `curl http://127.0.0.1:9090/live`, contador baseline, `timedatectl`, espacio disco.
- **T-10 min**: dueño permite temporalmente 41873 en Lightsail IPv4 Firewall con source aprobado, únicamente para esta ventana; iniciar PCAP límite 3×5 MB/20 min.
- **T-5 min**: reconfirmar IP:puerto, hora y 1 unidad con Tracer.
- **T+0 min**: Tracer habilita 1 unidad, observar primera conexión, bytes, frames PC y EOF.
- Comparar `59` bytes/`|`, offsets, matrícula/padding, fecha/hora UTC, latencia típica 60–90 s (sin suponer puntualidad), GPS inválido, PS si llega.
- Revisar 0 bytes de aplicación enviados, contadores `frames_valid = stored + duplicates` (dentro de la ventana), y reconciliar frames con PCAP limitado.
- Reinicio controlado **solo** si Tracer acuerda repetir: demostrar SQLite durable, jamás inferir replay del proveedor.
- Repetir con segundo lote/unidad si está disponible.
- **T+fin**: Tracer suspende, **dueño borra inmediatamente la regla Lightsail TCP 41873**; desde PC comprobar puerto cerrado. No hay ni se debe crear regla UFW.
- Exportar sólo resumen saneado; fixture sanitizado ya disponible con placas AAA001–AAA003; no sustituye captura real de TCP; purgar crudo y PCAP <=24h.

## NO-GO inmediato

Un PC distinto de 59, bytes inesperados, múltiples layouts, cambio de source no acordado, cierre con truncados recurrentes, spool/count descuadrado, IP abierta sin responsable, o imposibilidad de borrar firewall. **No adaptar parser en caliente.**

## Informe

Registrar fecha/hora, unidad sintética, conexiones, bytes, frames/conn min-p50-max, valid/invalid, latencia p50/p95/max, GPS inválido, reinicio, conteos PCAP/spool, cero ACK, cierre de firewall y decisión GO/NO-GO. No adjuntar raw ni PCAP a tickets públicos.


## Anexo GATE 0 v0.1.2 (no modifica la autorización de pruebas)

Antes de la ventana: `npm test` (41/41 como mínimo en el paquete entregado), verificar el fixture sanitizado de 12 mensajes y consultar `/live` para revisar `spoolCapacity` (`status=ok`, sin alerta), bytes disponibles y estado del listener. Verificar `MAX_ACTIVE_CONNECTIONS=128`, `MAX_CONNECTIONS_PER_IP=4`, `SOCKET_IDLE_TIMEOUT_MS=8000`, `MAX_ERRORS_ROWS` y `MAX_SPOOL_BYTES`.

`ALLOWED_SOURCES` es un control *adicional* al firewall Lightsail. Para el ensayo previo configurar la IP propia `/32` si se desea. Para Tracer con IP dinámica, confirmar si habrá IP fija para esa ventana; en caso contrario, vaciar temporalmente `ALLOWED_SOURCES` y abrir Lightsail a Any IPv4 solo con aprobación explícita, horario delimitado y cierre inmediato. Nunca confundir el origen de producción `34.39.146.212` con el de prueba.

Un PC de 59 bytes con evento **numérico** fuera de 01–11 se conserva con `eventKnown=false` y se contabiliza en `events_unknown`, sin alterar el frame; documentarlo y consultarlo con Tracer. Se mantienen como causas de STOP los errores de estructura, largo, cabecera, terminador, fecha/hora, coordenadas, truncamiento regular o source inesperado. `+99` sigue como supuesto de sensor nulo pendiente de confirmar.

Si `/live` muestra `SPOOL_NEARING_LIMIT` (80%), detener el aumento de tráfico y revisar capacidad antes de continuar. Con `SPOOL_CAPACITY_CRITICAL` (95%, HTTP 503), **NO-GO**: no iniciar ni seguir probando Tracer hasta disponer de espacio y una solución autorizada. Ni SQLite ni el receptor recuperan tráfico no recibido.
