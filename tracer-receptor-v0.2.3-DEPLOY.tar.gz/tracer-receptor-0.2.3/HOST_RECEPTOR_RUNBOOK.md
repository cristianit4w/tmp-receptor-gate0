# HOST_RECEPTOR_RUNBOOK.md

**Receptor Tracer/CAESSAT — GATE 0, código v0.1.2; revisión operativa Lightsail 2026-10-15.**

> **Este documento NO autoriza desplegar ni abrir puertos.** Todo lo indicado para la VM lo ejecuta el dueño cuando apruebe el ensayo. No se ha conectado a Lightsail ni a Tracer. Ya hay fixture **sanitizado** (12 PC) que bloquea el arranque si no pasa; falta observar el flujo TCP auténtico en la ventana coordinada. El significado de `+99` como sensor ausente sigue sin confirmación de Tracer.

## 0. Estado real de la VM y control de cambios — LEER ANTES DE PEGAR NADA

**Datos aportados por el dueño al 15/10/2026; no verificados remotamente por el asistente.**

| Elemento | Estado informado | Acción pendiente |
|---|---|---|
| Instancia | `tracer-receptor`, Lightsail São Paulo, zona A, **Running**, Ubuntu 24.04 LTS, 1 GB RAM | No recrear |
| IP fija | `18.230.173.65` **asociada** | Usarla como destino literal de Tracer; no reasignar |
| Perímetro | **Lightsail IPv4 Firewall**: SSH TCP 22 solo desde IP propia `/32` y SSH del navegador. **Sin reglas HTTP ni IPv6** | Conservar intacto |
| Ingesta | `41873/TCP` **CERRADO** | Lo abre/cierra **exclusivamente el dueño** desde consola Lightsail durante ventanas autorizadas |
| UFW | **No configurado**, no activar ni darlo por existente | Solo comprobación informativa si hiciera falta; no agregar reglas UFW |
| Sistema | `apt update` y `apt upgrade` ya ejecutados, **2 paquetes pendientes**, `unattended-upgrades` presente | Identificar pendientes, no repetir actualización a ciegas |
| Reloj | NTP sincronizado, UTC | Verificar, no modificar zona horaria |
| SSH | `PasswordAuthentication no`; `PermitRootLogin without-password` (sigue admitiendo claves para root) | Cambiar efectiva a **`PermitRootLogin no`** con validación antes de recargar |
| Kernel | Reinicio solicitado tras upgrade | Verificar `/var/run/reboot-required` y `uptime -p`; reiniciar **solo el dueño**, antes de instalar |
| Snapshot existente | Manual `base-limpia` | Conservar; hacer además snapshot **preinstalación** y **postvalidación** |
| Snapshots automáticos | Diarios a las **21:00 ART (UTC−3)**, retención 7, según configuración del dueño | No cambiar; snapshots manuales no deben suponerse incluidos en esa retención |
| Presupuesto | Alerta AWS de USD 15/mes | Es **alerta, no tope de gasto**; snapshots manuales pueden sumar costo |
| Acceso | Usuario `ubuntu`, terminal SSH en navegador Lightsail, sin `scp` y sin acceso root directo | Ejecutar con `sudo` después de verificar `sudo -v` |
| Tracer | Producción sale de `34.39.146.212`; prueba desde IP dinámica. Sin fecha confirmada | Coordinar **mínimo 48 horas**, lunes–viernes 11:00–17:00 ART, sin confundir entorno de ensayo con producción |

### 0.1. Revisión inicial, antes del instalador / antes de instalar

En **SSH del navegador**, como `ubuntu`, ejecutar comprobaciones (el comando `install -d` solo crea `/run/sshd` en el sistema temporal si hace falta):

```bash
whoami
sudo -v
ls /var/run/reboot-required; uptime -p
uname -r
timedatectl
sudo apt list --upgradable 2>/dev/null
sudo systemctl status unattended-upgrades --no-pager || true
sudo install -d -m 0755 /run/sshd
sudo sshd -t
sudo sshd -T | grep -E '^(permitrootlogin|passwordauthentication) '
```

- Si `ls /var/run/reboot-required` dice **«No such file»**, eso solo significa que el indicador de reinicio ya no está; no es un fallo. Si existe, **STOP: el dueño debe reiniciar mediante consola/SSH cuando pueda recuperar acceso**, esperar `Running`, reconectar y **volver a ejecutar estas verificaciones**, incluido `uptime -p`. No encadenar un reinicio dentro del instalador.
- Si siguen **2 paquetes pendientes**, anotar sus nombres y el motivo antes de instalar; no intentar `apt upgrade -y` sin revisar si requieren otra parada/reinicio.
- No confundir sincronización del reloj UTC con fecha de prueba: la ventana de Tracer se pacta en **ART (UTC−3)** y se consigna también en UTC.

### 0.2. Endurecer SSH: prohibir también root con clave

**Solo después de recuperar la sesión tras cualquier reinicio pendiente.** La cuenta `ubuntu` y el SSH del navegador deben mantenerse operativos. No desactivar el puerto 22 ni quitar su regla de Lightsail. Antes de editar:

```bash
sudo install -d -m 0755 /run/sshd
sudo grep -RniE '^\s*(Include|PermitRootLogin|PasswordAuthentication)\s+' \
  /etc/ssh/sshd_config /etc/ssh/sshd_config.d 2>/dev/null || true
sudo sshd -T | grep -E '^(permitrootlogin|passwordauthentication) '
```

Si la salida efectiva **todavía** indica `permitrootlogin` distinto de `no`, y el `Include /etc/ssh/sshd_config.d/*.conf` está activo antes de cualquier otra directiva que tome precedencia, instalar una regla pequeña y verificar la configuración **antes** de recargar:

```bash
printf '%s\n' 'PermitRootLogin no' | sudo tee /etc/ssh/sshd_config.d/00-tracer-no-root.conf >/dev/null
sudo chown root:root /etc/ssh/sshd_config.d/00-tracer-no-root.conf
sudo chmod 0644 /etc/ssh/sshd_config.d/00-tracer-no-root.conf
sudo sshd -t
sudo sshd -T | grep -E '^(permitrootlogin|passwordauthentication) '
```

**NO recargar SSH** salvo que el resultado efectivo sea **ambos** `permitrootlogin no` y `passwordauthentication no`. Si no coinciden, **STOP**: revisar las reglas previas y `Match` con personal de sistemas; no forzar ni encadenar comandos a ciegas. Si ambas coinciden:

```bash
sudo systemctl reload ssh
sudo systemctl is-active ssh
```

Antes de cerrar la sesión que ya funciona, abrir **otra sesión SSH de navegador** y comprobar acceso como `ubuntu`. No crear usuario root ni configurar contraseñas nuevas.

### 0.3. Snapshot manual PRE instalación (obligatorio)

La snapshot `base-limpia` ya existe, pero es anterior a estos controles. **Antes de ejecutar la sección C**:

1. En **AWS Lightsail Console → Instances → tracer-receptor → Snapshots → Create snapshot**, crear manual con nombre equivalente a `pre-receptor-gate0-20261015` (ajustar fecha real).
2. Esperar estado **Completed/Available** en la consola y registrar ID/hora UTC, sin capturas que expongan datos privados.
3. Verificar que `base-limpia` y los snapshots automáticos siguen visibles. No eliminar ninguno por cuenta propia.
4. Considerar costo y espacio del snapshot; la alerta de USD 15 no bloquea cargos adicionales.

**Si no se completa el snapshot preinstalación: NO-GO para sección C.**

### 0.4. Snapshot manual POST validación (obligatorio)

**Solo después de que las secciones C y D pasen**, sin conexiones de Tracer y con `41873` cerrado en Lightsail:

1. Registrar resultados `npm test`, prueba TCP en `127.0.0.1`, estado de `systemd`, contadores SQLite y SHA256 del paquete.
2. Realizar copia **consistente** del SQLite con `bin/backup.js` (ver H). Para una captura de disco más coherente, detener temporalmente el servicio solo si no hay ventana externa activa: `sudo systemctl stop tracer-receptor.service`. Con Tracer real conectado, **NO parar**, pues no existe replay.
3. En consola **Lightsail → tracer-receptor → Snapshots → Create snapshot**, crear `post-receptor-validado-20261015` (fecha real). Esperar **Completed/Available** y registrar el ID.
4. Reanudar `sudo systemctl start tracer-receptor.service` solo si el dueño autorizó mantener el receptor local vivo (el puerto externo permanece cerrado), y comprobar `curl -fsS http://127.0.0.1:9090/live`.
5. **Si fallan tests o falta validación local, NO crear snapshot etiquetado como validado**; anotar bloqueo y conservar snapshot preinstalación.

Los snapshots manuales son una contingencia de restauración de VM, **no sustituyen** el backup consistente y probado de SQLite. No asumir que retención automática de 7 días aplica a snapshots manuales.

## A. Estado y decisiones

- VM ya creada y **Running**: `tracer-receptor`, Lightsail São Paulo zona A, Ubuntu 24.04, 1 GB RAM, usuario `ubuntu`, IPv4 estática asociada `18.230.173.65`. Perímetro exclusivamente **Lightsail IPv4 Firewall**; `41873` permanece cerrado salvo ventana controlada por el dueño. No configurar UFW.
- Proveedor: solo `PC` exactamente 59 bytes ASCII incluyendo `|`, `PS_UNSUPPORTED_BY_SCOPE`, N mensajes/conexión TCP no persistente, EOF = fin de lote, cero ACK de aplicación, cero replay/buffer, origen producción `34.39.146.212`, IP dinámica en prueba, sin TLS.
- **Recomendación: Node.js nativo + systemd**. No Docker en VM de 1 GB: se evitan daemon e imagen, no hay dependencias npm, usa `node:sqlite` del runtime. Requiere Node >=22.16.0 (Node 22 genera advertencia experimental sqlite; se probó con esa versión). El proceso corre bajo `tracerrx` sin shell ni privilegios root.
- Solo SQLite local en GATE 0. `DB_FORWARDER=false` obligatorio por código. No agregar Postgres/Supabase, credenciales, stock ni app By Mones.
- Servir TCP únicamente con regla de firewall Lightsail aprobada temporalmente. Health solo `127.0.0.1:9090`.
- Las patentes/coordenadas son datos confidenciales: raw diagnóstico SQLite en hex y pcap quedan únicamente en VM, protegidos, y deben purgarse tras generar resumen saneado.
- Frente a cualquier discrepancia layout PC, PS, source IP o mensaje con bytes no ASCII: **STOP** y escalar a Tracer; no modificar parser en caliente.

## B. Transferencia sin scp, solo pegar en SSH de navegador

El ZIP/TAR adjunto se puede auditar en una PC, pero para la VM sin `scp` se entrega **`INSTALAR_SSH_PEGAR_TRACER_v0.1.2.txt`** (autocontenido; sustituye al instalador anterior, pues incluye este runbook actualizado). **Primero** verificar el preflight 0.1 y completar snapshot PRE (0.3); luego abrir ese archivo de texto en tu PC, copiar TODO su contenido y pegarlo en la terminal SSH del navegador de Lightsail. No contiene secretos. Hace solamente esto:

1. reconstruye `~/tracer-receptor-gate0.tar.gz` desde Base64;
2. verifica SHA256 del tarball;
3. imprime `PAQUETE COPIADO; SIN INSTALAR`.

No inicia servicios, no abre puertos ni modifica sistema. Si falla hash, **NO instalar**. No pegar el contenido del TAR en la línea de comandos.

En la terminal SSH, cuando termine el pegado:

```bash
sha256sum "$HOME/tracer-receptor-gate0.tar.gz"
tar -tzf "$HOME/tracer-receptor-gate0.tar.gz" | head -40
```

Comparar SHA256 con el valor indicado al principio de `INSTALAR_SSH_PEGAR_TRACER_v0.1.2.txt` y en `SHA256SUMS_TRACER_v0.1.2.txt`.

## C. Preparación de Node, dependencias y usuario de servicio

**Solo cuando el dueño apruebe instalar localmente, el reinicio pendiente esté resuelto, SSH esté verificado y el snapshot PRE esté completo.** Ingresar como `ubuntu` en la SSH del navegador, con `sudo` disponible. Comprobar arquitectura y recursos:

```bash
id -un
uname -m
cat /etc/os-release | head -5
free -h
df -h /
```

Instalar Node.js 22 con repositorio firmado de NodeSource (sin ejecutar `curl | bash`). `node:sqlite` necesita Node >=22.16:

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg tar
sudo install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key -o /tmp/nodesource-repo.gpg.key
sudo gpg --batch --yes --dearmor -o /etc/apt/keyrings/nodesource.gpg /tmp/nodesource-repo.gpg.key
rm -f /tmp/nodesource-repo.gpg.key
echo 'deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main' | sudo tee /etc/apt/sources.list.d/nodesource.list
sudo apt-get update
sudo apt-get install -y nodejs
node --version
```

**Fijar exclusivamente Node.js 22 (22.16+), sin permitir upgrades de major/minor por APT sin un gate de tests:**

```bash
node -e 'const [major, minor] = process.versions.node.split(".").map(Number); if (major !== 22 || minor < 16) process.exit(1)'
sudo apt-mark hold nodejs
apt-mark showhold | grep -x nodejs
```

Si falla la validación de Node **STOP**. No se necesita `npm install`: utiliza sólo el runtime y `node:sqlite` incluido. `apt-mark hold nodejs` puede recibir aviso de actualizaciones de seguridad: evaluar cada cambio de Node, hacer `sudo apt-mark unhold nodejs` únicamente con autorización, aplicar actualización controlada, y **repetir obligatoriamente `npm test` después de cualquier cambio de Node**, ANTES de reiniciar el servicio. Volver a poner `sudo apt-mark hold nodejs`. No saltarse los tests ante un parche menor.

Crear usuario y estructura. **No iniciar todavía**:

```bash
id tracerrx >/dev/null 2>&1 || sudo useradd --system --home-dir /var/lib/tracer-receptor --no-create-home --shell /usr/sbin/nologin tracerrx
sudo install -d -m 0755 -o root -g root /opt/tracer-receptor/releases/0.1.2
sudo tar -xzf "$HOME/tracer-receptor-gate0.tar.gz" -C /opt/tracer-receptor/releases/0.1.2 --strip-components=1
sudo chown -R root:root /opt/tracer-receptor/releases/0.1.2
sudo ln -sfn /opt/tracer-receptor/releases/0.1.2 /opt/tracer-receptor/current
sudo install -d -m 0700 -o tracerrx -g tracerrx /var/lib/tracer-receptor
sudo install -d -m 0750 -o root -g tracerrx /etc/tracer-receptor
sudo install -m 0640 -o root -g tracerrx /opt/tracer-receptor/current/systemd/receiver.env.example /etc/tracer-receptor/receiver.env
sudo install -m 0644 /opt/tracer-receptor/current/systemd/tracer-receptor.service /etc/systemd/system/tracer-receptor.service
sudo install -m 0644 /opt/tracer-receptor/current/systemd/tracer-heartbeat.service /etc/systemd/system/tracer-heartbeat.service
sudo install -m 0644 /opt/tracer-receptor/current/systemd/tracer-heartbeat.timer /etc/systemd/system/tracer-heartbeat.timer
sudo systemctl daemon-reload
```

**Revisar ANTES de cualquier arranque**:

```bash
sudo grep -E '^(RECEIVER_MODE|DIAGNOSTIC_MODE|DB_FORWARDER|TCP_HOST|TCP_PORT|SQLITE_PATH)=' /etc/tracer-receptor/receiver.env
sudo systemctl cat tracer-receptor.service
sudo -u tracerrx /usr/bin/node --test /opt/tracer-receptor/current/test/*.test.js
# Si cambiás la versión de Node después: volver a ejecutar este test.
```

Esperado: `gate0`, `true`, `false`, `0.0.0.0`, `41873`, ruta de SQLite, **todos los tests verdes**.


### C.1 Parámetros v0.1.2 y seguridad contra conexiones ociosas

El archivo `/etc/tracer-receptor/receiver.env` instala estos valores por defecto:

```ini
MAX_ACTIVE_CONNECTIONS=128
MAX_CONNECTIONS_PER_IP=4
SOCKET_IDLE_TIMEOUT_MS=8000
ALLOWED_SOURCES=
MAX_ERRORS_ROWS=1000
MAX_SPOOL_BYTES=134217728
```

- `MAX_ACTIVE_CONNECTIONS=128` es el máximo global en memoria; `MAX_CONNECTIONS_PER_IP=4` aplica al origen remoto normalizado. Si el origen agota el cupo con sockets que aún no enviaron bytes, un socket nuevo desaloja el más antiguo ocioso; si todos están enviando, se rechaza la conexión adicional. **Esto mitiga, no elimina, ataques DoS.**
- `ALLOWED_SOURCES` acepta IP o CIDR IPv4/IPv6 separados por comas (`198.51.100.42/32,203.0.113.0/24`); vacío = sin filtro de aplicación, pero el firewall **Lightsail sigue obligatorio**. Entradas inválidas impiden arrancar. Antes de abrir el puerto al PC del dueño, es recomendable configurarlo a `TU_IP_PUBLICA/32`; durante una prueba Tracer de IP dinámica puede requerirse dejarlo vacío si no se conoce el origen, únicamente bajo la ventana y apertura temporal autorizadas. En fase productiva se proyecta `34.39.146.212/32`, **no se habilita en GATE 0**.
- Cambiar el `.env` con `sudoedit /etc/tracer-receptor/receiver.env`, sin pegar credenciales ni tokens en la consola. Para aplicar se requiere `sudo systemctl restart tracer-receptor.service`, **solo fuera de ventana Tracer** (no hay replay), seguido de `curl -fsS http://127.0.0.1:9090/live` y `journalctl`.
- `MAX_ERRORS_ROWS=1000` conserva únicamente las últimas 1000 filas de errores; los contadores históricos permanecen en `counters`. Al abrir una SQLite heredada poda el exceso existente.
- `MAX_SPOOL_BYTES=134217728` (128 MiB) mide `spool.sqlite` + `-wal` + `-shm`. `/live` muestra `spoolCapacity.bytes`, `limitBytes`, `utilization`, `status` y `alert`. **80%**: HTTP 200 más `alert=SPOOL_NEARING_LIMIT`; **95%**: HTTP 503, `alert=SPOOL_CAPACITY_CRITICAL`, nuevas inserciones se rechazan antes de llenar el disco. Es límite lógico de admisión, **no cuota exacta del sistema de archivos**. Puede haber bytes adicionales por journaling y contadores: monitorear además `df -h` y no esperar el 95%. Como Tracer no reenvía, un bloqueo puede significar pérdida.
- El endpoint `/live` escucha sólo en `127.0.0.1:9090`, nunca por Internet. Configurar un monitor local para evaluar el `status` y el tamaño además del heartbeat externo; el ping externo por sí solo no detecta el aviso del 80%.

**Eventos:** `event_code=01..11` se guarda con `eventKnown=true`. Otros códigos **numéricos de dos dígitos** (`00`, `12`...`99`) se guardan con `eventKnown=false`, `event_known=0` en SQLite y contador `events_unknown` (duplicados incluidos); `events_unknown_unique` cuenta los nuevos. Evento no numérico es inválido y sigue rechazado. Los rechazos de largo, cabecera, terminador, fecha/hora y coordenadas **siguen estrictos**. Evento desconocido es anomalía para analizar, no motivo para perder datos.

**Actualización de esquema SQLite:** v0.1.2 agrega `event_known` con `ALTER TABLE` idempotente preservando mensajes v0.1.1. Antes de cambiar binario hacer respaldo **consistente** con `bin/backup.js`; la reversa a v0.1.1 debe validarse separadamente con copia de la base y la versión previa.

## D. Ensayo local seguro, SIN abrir firewall

En VM, aún sin abrir el puerto público de Lightsail:

```bash
sudo systemctl enable --now tracer-receptor.service
sudo systemctl status tracer-receptor.service --no-pager
curl -fsS http://127.0.0.1:9090/live
cd /opt/tracer-receptor/current
node bin/simulate.js --host 127.0.0.1 --port 41873 --batches 2 --per-batch 3 --chunk 7
sudo -u tracerrx node bin/stats.js /var/lib/tracer-receptor/spool.sqlite
sudo journalctl -u tracer-receptor.service -n 40 --no-pager
```

Esperado simulador: `bytesReceived=0`; para 6 frames sintéticos con 3 modelos distintos repetidos, habrá 3 filas únicas y 3 duplicados en cola. `frames_valid=6`, `stored=3` y `duplicates=3`, y **6 raw de diagnóstico temporales**, si la cola estaba vacía antes. El simulador prueba conexiones TCP nuevas por lote. Para reinicio automático:

```bash
sudo systemctl restart tracer-receptor.service
curl -fsS http://127.0.0.1:9090/live
sudo -u tracerrx node bin/stats.js /var/lib/tracer-receptor/spool.sqlite
```

**No borrar el SQLite para resetear counters** sin autorización expresa. Si ya hubo otros ensayos, mirar incrementos, no valores absolutos. Consulta de raw de diagnóstico SOLO en SSH:

```bash
sudo -u tracerrx node /opt/tracer-receptor/current/bin/raw.js /var/lib/tracer-receptor/spool.sqlite
```


**Conformidad previa obligatoria, ya disponible:**

```bash
cd /opt/tracer-receptor/current
sudo -u tracerrx node --test test/fixtureConformance.test.js
# Esperado: 12 tests en verde, todos los PC tienen exactamente 59 bytes.
# Ensayo de los 12 mensajes como 3 lotes separados por patente:
node bin/simulate.js --host 127.0.0.1 --port 41873 --fixture fixtures/Ejemplo_paquetes_SANITIZADO.txt --group-by-plate --chunk 7
# Resultado esperado: 3 conexiones con 4, 5 y 3 mensajes; 708 bytes; 0 bytes ACK.
# NOTA: estos mensajes son de 2018 y la cola persistente retendra esos 12 reportes de ensayo.
```

El TXT del usuario es SANITIZADO, patentes sintéticas y fechas de 2018. No usar sus
`reported_at` para controlar la latencia de Tracer. Nunca ordenar globalmente:
los grupos AAA001, AAA002 y AAA003 tienen tiempos intercalados. `+99` representa
`null` **provisionalmente** (supuesto pendiente de confirmación); el valor
original permanece en `temperatureRaw` y el hash canónico usa el crudo.

## E. Ensayo previo desde tu PC: permitir solo tu IP pública

1. En tu PC, abrir en navegador `https://api.ipify.org` y anotar tu IPv4 pública actual. **No usar la IP de Lightsail ni la IP del browser SSH**. Asegurarse de que esa es la IPv4 desde la cual correrá PowerShell.
2. **Solo el dueño**: AWS Lightsail Console → `tracer-receptor` → Networking → IPv4 Firewall → Add rule → Custom TCP → `41873` → Restricted to IP address: `TU_IP_PUBLICA/32`. No seleccionar Any IPv4 en este ensayo. La regla se configura en **Lightsail**, no dentro del SSH. No agregar HTTP, IPv6 ni cambiar la regla SSH 22.
3. Dentro de la VM:

```bash
sudo systemctl is-active tracer-receptor.service
sudo ss -lntp | grep ':41873'
```

4. Desde tu PC con PowerShell (Windows):

```powershell
Test-NetConnection -ComputerName 18.230.173.65 -Port 41873
```

Debe decir `TcpTestSucceeded: True`. Este chequeo solo establece TCP, no transmite PC. Si falla, revisar firewall Lightsail y estado del listener; **no abrir todas las IP por comodidad**.
5. Cerrar/borrar la regla `TU_IP_PUBLICA/32` de Lightsail al terminar. Repetir `Test-NetConnection` y confirmar `False`.

**UFW no está configurado en esta VM.** No instalarlo, activarlo ni añadir excepciones. Si alguna vez cambia esa condición, detener el ensayo y documentar ambos perímetros antes de proceder.

## F. Preparación de ventana Tracer (48 h antes)

- Solicitudes a Tracer todavía **en preparación**; **no hay fecha agendada**. Solicitar confirmación por escrito con **48 h de anticipación**, **lunes a viernes de 11:00 a 17:00 ART** (no asumir disponibilidad fuera de esa franja): `18.230.173.65:41873` como IPv4 literal, fecha/hora ART y UTC, patentes/unidades sintéticas de prueba o unidades autorizadas, y contactos de ambos lados.
- Avisar que el receptor **no devuelve ningún ACK de aplicación** y que Tracer no reintenta ni bufferiza.
- Verificar documentación `RUNBOOK_PRUEBA_TRACER.md`, diferencia de formato del TXT real y chequeos GO/NO-GO.
- Ya recibimos `Ejemplo_paquetes_SANITIZADO.txt`, de 12 PC consecutivos y patentes sintéticas. Es **GATE de conformidad obligatorio**: correr `npm test` y comprobar específicamente `fixtureConformance` antes de cualquier sesión con Tracer; debe terminar 41/41 o más (ninguna falla). El archivo sanitizado valida el layout pero NO reemplaza una observación real de TCP en ventana: STOP ante diferencias estrictas de layout; eventos numéricos desconocidos no bloquean pero quedan contados. `+99` => sin sensor/null es SUPUESTO PENDIENTE de confirmación por Tracer. No utilizar sus marcas de tiempo (2018) para medir latencia en vivo.
- No habilitar forwarder ni credenciales PostgreSQL/Supabase.
- Verificar disco (`df -h`), fecha UTC (`timedatectl`), RAM (`free -m`), listener, cola y logs. Alerta si cola/disco quedan cerca de límite; evitar pruebas con disco lleno.

## G. Ventana coordinada con Tracer, según RUNBOOK_PRUEBA_TRACER.md

**Atención: IP de prueba de Tracer dinámica; todavía no hay fecha.** Preferir una IP de origen exacta `/32` si Tracer puede confirmarla para la ventana. Si no puede, el runbook original contempla **temporalmente `0.0.0.0/0` a TCP 41873**, SOLO durante la ventana de 11:00–17:00 ART previamente coordinada, con dueño presente y cierre inmediato. **La decisión y operación de abrir/cerrar son exclusivamente del dueño en el firewall IPv4 de Lightsail; el runbook no automatiza reglas.** Es deliberadamente distinto del ensayo previo `/32`. TCP sin TLS temporalmente expuesto implica riesgo que requiere aceptación explícita; si no se acepta, **NO-GO** hasta obtener source IP verificable u otra solución. No crear reglas IPv6, HTTP ni UFW.

- **T-15**: estado `systemctl`, `curl /live`, `df -h`, `timedatectl`; registrar snapshot de `node bin/stats.js` y hora local/UTC. Verificar que no hay forwarder, sin secretos DB.
- **T-10**: **el dueño**, en AWS Lightsail IPv4 Firewall, habilita **Custom TCP 41873**, idealmente origen `/32` confirmado por Tracer y, solo si no está disponible y se aprobó expresamente, **Any IPv4 (0.0.0.0/0)** durante esa ventana. Si persiste una regla de ensayo privado, revisarla; no cambiar SSH. **NO activar ni modificar UFW**, no abrir ningún otro puerto ni IPv6.
- **T-10**: iniciar PCAP local capada **3 × 5 MB** y límite máximo **20 minutos** (no capturar otros puertos):

```bash
sudo apt-get install -y tcpdump
sudo install -d -m 0700 -o root -g root /var/lib/tracer-receptor/pcap
sudo systemd-run --unit=tracer-capture --property=RuntimeMaxSec=1200 /usr/bin/tcpdump -i any -nn -s 0 -C 5 -W 3 -w /var/lib/tracer-receptor/pcap/tracer-window.pcap 'tcp port 41873'
sudo systemctl status tracer-capture --no-pager
```

- **T-5**: confirmar con Tracer IP literal, puerto y una unidad habilitada. Confirmar que la prueba no es producción.
- **T+0**: Tracer manda 1..N PC por conexión y cierra. Ejecutar en SSH:

```bash
sudo journalctl -u tracer-receptor.service -f
# En otra pestaña SSH del navegador:
curl -fsS http://127.0.0.1:9090/metrics
sudo -u tracerrx node /opt/tracer-receptor/current/bin/stats.js /var/lib/tracer-receptor/spool.sqlite
```

- **Validar:** IP source observada (en journal/pcap), conexiones, bytes, N frames/conexión, EOF limpio, todas las PC exactamente 59 con `|`, UTC real, latencia `received_at - reportado_at` (60–90 s referenciales), padding de patente, GPS inválido no desplaza último GPS válido, PS si aparece contabilizado con `PS_UNSUPPORTED_BY_SCOPE`, 0 bytes escritos al socket desde receptor.
- **Para revisar crudo local**: `sudo -u tracerrx node /opt/tracer-receptor/current/bin/raw.js /var/lib/tracer-receptor/spool.sqlite` muestra `raw_hex` (confidencial); comparar longitud real. No pegar frames reales ni PCAP en chats o GitHub.
- **Reinicio deliberado** del receptor solo si Tracer accede explícitamente a repetir un paquete de prueba controlado. Reinicio demuestra persistencia SQLite, NO replay de Tracer.
- Repetir con otra unidad/lote si disponible. `PS`, cambio layout, bytes inexplicados, origen inesperado, conteos que no cierran => **STOP**.
- **T+fin**: Tracer deshabilita reenvío; **el dueño elimina inmediatamente** la regla de TCP `41873` (sea `/32` o Any IPv4) desde **Lightsail IPv4 Firewall**. **No hay regla UFW que eliminar**; comprobar desde la VM:

```bash
sudo systemctl stop tracer-capture.service || true
sudo ss -lntp | grep ':41873' || true
curl -fsS http://127.0.0.1:9090/live
```

Desde PC externa repetir `Test-NetConnection` y comprobar **False**. Es normal que el proceso siga escuchando internamente; el puerto debe estar bloqueado por firewall externo.
- Exportar exclusivamente métricas agregadas saneadas, sin patentes reales. Captura local `pcap` y raw <=24 h, preferentemente purgar apenas cierren el informe y fixture anonimizado.

## H. Raw, cola, copia de seguridad y limpieza

**Raw:** mensajes validos en `raw_diagnostic` y errores en `errors.raw_text` (hex). Purga automática por hora hasta 24 h configurables; se recomienda purgar inmediatamente al concluir la ventana. El spool de datos estructurados `spool` **NO se borra** con purga raw.

```bash
sudo -u tracerrx node /opt/tracer-receptor/current/bin/raw.js /var/lib/tracer-receptor/spool.sqlite --purge
sudo find /var/lib/tracer-receptor/pcap -maxdepth 1 -type f -name 'tracer-window.pcap*' -delete
```

Capturas pcap contienen localizaciones y placas y deben permanecer restringidas. **No subir a GitHub, chats, Drive o tickets sin anonimizar**.

**Backup SQLite consistente** incluso con WAL activo, sin copiar `spool.sqlite` a pelo:

```bash
sudo -u tracerrx /usr/bin/node /opt/tracer-receptor/current/bin/backup.js \
  /var/lib/tracer-receptor/spool.sqlite \
  "/var/lib/tracer-receptor/backup-$(date -u +%Y%m%dT%H%M%SZ).sqlite"
```

Retención y disposición de esos datos requieren decisión separada del dueño. La cola no drena hacia DB en este gate y **nunca se autodestruye**. Si el disco alcanza un umbral, STOP/alertar: no borrar pendientes automáticamente.

## I. Logs, salud, monitoreo externo

```bash
sudo systemctl status tracer-receptor.service --no-pager
sudo journalctl -u tracer-receptor.service -n 120 --no-pager
sudo journalctl -u tracer-receptor.service --since '20 minutes ago' --no-pager
curl -fsS http://127.0.0.1:9090/live
curl -fsS http://127.0.0.1:9090/metrics
sudo -u tracerrx node /opt/tracer-receptor/current/bin/stats.js /var/lib/tracer-receptor/spool.sqlite
sudo systemctl is-enabled tracer-receptor.service
```

**Checklist de monitores externos (configuración a cargo del dueño):**

- [ ] Heartbeat entrante al monitor desde la VM cada **1 minuto** y **alerta si faltan 5 minutos**; instalar un proveedor externo (Healthchecks/Uptime Kuma o equivalente). URL de ping secreta y con HTTPS; no pegar en chat.
- [ ] TCP check **externo** a `18.230.173.65:41873` desde una IP fija permitida por el dueño **solo en la ventana de ensayo**. Sin esa regla de Lightsail, un check fallido es **cierre intencional**, NO caída. **Desactivarlo fuera de las ventanas**; no dejar el puerto abierto para satisfacer al monitor.
- [ ] Alerta si `queueDepth` supera umbral acordado, disco libre <20%, `oldestPendingAt` crece, `systemd` reinicia en bucle, error de parsing o si hay zero `frames_valid` durante una ventana que Tracer confirmó activa.
- [ ] No confundir ausencia de datos flota con servicio caído: cadencias 3/15 (1/10 algunas) + 60–90 s latencia. En etapa posterior usar el umbral `2×intervalo máximo +90 s`, normalmente **31m30s** con máximo 15 min.

**Heartbeat opcional por SSH**, solo después de obtener URL del proveedor de monitoreo. El secreto NO aparece en comandos ni historia del shell; se ingresa de forma interactiva sin eco:

```bash
read -r -s -p 'Pegar URL HTTPS de heartbeat: ' HURL; echo
printf '%s\n' "$HURL" | sudo tee /etc/tracer-receptor/heartbeat-url >/dev/null
unset HURL
sudo chown root:tracerrx /etc/tracer-receptor/heartbeat-url
sudo chmod 0640 /etc/tracer-receptor/heartbeat-url
sudo systemctl enable --now tracer-heartbeat.timer
sudo systemctl list-timers tracer-heartbeat.timer --no-pager
```

Timer cada 60 s comprueba `http://127.0.0.1:9090/live` y, solo si la URL existe, emite ping HTTPS de monitor. El servicio no envía raw, placa ni coordenadas al monitor. No usar `set -x` ni pegar URLs en comandos de terminal/logs.

## J. Actualización y reversa (sin despliegue automático)

El código queda en `/opt/tracer-receptor/releases/0.1.2` y `/opt/tracer-receptor/current` es un symlink. Cada actualización es un tarball íntegro con SHA256 comprobado, pegado por SSH como en B, almacenado como nueva carpeta `releases/VERSION_NUEVA`. **Nunca sobrescribir una versión anterior** y **nunca** borrar datos de `/var/lib/tracer-receptor`.

Ejemplo de actualización futura, una vez recibido otro bundle y aprobado el gate:

```bash
sudo install -d -m 0755 -o root -g root /opt/tracer-receptor/releases/VERSION_NUEVA
sudo tar -xzf "$HOME/tracer-receptor-gate0.tar.gz" -C /opt/tracer-receptor/releases/VERSION_NUEVA --strip-components=1
sudo chown -R root:root /opt/tracer-receptor/releases/VERSION_NUEVA
sudo -u tracerrx node --test /opt/tracer-receptor/releases/VERSION_NUEVA/test/*.test.js
readlink -f /opt/tracer-receptor/current
# Tras autorizar reinicio, con Tracer detenido (sin replay):
sudo systemctl stop tracer-receptor.service
sudo ln -sfn /opt/tracer-receptor/releases/VERSION_NUEVA /opt/tracer-receptor/current
sudo systemctl start tracer-receptor.service
sudo systemctl status tracer-receptor.service --no-pager
```

Ejemplo de reversa de código (**separada de reversa de esquema SQLite**):

**Solo sirve si esa versión anterior existe realmente en `/opt/tracer-receptor/releases/`. Si esta es la primera instalación, detener el servicio y conservar el SQLite en vez de apuntar a una versión inexistente.**

```bash
# Solo con Tracer suspendido y autorización de mantenimiento:
sudo systemctl stop tracer-receptor.service
sudo ln -sfn /opt/tracer-receptor/releases/VERSION_ANTERIOR_VALIDADA /opt/tracer-receptor/current
sudo systemctl start tracer-receptor.service
```

Si la versión nueva cambia esquema SQLite, **no** asumir rollback compatible: restaurar un backup SQLite consistente, probado, con parada total y autorización adicional; lo anterior revierte solo código. Actualizar unidad de systemd solo si cambió, con `daemon-reload` previo.

## K. GO/NO-GO de cierre

**GO** exclusivamente si: `ls /var/run/reboot-required; uptime -p` revisados y reinicio pendiente resuelto; `sshd -T` confirma `permitrootlogin no` y `passwordauthentication no` sin perder login `ubuntu`; snapshot manual PRE completo; todas las pruebas locales y de VM pasan, incluidos los tests bloqueantes del `Ejemplo_paquetes_SANITIZADO.txt`; SQLite durabilidad/restart demostrados; snapshot manual POST validación completo; confirmación PC 59 y ninguna discrepancia posterior con TCP real; ventana Tracer acordada con >=48 h de antelación en día hábil 11:00–17:00 ART; firewall IPv4 de Lightsail bajo control manual del dueño, cierre reversible, nunca ACK y ningún forwarder DB.

**NO-GO** si: falla el fixture sanitizado, layout divergente en real, source inesperado, fuga de puerto, fail spool, no monitor de liveness, tráfico truncado o trama ambigua. En caso NO-GO, detener, cerrar 41873 y conservar métricas saneadas.

**Queda fuera de alcance**: instalar credenciales PostgreSQL, desplegar en Lightsail desde aquí, abrir reglas, modificar Supabase/By Mones, activar producción y el seguimiento público.
