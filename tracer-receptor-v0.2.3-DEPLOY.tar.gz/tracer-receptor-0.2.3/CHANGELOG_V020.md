# v0.2.2 — H07: cuerpo de respuesta fallido con headers ya recibidos

**Estado: codigo y pruebas locales. El reenviador sigue APAGADO por defecto.** Solo cambia `src/forwarder.js` (y se agrega una prueba).

| ID | Problema reproducido por la IA de ByMones (contraste de v0.2.1) | Correccion |
|---|---|---|
| H07 | `fetch` y la lectura del cuerpo compartian `catch`: si el cuerpo fallaba tras recibir headers validos, salia por `NETWORK_ERROR` con espera de ~1 s y las filas pasaban a `retry`, ignorando status y `Retry-After` (p. ej. 401/429/503 con `Retry-After: 7200`). | Dos pasos separados. Si falla **recibir headers** sigue siendo error de red. Si falla **leer el cuerpo**, el status y `Retry-After` ya recibidos conservan su politica y el cuerpo queda como "no verificable": 401/403/429/503 pausan >= `Retry-After` sin tocar la cola; 503 sin JSON es `UNAVAILABLE`; 409 sin `REPLAY` verificado detiene el contrato; 200 incompleto no confirma (filas a `retry`, `ACK_INVALID`); 5xx y 4xx mantienen su regla. |

Pruebas: **109** en verde (104 previas + 5 de H07). Ademas, la suite de contraste de la IA de ByMones (`CONTRASTE_REENVIADOR_V021`, usando `FORWARDER_PATH`) pasa **102/102** contra este forwarder: verificador 34, compatibilidad 34, H01-H06 6, adicionales 25, bordes H07 3.
La prueba de temporizadores largos (frágil en v0.2.1) ahora filtra solo temporizadores largos.

---

# v0.2.1 — correcciones tras la validacion independiente de la IA de ByMones (rev. 1.3)

**Estado: codigo y pruebas locales. El reenviador sigue APAGADO por defecto.** Solo cambia el reenviador y detalles menores; el protocolo, el hash, la cola y la migracion no cambian.

| ID | Problema reproducido por la IA de ByMones | Correccion |
|---|---|---|
| H02 | El limite de respuesta de 1 MiB contaba caracteres despues de leer todo (acepto 1.200.008 bytes). | `readBounded`: lee por **bytes** con tope, cancela la descarga al superarlo, y rechaza antes si `Content-Length` lo excede. Una respuesta 200 demasiado grande es ACK invalido (filas a retry). |
| H03 | Los status distintos de 200/409/503 usaban `arrayBuffer()` sin tope. | Todo status usa la misma lectura acotada. |
| H01 | `Retry-After: 7200` se recortaba a 3600 s. | **Sin recorte** (segundos o fecha HTTP). El techo de 300 s es solo del backoff. Las esperas > 2^31-1 ms se parten en temporizadores sin acortarlas. La pausa queda **persistida** en la cola (`forwarder_state`) y se respeta tras un reinicio. |
| H04 | 409 con `Retry-After` igual hacia 3 intentos inmediatos. | Con `Retry-After` positivo: un intento y pausa >= Retry-After. |
| H05 | 400 + `Retry-After: 3600` pausaba solo 900 s. | Pausa = max(900 s, Retry-After). |
| H06 | Cualquier 409 se trataba como repeticion de nonce. | Solo `{"code":"REPLAY"}` autoriza el reintento inmediato (hasta 2, es decir 3 intentos). Otro 409 o cuerpo invalido: contrato detenido >= 15 min y alerta (`HTTP_409_UNKNOWN`). |

Tambien: `/live` muestra `LOCAL_QUEUE_ONLY` cuando el diagnostico esta apagado y no hay reenviador; `bin/migrate.js` informa `schemaWasLegacy`; descripcion del servicio sin "GATE0".
HTTP 202 sigue sin confirmar nada: cola intacta, contrato detenido 15 min y alerta (aceptado por la IA de ByMones).

Pruebas: 104 en verde (89 previas + 15 nuevas que cubren H01..H06, lectura acotada, pausa persistente y temporizadores largos).

---

# v0.2.0 — reenviador HTTPS, cuarentena local y diagnostico desactivable

**Estado: codigo y pruebas locales. NO desplegado. El reenviador viene APAGADO y no se conecta a ningun destino.**
Basado en el contrato `CONTRATO_HTTPS_P2_PRECISADO.md` (rev. 1.2) y `02_CONTRATO_DATOS_RECEPTOR_v2.md`
(SHA-256 `0d2cf62e7f400352aba6a2067ee513830c6b83dde14f78b599a3202132d4ba60`).

## Que cambia respecto de v0.1.2

| Area | Cambio |
|---|---|
| Cola SQLite | Nuevo estado `quarantine` y columnas `sent_at`, `quarantined_at`, `quarantine_code`, `last_error_code`. Migracion idempotente que **reconstruye la tabla** dentro de una transaccion (SQLite no permite cambiar un CHECK con ALTER), verifica conteos y conserva `seq`, hash, payload, estados, reintentos y el contador AUTOINCREMENT. Rollback si algo falla. |
| Reenviador | `src/forwarder.js`: lotes de hasta 500 filas / 512 KiB, firma HMAC-SHA-256 (`TRACER-HMAC-V1`), un request en vuelo, ACK **por fila**, backoff con jitter 1..300 s, `Retry-After`, 413 parte el lote, 409 firma de nuevo, 401/403/429/503/400 pausan sin tocar la cola. Con atraso acumulado el siguiente lote sale sin esperar los 15 s. |
| Confirmacion por fila | `insertada`/`duplicada` -> `sent`. `rechazada` permanente -> `quarantine` (no bloquea el resto). `rechazada` transitoria, timeout, red, 5xx, ACK invalido o fila sin confirmar -> `retry` con espera propia. |
| Retencion local | `sent` 72 h desde `sent_at`; `quarantine` 7 dias desde `quarantined_at`; poda diaria (y una vez 5 min despues de arrancar). Nunca se podan `pending`/`retry`. Sin reloj de transicion la fila se conserva y se audita. |
| Configuracion | `src/config.js` valida TODO antes de abrir puertos. `RECEIVER_MODE=gate0` conserva v0.1.2; `standard` permite `DIAGNOSTIC_MODE=false`. Perfiles `staging`/`production` con los literales exactos del contrato; sin alias `prod`; sin fallback a produccion. |
| Clave HMAC | Solo desde **archivo** (`FORWARDER_KEY_FILE`, hex o base64url, >= 32 bytes, permisos 0640/0600). Nunca desde variable de entorno ni en logs. |
| Seguridad de arranque | Reenviador apagado salvo `FORWARDER_ENABLED=true`. Produccion exige ademas `FORWARDER_PRODUCTION_AUTHORIZATION=G5`. Staging exige un spool aparte (`staging*`). |
| Salud | `/live` incluye `forwarder{...}` y la alerta `FORWARDER_STALLED` (contrato detenido o >= 5 fallos seguidos). `queueDepth` = pending + retry. |
| Herramientas | `bin/migrate.js` (respaldo consistente + migracion + verificacion), `bin/quarantine.js` (resumen / reproceso EXPRESO y auditado), `bin/mock-ingest.js` (destino simulado). `bin/stats.js` no migra. |

## Que NO cambia
Protocolo PC, parser, hash, deduplicacion por hash, **cero bytes de respuesta a Tracer** (ahora tambien con test automatico), limites de conexion, ALLOWED_SOURCES, puertos.

## Pruebas (local, Node 24; en la VM correr con Node 22)
89 pruebas en verde: las 41 de v0.1.2 + 48 nuevas (firma con vector publico generado en Python, migracion desde v0.1.1/v0.1.2, rollback, poda, cuarentena, 17 escenarios del reenviador contra un destino simulado, configuracion y extremo a extremo TCP -> HTTPS).
Verificado aparte: **v0.1.2 puede abrir una cola ya migrada** (reversa segura).

## Que NO esta probado ni hecho
- No hay destino real: no se probo contra Supabase/Vercel, ni la verificacion HMAC del lado servidor.
- No se desplego en la VM ni se toco produccion.
- Capacidad: el tope de cola sigue siendo el de `MAX_SPOOL_BYTES`; no se certifico para 72 h de `sent` a 40.000 filas/dia (ver RUNBOOK §Capacidad).
