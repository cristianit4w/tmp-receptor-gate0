# RUNBOOK v0.2.0 — actualizacion y reversa (NO ejecutar sin autorizacion)

Ejecuta Cristian en la VM `tracer-receptor`. Ninguno de estos pasos habilita el reenviador.
Si hay dudas, detenerse: la recepcion TCP (Tracer no reenvia) manda sobre cualquier otra cosa.

## 0. Antes
- Snapshot manual de Lightsail (nombre `pre-v020-AAAAMMDD`).
- Paquete transferido por un canal controlado y **SHA-256 verificado** contra el informado.
- Elegir una ventana de poco trafico (noche). El unico corte es el reinicio del servicio (~3 s).

## 1. Instalar sin activar nada
```bash
sudo install -d -m 0755 /opt/tracer-receptor/releases/0.2.0
sudo tar -xzf ~/tracer-receptor-v0.2.0.tar.gz -C /opt/tracer-receptor/releases/0.2.0 --strip-components=1
sudo chown -R root:root /opt/tracer-receptor/releases/0.2.0
cd /; sudo -u tracerrx node --test --test-concurrency=1 /opt/tracer-receptor/releases/0.2.0/test/*.test.js 2>&1 | grep -E '^# (tests|pass|fail)'
```
Esperado: `fail 0` (correr desde `/`: el usuario de servicio no puede leer `/home/ubuntu`). Node debe ser 22.16+.

## 2. Respaldo + migracion controlada (online, con v0.1.2 todavia corriendo)
```bash
cd /; sudo -u tracerrx node --no-warnings /opt/tracer-receptor/releases/0.2.0/bin/migrate.js \
  /var/lib/tracer-receptor/spool.sqlite /var/lib/tracer-receptor/backups/spool-pre-v020-AAAAMMDD.sqlite
```
Imprime conteos antes/despues; deben coincidir. La cola migrada **sigue funcionando con v0.1.2** (verificado), asi que este paso no requiere cortar el servicio.

## 3. Configuracion
Editar `/etc/tracer-receptor/receiver.env` con `sudoedit` tomando `systemd/receiver.env.v020.example`:
`RECEIVER_MODE=standard`, `DIAGNOSTIC_MODE=false`, y **sin** lineas `FORWARDER_*`. Conservar los valores actuales de limites (`MAX_SPOOL_BYTES`, etc.).
Opcional, para un primer paso mas conservador: dejar `RECEIVER_MODE=gate0` + `DIAGNOSTIC_MODE=true` (identico a v0.1.2).

## 4. Cambio de version (el unico corte)
```bash
sudo ln -sfn /opt/tracer-receptor/releases/0.2.0 /opt/tracer-receptor/current
sudo systemctl restart tracer-receptor.service
sleep 3; systemctl is-active tracer-receptor; curl -fsS http://127.0.0.1:9090/live | head -c 400; echo
sudo journalctl -u tracer-receptor.service -n 5 --no-pager -o cat | cut -c1-200
```
Verificar: `"forwarder":{"enabled":false}`, mismo `queueDepth`, listener en 41873, sin `error`.
Tras la actualizacion, **la copia cruda deja de acumularse** (`DIAGNOSTIC_MODE=false`); purgar la existente cuando se decida (`purgeDiagnosticRaw`) con autorizacion.

## 5. Reversa
```bash
sudo ln -sfn /opt/tracer-receptor/releases/0.1.2 /opt/tracer-receptor/current
# volver RECEIVER_MODE=gate0 y DIAGNOSTIC_MODE=true en receiver.env
sudo systemctl restart tracer-receptor.service
```
La base queda con las columnas nuevas (inocuas para v0.1.2). Restaurar el respaldo `.sqlite` solo si hay corrupcion: **se perderian los mensajes posteriores al respaldo**.

## 6. Reenviador (NO es parte de esta actualizacion)
Habilitarlo es otro cambio, por gates del plan: G3 (staging sintetico, spool `staging-*`, URL de staging, clave de staging) y G5 (produccion, solo tras G4 aprobado, con `FORWARDER_PRODUCTION_AUTHORIZATION=G5`).
Clave: el dueño la entrega por canal privado; guardarla en `/etc/tracer-receptor/forwarder.key` (`0640 root:tracerrx`), nunca en chat, repo, logs ni variables de entorno.

## Capacidad (pendiente de medir antes de G4)
Con poda diaria, `sent` puede conservar hasta ~96 h: a 40.000 filas/dia son ~160.000 filas extra en la cola, mas pendientes y cuarentena. Medir bytes/fila reales con `sent` incluido y ajustar `MAX_SPOOL_BYTES` (hoy 2 GiB por decision aprobada) con evidencia; no se ajusta automaticamente.
